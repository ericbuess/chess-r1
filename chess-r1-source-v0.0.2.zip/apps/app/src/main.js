// CRITICAL: DO NOT MODIFY THIS FILE except for updating paths for linking or imports
// R1 Chess Game v0.0.2
// Two-player chess game with full rule implementation including en passant

// ===========================================
// js-chess-engine Library Integration
// ===========================================

// Import js-chess-engine from npm package - prevents tree-shaking issues
import * as ChessEngine from 'js-chess-engine';
// Import sound data directly to avoid 403 path issues on Rabbit device
import { woodenSoundData } from './woodenSoundData.js';
// Import bot dialogue system
import { getRandomDialogue, dialogueManager } from './botDialogues.js';
// Import king dialogues for Human vs Human mode
import { getWhiteKingDialogue } from './whiteKingDialogues.js';
import { getBlackKingDialogue } from './blackKingDialogues.js';
// Import UI design system for responsive sizing
import uiDesign from './lib/ui-design.js';
window.jsChessEngine = ChessEngine;

// ChessConverter class to translate between our format and js-chess-engine format
class ChessConverter {
  // Convert our board array to js-chess-engine format
  static toLibraryFormat(board, currentPlayer, castlingRights, enPassantTarget) {
    const pieces = {};
    const files = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];
    
    // Convert board array to pieces object
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = board[row][col];
        if (piece) {
          const position = files[col] + ranks[row];
          const notation = this.getPieceNotation(piece);
          pieces[position] = notation;
        }
      }
    }
    
    // Convert castling rights
    const castling = {
      whiteShort: castlingRights?.white?.kingside || false,
      whiteLong: castlingRights?.white?.queenside || false,
      blackShort: castlingRights?.black?.kingside || false,
      blackLong: castlingRights?.black?.queenside || false
    };
    
    return {
      pieces,
      turn: currentPlayer,
      castling,
      enPassant: enPassantTarget || null,
      halfMove: 0, // We don't track this exactly
      fullMove: 1  // We don't track this exactly
    };
  }
  
  static getPieceNotation(piece) {
    const typeMap = {
      'pawn': 'P', 'rook': 'R', 'knight': 'N',
      'bishop': 'B', 'queen': 'Q', 'king': 'K'
    };
    const notation = typeMap[piece.type];
    return piece.color === 'white' ? notation : notation.toLowerCase();
  }
  
  // Validate endgame using library
  static validateEndgame(board, currentPlayer, castlingRights, enPassantTarget) {
    try {
      const config = this.toLibraryFormat(board, currentPlayer, castlingRights, enPassantTarget);
      const game = new window.jsChessEngine.Game(config);
      const status = game.exportJson();
      
      return {
        isCheckmate: status.checkMate || false,
        isStalemate: status.isFinished && !status.checkMate && !status.check,
        isCheck: status.check || false,
        hasValidMoves: Object.keys(status.moves || {}).length > 0
      };
    } catch (error) {
      // Error handling silently
      return null;
    }
  }
}

// Debug Logger - Disabled for production
const debugLogger = {
  debug: () => {},
  info: () => {},
  warn: () => {},
  error: () => {}
};

// Game State Tracker - Enhanced dialogue and context system
const gameStateTracker = {
  lastMove: null,
  gamePhase: 'opening', // opening, middlegame, endgame
  materialBalance: 0, // positive favors white, negative favors black
  lastBalance: 0,
  checkHistory: [],
  specialMoves: [],
  recentlyUsedDialogues: new Set(),
  maxRecentDialogues: 10,
  movesSinceLastDialogue: 0,
  currentPlayer: 'white',
  lastPlayer: 'black',

  // Track last move details
  updateLastMove(fromRow, fromCol, toRow, toCol, piece, capturedPiece, special) {
    this.lastMove = {
      from: { row: fromRow, col: fromCol },
      to: { row: toRow, col: toCol },
      piece: piece,
      captured: capturedPiece,
      special: special || null,
      timestamp: Date.now()
    };
  },

  // Update material balance
  updateMaterialBalance(newBalance) {
    this.lastBalance = this.materialBalance;
    this.materialBalance = newBalance;
  },

  // Check if momentum shifted
  detectMomentumShift() {
    const balanceChange = Math.abs(this.materialBalance - this.lastBalance);
    // Significant shift if balance changed by 3+ points (minor piece)
    return balanceChange >= 3;
  },

  // Track recently used dialogues to avoid repetition
  trackUsedDialogue(category, botName) {
    const key = `${botName}:${category}`;
    if (this.recentlyUsedDialogues.size >= this.maxRecentDialogues) {
      // Remove oldest entries
      const oldestKey = this.recentlyUsedDialogues.values().next().value;
      this.recentlyUsedDialogues.delete(oldestKey);
    }
    this.recentlyUsedDialogues.add(key);
  },

  // Check if dialogue was recently used
  isDialogueRecentlyUsed(category, botName) {
    const key = `${botName}:${category}`;
    return this.recentlyUsedDialogues.has(key);
  },

  // Reset for new game
  reset() {
    this.lastMove = null;
    this.gamePhase = 'opening';
    this.materialBalance = 0;
    this.lastBalance = 0;
    this.checkHistory = [];
    this.specialMoves = [];
    this.recentlyUsedDialogues.clear();
    this.movesSinceLastDialogue = 0;
    this.currentPlayer = 'white';
    this.lastPlayer = 'black';
  }
};

// Chess Game State
class ChessGame {
  constructor() {
    // Initialize js-chess-engine
    this.engine = new window.jsChessEngine.Game();
    
    // UI state management (separate from chess logic)
    this.selectedSquare = null;
    this.possibleMoves = [];
    this.boardFlipped = false;
    this.orientationMode = 'handoff'; // 'none', 'table', or 'handoff' for human vs human
    this.gameMode = 'human-vs-bot';
    this.humanColor = 'white';
    this.botDifficulty = 1; // Bot difficulty: 0=Evy(easy), 1=Emmy(normal), 2=Asa(hard)
    this.allowUndo = true; // Enable undo by default
    this.soundEnabled = true; // Sound effects enabled by default

    // Track changes for menu "Back to game" button
    this.originalGameMode = 'human-vs-bot';
    // Track original settings per mode to properly manage Back to Game button
    this.modeSettings = {
      'human-vs-bot': {
        originalHumanColor: 'white',
        colorChangedMidGame: false,
        originalBotDifficulty: 1,
        difficultyChangedMidGame: false
      },
      'human-vs-human': {
        // Human vs Human doesn't track these changes
      }
    };

    // Cache frequently accessed state
    this.board = this.engineStateToBoard();
    this.currentPlayer = 'white';
    this.gameStatus = 'playing';

    // NEW STATE HISTORY SYSTEM
    // Store complete game states for instant undo/redo
    // Index 0 = initial state, Index 1 = after first move, etc.
    this.stateHistory = [];
    this.currentStateIndex = 0;
    this.isInUndoRedoState = false; // Track if we're in an undo/redo state where bot shouldn't auto-move
    this.lastUndoWasBotMove = false; // Track if the last undo was a bot move for notification
    this.botWasCancelled = false; // Track if bot was cancelled via undo

    // Initialize moveHistory (for backward compatibility)
    this.moveHistory = [];

    // Track current dialogue for persistence
    this.currentDialogue = { text: '', botName: '' };

    // Store initial state as first entry
    const initialState = this.engine.exportJson();
    this.stateHistory.push({
      engineState: JSON.parse(JSON.stringify(initialState)),
      move: null, // No move for initial state
      notation: null,
      dialogue: { text: '', botName: '' }, // No dialogue initially
      timestamp: Date.now()
    });

    // State history system initialized - index 0 is initial state
    
    // Sound system (UI only)
    this.sounds = this.createSoundSystem();
    
    // Circuit breaker properties (kept for compatibility but not used)
    this.checkDepth = 0;
    this.checkOperations = 0;
    this.maxCheckDepth = 10;
    this.maxCheckOperations = 1000;
    this.isEndgameDetection = false;
    
    // Castling rights (maintained for save/load compatibility)
    this.castlingRights = {
      white: { kingside: true, queenside: true },
      black: { kingside: true, queenside: true }
    };
    this.enPassantTarget = null;
  }

  // ============================================
  // CORE MOVEMENT METHODS (UI Interface)
  // ============================================
  
  /**
   * Make a move on the board
   * @param {number} fromRow - Source row (0-7)
   * @param {number} fromCol - Source column (0-7)
   * @param {number} toRow - Destination row (0-7)
   * @param {number} toCol - Destination column (0-7)
   * @returns {boolean} True if move was successful
   */
  async makeMove(fromRow, fromCol, toRow, toCol) {
    
    const from = this.coordsToSquare(fromRow, fromCol);
    const to = this.coordsToSquare(toRow, toCol);
    
    
    
    try {
      // Check if this was a capture for sound
      const targetPiece = this.board[toRow][toCol];
      const isCapture = targetPiece !== null;
      const movedPiece = this.board[fromRow][fromCol];

      // Execute move in engine
      
      const moveResult = this.engine.move(from, to);
      

      // Update our cached state
      this.updateCachedState();

      // Update board orientation after player change
      this.boardFlipped = this.determineOrientation();
      

      // Update game status from engine and check for transitions
      const enteredCheck = this.updateGameStatus();
      if (enteredCheck) {
        // We just entered check - determine who's in check
        const checkedPlayer = this.currentPlayer === 'white' ? 'White' : 'Black';
        
      }

      // Generate notation and commentary for the move
      const notation = this.generateMoveNotation(fromRow, fromCol, toRow, toCol, movedPiece, targetPiece,
        this.gameStatus === 'check', this.gameStatus === 'checkmate');
      const commentary = this.generateMoveCommentary(fromRow, fromCol, toRow, toCol, movedPiece, targetPiece, null);

      // Capture sound metadata for faithful replay
      const soundsPlayed = {};

      // Record what sounds should be played but don't play them yet
      if (isCapture) {
        // Get capture sound indices WITHOUT playing them
        const indices = this.sounds.getCaptureIndices();
        soundsPlayed.action = { type: 'capture', indices };
      } else {
        // Pre-select move sound index
        const lastIndex = this.sounds.lastMoveIndex || 0;
        const index = (lastIndex + 1 + Math.floor(Math.random() * 3)) % 5;
        soundsPlayed.action = { type: 'move', index };
      }

      // Record status sound metadata
      if (this.gameStatus === 'checkmate') {
        soundsPlayed.status = 'checkmate';
      } else if (this.gameStatus === 'check') {
        soundsPlayed.status = 'check';
      }

      // Play sounds after a small delay to sync with visual updates
      setTimeout(() => {
        // Play action sound
        if (isCapture) {
          this.playSound('capture');
        } else {
          this.playSound('move');
        }

        // Play status sound with additional delay if there was a capture
        if (this.gameStatus === 'checkmate') {
          setTimeout(() => this.playSound('checkmate'), isCapture ? 100 : 0);
        } else if (this.gameStatus === 'check') {
          setTimeout(() => this.playSound('check'), isCapture ? 100 : 0);
        }
      }, 100); // Small delay to let piece visually land

      // Use unified state recording method with sound metadata
      this.recordGameState({
        from: { row: fromRow, col: fromCol },
        to: { row: toRow, col: toCol },
        piece: movedPiece,
        captured: targetPiece,
        notation: notation,
        commentary: commentary,
        sounds: Object.keys(soundsPlayed).length > 0 ? soundsPlayed : null
      });

      // Auto-save after successful move
      await this.autoSave();

      // Show dialogue based on move type
      // Determine who just moved (it's now the opponent's turn)
      const justMovedPlayer = this.currentPlayer === 'white' ? 'black' : 'white';
      const isHumanMove = (this.gameMode === 'human-vs-bot' && justMovedPlayer === this.humanColor);
      const isBotMove = (this.gameMode === 'human-vs-bot' && justMovedPlayer !== this.humanColor);

      // Update game state tracker for enhanced dialogue context
      gameStateTracker.lastPlayer = gameStateTracker.currentPlayer;
      gameStateTracker.currentPlayer = this.currentPlayer;
      gameStateTracker.updateLastMove(fromRow, fromCol, toRow, toCol, movedPiece, targetPiece,
        this.generateSpecialMoveDescription(fromRow, fromCol, toRow, toCol, movedPiece, targetPiece));

      // Create rich move context for enhanced dialogue selection
      const moveContext = {
        piece: movedPiece,
        captured: targetPiece,
        isCheck: enteredCheck,
        special: gameStateTracker.lastMove ? gameStateTracker.lastMove.special : null,
        from: { row: fromRow, col: fromCol },
        to: { row: toRow, col: toCol },
        player: justMovedPlayer,
        gamePhase: this.detectGamePhase(),
        materialBalance: this.calculateMaterialBalance()
      };

      // Only show dialogue after bot moves in human-vs-bot mode, or after any move in human-vs-human
      const shouldShowDialogue = (this.gameMode === 'human-vs-human') ||
                                  (this.gameMode === 'human-vs-bot' && isBotMove);

      // Mark that we're about to show a dialogue (for timing coordination)
      if (shouldShowDialogue && window.gameUI) {
        window.gameUI.pendingBotDialogue = true;
    // console.log(`[makeMove] Set pendingBotDialogue = true`);
      }

      // Show enhanced context-aware dialogue
      if (shouldShowDialogue) {
        setTimeout(() => {
          // Determine base dialogue category
          let baseCategory = 'humanMove';

          if (enteredCheck) {
            // Check dialogue takes priority
            if (this.gameMode === 'human-vs-bot') {
              baseCategory = isHumanMove ? 'humanCheck' : 'botCheck';
            } else {
              // Human vs Human - use appropriate check dialogue
              baseCategory = gameStateTracker.currentPlayer === 'white' ? 'inCheck' : 'inCheck';
            }
          } else if (moveContext.captured) {
            // Capture dialogue
            if (this.gameMode === 'human-vs-bot') {
              // Check if it's a queen capture for special handling
              if (moveContext.captured.type === 'queen') {
                // Use capturedQueen category for importance, but will map to capture dialogues
                baseCategory = 'capturedQueen';
              } else {
                baseCategory = isHumanMove ? 'humanCapture' : 'botCapture';
              }
            } else {
              // Human vs Human - use specific capture dialogue
              const capturedType = moveContext.captured.type;
              baseCategory = `captured${capturedType.charAt(0).toUpperCase() + capturedType.slice(1)}`;
            }
          } else if (moveContext.special) {
            // Special move dialogue
            if (moveContext.special.includes('castling')) {
              baseCategory = 'castling';
            } else if (moveContext.special.includes('promotion')) {
              baseCategory = 'promotion';
            } else if (moveContext.special.includes('enPassant')) {
              baseCategory = 'enPassant';
            }
          } else {
            // Regular move dialogue - use piece-specific categories
            if (this.gameMode === 'human-vs-bot') {
              baseCategory = isHumanMove ? 'humanMove' : 'botMove';
            } else {
              // Human vs Human - use piece-specific dialogue
              const pieceType = moveContext.piece ? moveContext.piece.type : 'pawn';
              baseCategory = `${pieceType}Move`;
            }
          }

          // Always show dialogue on every move - use filler for regular moves
          const isCapture = moveContext.captured !== null;
          const isQueenCapture = moveContext.captured && moveContext.captured.type === 'queen';

          // Check material balance for advantage/disadvantage commentary
          const materialBalance = this.calculateMaterialBalance();
          const isHumanPlayer = this.gameMode === 'human-vs-bot' && justMovedPlayer === 'white';

          // Override category for significant material advantage/disadvantage
          if (!enteredCheck && !isCapture) { // Don't override checks or captures
            if (this.gameMode === 'human-vs-bot') {
              // From bot's perspective (black)
              if (materialBalance <= -5) { // Bot has significant advantage
                baseCategory = 'winning';
              } else if (materialBalance >= 5) { // Bot is losing significantly
                baseCategory = 'losing';
              }
            }
          }

          // Determine if we should force show based on event importance
          const eventImportance = this.getEventImportance(baseCategory);
          const forceShow = eventImportance === 'key'; // Only force for key moments

          // Show dialogue with rich context
          this.showBotDialogue(baseCategory, forceShow, moveContext);

          // Clear the pending flag after showing dialogue
          if (window.gameUI) {
            window.gameUI.pendingBotDialogue = false;
    // console.log(`[makeMove] Cleared pendingBotDialogue = false`);
          }
        }, 300);
      }

      return { success: true, enteredCheck };
    } catch (error) {
      
      
      return { success: false, enteredCheck: false };
    }
  }
  
  /**
   * Get possible moves for a piece at given position
   * @param {number} row - Row position (0-7)
   * @param {number} col - Column position (0-7)
   * @returns {Array} Array of {row, col} objects for possible moves
   */
  getPossibleMoves(row, col) {
    const square = this.coordsToSquare(row, col);
    const moves = this.engine.moves(square);
    
    if (!moves || moves.length === 0) {
      return [];
    }
    
    // Convert chess notation back to row/col format
    return moves.map(moveSquare => {
      const coords = this.squareToCoords(moveSquare);
      return { row: coords.row, col: coords.col };
    });
  }
  
  // ============================================
  // GAME STATE METHODS
  // ============================================
  
  /**
   * Update game status based on engine state
   */
  updateGameStatus() {
    const state = this.engine.exportJson();
    const previousStatus = this.gameStatus;
    
    // Update status based on engine state
    if (state.checkMate) {
      this.gameStatus = 'checkmate';
    } else if (state.isFinished && !state.checkMate) {
      this.gameStatus = 'stalemate';
    } else if (state.check) {
      this.gameStatus = 'check';
    } else {
      this.gameStatus = 'playing';
    }
    
    // Return true if we just entered check state
    return previousStatus !== 'check' && this.gameStatus === 'check';
  }
  
  /**
   * Update all cached state from engine
   */
  updateCachedState() {
    const state = this.engine.exportJson();

    // Update board representation
    this.board = this.engineStateToBoard();
    
    // Update current player
    const oldPlayer = this.currentPlayer;
    this.currentPlayer = state.turn;

    // Refresh dialogue button in Human vs Human mode to update turn indicator
    if (this.gameMode === 'human-vs-human' && window.gameUI) {
      // Use a small timeout to ensure UI has settled
      setTimeout(() => {
        window.gameUI.refreshDialogueButton();
      }, 50);
    }

    // DON'T update game status here - let updateGameStatus() be the single source
    // This prevents duplicate/conflicting status updates
    
    // Update castling rights from engine
    this.castlingRights = {
      white: { 
        kingside: state.castling.whiteShort, 
        queenside: state.castling.whiteLong 
      },
      black: { 
        kingside: state.castling.blackShort, 
        queenside: state.castling.blackLong 
      }
    };
    
    this.enPassantTarget = state.enPassant;
  }
  
  // ============================================
  // BOT METHODS
  // ============================================
  
  /**
   * Check if it's the bot's turn
   */
  isBotTurn() {
    if (this.gameMode === 'human-vs-human') {
      return false;
    }
    
    // REMOVED game status check - callers already check this
    // The method should ONLY check whose turn it is, not game state
    
    // In human-vs-bot mode, check if current player is opposite of human color
    return this.currentPlayer !== this.humanColor;
  }
  

  /**
   * Generate bot move
   */
  async generateBotMove() {

    try {
      // Get the piece positions before the move for history tracking
      const boardBefore = this.board;

      // IMPORTANT: aiMove() directly executes the move in the engine!
      // It doesn't just return a move suggestion - it plays it
      // Difficulty: 0 = random, 1 = easy, 2 = medium, 3 = hard, 4 = expert

      // Check if bot was cancelled (use game.botWasCancelled for ChessGame instance)
      if (this.botWasCancelled) {
        return null;
      }

      // Store the engine state before bot move in case we need to restore it
      const engineStateBeforeBot = this.engine.exportJson();

      // For high difficulties (3+), try to use a simpler approach
      // that's more responsive but still challenging

      // All difficulties now use the synchronous method (no Web Worker)
      // Difficulty levels: 0 = Easy (Evy), 1 = Normal (Emmy), 2 = Hard (Asa)
      const aiMove = this.engine.aiMove(this.botDifficulty);

      // Check if bot was cancelled during calculation
      if (this.botWasCancelled) {
        // Restore the engine state from before the bot move
        this.engine = new window.jsChessEngine.Game(engineStateBeforeBot);
        this.updateCachedState();
        this.updateGameStatus();
        return null;
      }

      // Extract moves from aiMove object (it returns an object like {"E2": "E4"})
      const moves = Object.entries(aiMove || {});

      // Only update cached state if NOT cancelled
      // The move has already been made in the engine
      // Update our cached state to reflect the new position
      this.updateCachedState();
      
      // Update game status from engine and check for transitions
      const enteredCheck = this.updateGameStatus();
      if (enteredCheck) {
        // Bot just put human in check
        
      }
      
      // Convert to our format for UI and history
      if (moves && moves.length > 0) {
        const [from, to] = moves[0];
        const fromCoords = this.squareToCoords(from);
        const toCoords = this.squareToCoords(to);
        
        // Get the piece that was moved (now at the destination after updateCachedState)
        const movedPiece = this.board[toCoords.row][toCoords.col];
        const capturedPiece = boardBefore[toCoords.row][toCoords.col];
        
        // Generate notation and commentary
        const notation = this.generateMoveNotation(fromCoords.row, fromCoords.col, toCoords.row, toCoords.col,
          movedPiece, capturedPiece, this.gameStatus === 'check', this.gameStatus === 'checkmate');
        const commentary = this.generateMoveCommentary(fromCoords.row, fromCoords.col, toCoords.row, toCoords.col,
          movedPiece, capturedPiece, null);

        // Capture sound metadata for faithful replay - we need to determine what sounds to play
        // but delay the actual playing
        const soundsPlayed = {};

        // Determine what sounds would be played and store the metadata
        if (capturedPiece) {
          // For captures, get the indices WITHOUT playing sounds
          const indices = this.sounds.getCaptureIndices();
          if (indices) soundsPlayed.action = { type: 'capture', indices };
        } else {
          // For moves, pre-select the index that will be played
          const lastIndex = this.sounds.lastMoveIndex || 0;
          const index = (lastIndex + 1 + Math.floor(Math.random() * 3)) % 5;
          soundsPlayed.action = { type: 'move', index };
        }

        // Record status sound metadata
        if (this.gameStatus === 'checkmate') {
          soundsPlayed.status = 'checkmate';
        } else if (this.gameStatus === 'check') {
          soundsPlayed.status = 'check';
        }

        // Use unified state recording method with sound metadata
        this.recordGameState({
          from: fromCoords,
          to: toCoords,
          piece: movedPiece,
          captured: capturedPiece,
          notation: notation,
          commentary: commentary,
          sounds: Object.keys(soundsPlayed).length > 0 ? soundsPlayed : null
        });

        // Don't play sounds here - let the UI layer handle timing after display update
        // Store what sounds to play in a temporary property for UI to access
        this.pendingBotSounds = { soundsPlayed, capturedPiece };

        // Auto-save after successful bot move
        await this.autoSave();

        return {
          from: fromCoords,
          to: toCoords,
          piece: movedPiece,
          enteredCheck
        };
      } else {
        return null;
      }
    } catch (error) {
      console.error('[generateBotMove] ❌ ERROR:', error.message);
      console.error('[generateBotMove] Stack:', error.stack);
    }
    
    return null;
  }
  
  /**
   * Execute bot move
   */
  async executeBotMove() {

    // Check conditions
    const isHumanVsBot = this.gameMode === 'human-vs-bot';
    const isBotTurn = this.isBotTurn();
    const isValidStatus = this.gameStatus === 'playing' || this.gameStatus === 'check';
    const engineTurn = this.engine.exportJson().turn;

    if (!isHumanVsBot || !isBotTurn || !isValidStatus) {
      const failReason = {
        humanVsBot_fail: !isHumanVsBot ? 'Not human vs bot mode' : 'OK',
        botTurn_fail: !isBotTurn ? `Not bot turn (${this.currentPlayer} === ${this.humanColor})` : 'OK',
        validStatus_fail: !isValidStatus ? `Invalid status (${this.gameStatus})` : 'OK'
      };

      return { success: false, enteredCheck: false };
    }

    // Clear cancellation flag only after we confirm bot should move
    this.botWasCancelled = false;

    const startTime = Date.now();
    
    // Generate AND execute bot move (aiMove() does both!)
    const botMove = await this.generateBotMove();


    // Check if bot was cancelled during generateBotMove (even if it returned a move)
    if (this.botWasCancelled) {
      return { success: false, enteredCheck: false };
    }

    if (!botMove) {
      return { success: false, enteredCheck: false };
    }
    
    // Extract whether check was triggered
    const enteredCheck = botMove.enteredCheck || false;
    
    // Calculate delay for natural feel (reduced since we added pre-calculation delay)
    const thinkingTime = Date.now() - startTime;
    // Ensure minimum 1 second total time for bot move (1000-1200ms total)
    const minimumTotalTime = 1000;
    const targetDelay = minimumTotalTime + Math.random() * 200; // 1000-1200ms total
    const remainingDelay = Math.max(0, targetDelay - thinkingTime);

    // Wait for remaining delay to ensure minimum time
    await new Promise(resolve => setTimeout(resolve, remainingDelay));
    
    // Move was already executed by generateBotMove()
    // Just log success
    // Auto-save after successful bot move
    await this.autoSave();

    return { success: true, enteredCheck };
  }
  
  /**
   * Unified method to record game state after a move
   * Used by both makeMove() and generateBotMove() to avoid duplication
   * This is also what the scroll wheel will call for undo/redo
   * @param {Object} moveData - Move information
   * @param {Object} moveData.from - Source position {row, col}
   * @param {Object} moveData.to - Destination position {row, col}
   * @param {string} moveData.piece - Piece that was moved
   * @param {string|null} moveData.captured - Captured piece (if any)
   * @param {string} moveData.notation - Move notation
   * @param {string} moveData.commentary - Move commentary
   */
  recordGameState(moveData) {
    

    // If we're not at the end of history, truncate future states (branching)
    if (this.currentStateIndex < this.stateHistory.length - 1) {
      
      this.stateHistory = this.stateHistory.slice(0, this.currentStateIndex + 1);
    }

    // Clear the undo/redo state flag when making a new move
    this.isInUndoRedoState = false;

    // R1 Memory Management: Define history limit for R1 device
    const MAX_HISTORY_LENGTH = 100; // Keep last 100 states to prevent memory issues

    // DON'T store complete engine state for moves - only move data
    // This prevents save file bloat (was storing 2KB per move)
    // Engine state can be reconstructed by replaying moves from initial state
    const stateEntry = {
      engineState: null, // Only store engineState for initial state (index 0)
      move: {
        from: moveData.from,
        to: moveData.to,
        piece: moveData.piece,
        captured: moveData.captured
      },
      notation: moveData.notation,
      commentary: moveData.commentary,
      dialogue: { ...this.currentDialogue }, // Store current dialogue state
      sounds: moveData.sounds || null, // Store sound metadata for faithful replay
      timestamp: Date.now()
    };

    
    this.stateHistory.push(stateEntry);
    this.currentStateIndex++;

    // Check if we've exceeded the history limit
    if (this.stateHistory.length > MAX_HISTORY_LENGTH) {
      // Keep the initial state (index 0) plus the most recent states
      const statesToKeep = MAX_HISTORY_LENGTH - 1; // Reserve one slot for initial state
      const removedCount = this.stateHistory.length - MAX_HISTORY_LENGTH;

      

      // Keep initial state + most recent states
      this.stateHistory = [
        this.stateHistory[0], // Always keep initial state for full game reset
        ...this.stateHistory.slice(-statesToKeep)
      ];

      // Adjust current index after trimming
      this.currentStateIndex = this.stateHistory.length - 1;

      
    }

    // Keep old moveHistory for backward compatibility (will remove later)
    if (!this.moveHistory) this.moveHistory = [];
    this.moveHistory.push({
      from: moveData.from,
      to: moveData.to,
      piece: moveData.piece,
      captured: moveData.captured,
      notation: moveData.notation
    });

    // Also limit moveHistory to match stateHistory limits
    if (this.moveHistory.length > MAX_HISTORY_LENGTH - 1) {
      // Keep moves in sync with stateHistory (exclude initial state)
      this.moveHistory = this.moveHistory.slice(-(MAX_HISTORY_LENGTH - 1));
    }

    // Auto-save after recording state
    this.autoSave().catch(error => {
      
    });
  }

  // ============================================
  // COORDINATE CONVERSION
  // ============================================
  
  /**
   * Convert board coordinates to chess notation
   */
  coordsToSquare(row, col) {
    const files = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];
    return files[col] + ranks[row];
  }
  
  /**
   * Convert chess notation to board coordinates
   */
  squareToCoords(square) {
    const files = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
    const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];
    
    const file = square[0];
    const rank = square[1];
    
    const col = files.indexOf(file);
    const row = ranks.indexOf(rank);
    
    return { row, col };
  }
  
  /**
   * Convert engine state to board array
   */
  engineStateToBoard() {
    const state = this.engine.exportJson();
    const board = Array(8).fill(null).map(() => Array(8).fill(null));

    
    
    
    

    for (const [square, piece] of Object.entries(state.pieces)) {
      const coords = this.squareToCoords(square);
      const parsedPiece = this.parsePiece(piece);

      // CRITICAL BUG FIX: Skip corrupted pieces that return null
      if (parsedPiece === null) {
        
        continue; // Don't place corrupted pieces on board
      }

      board[coords.row][coords.col] = parsedPiece;
      if (square === 'E2' || square === 'E4' || square === 'E7' || square === 'E5') {
        
      }
    }

    
    return board;
  }
  
  /**
   * Parse engine piece notation to our format
   */
  parsePiece(enginePiece) {
    // CRITICAL BUG FIX: Validate input to prevent corruption
    if (typeof enginePiece !== 'string') {
      
      return null; // Return null for invalid pieces to filter them out
    }

    if (enginePiece.length !== 1) {
      
      return null;
    }

    const isWhite = enginePiece === enginePiece.toUpperCase();
    const pieceMap = {
      'K': 'king',
      'Q': 'queen',
      'R': 'rook',
      'B': 'bishop',
      'N': 'knight',
      'P': 'pawn'
    };

    const type = pieceMap[enginePiece.toUpperCase()];
    if (!type) {
      
      return null;
    }

    const color = isWhite ? 'white' : 'black';

    return { type, color };
  }
  
  // ============================================
  // GAME MANAGEMENT METHODS
  // ============================================
  
  /**
   * Start a new game
   */
  newGame() {
    // Reset engine
    this.engine = new window.jsChessEngine.Game();

    // Reset UI state
    this.selectedSquare = null;
    this.possibleMoves = [];
    this.moveHistory = [];
    this.currentMoveIndex = -1;
    this.initialEngineState = JSON.parse(JSON.stringify(this.engine.exportJson())); // Deep clone

    // Reset game state tracker for enhanced dialogue system
    gameStateTracker.reset();

    // Reset tracking flags for current mode
    if (this.gameMode === 'human-vs-bot' && this.modeSettings['human-vs-bot']) {
      this.modeSettings['human-vs-bot'].colorChangedMidGame = false;
      this.modeSettings['human-vs-bot'].difficultyChangedMidGame = false;
      this.modeSettings['human-vs-bot'].originalHumanColor = this.humanColor;
      this.modeSettings['human-vs-bot'].originalBotDifficulty = this.botDifficulty;
    }
    this.originalGameMode = this.gameMode;

    // Reset state history for undo/redo system
    this.stateHistory = [];
    this.currentStateIndex = 0;
    this.isInUndoRedoState = false;

    // Store initial state as first entry
    const initialState = this.engine.exportJson();
    this.stateHistory.push({
      engineState: JSON.parse(JSON.stringify(initialState)),
      move: null, // No move for initial state
      captured: null,
      notation: null,
      commentary: null,
      dialogue: { text: '', botName: '' } // No dialogue initially
    });

    // Update cached state FIRST (this sets currentPlayer correctly)
    this.updateCachedState();

    // CRITICAL: Update game status to ensure it's set to 'playing'
    this.updateGameStatus();
    

    // THEN determine board orientation based on correct currentPlayer
    this.boardFlipped = this.determineOrientation();


    // Removed new game sound - only play sounds on moves/undo/redo

    // Reset dialogue manager and show appropriate greeting
    dialogueManager.reset();

    // Show greeting immediately to prevent layout shift
    this.showBotDialogue('gameStart', true); // Force show greeting immediately
  }
  
  /**
   * Set game mode
   */
  setGameMode(mode) {
    this.gameMode = mode;
  }
  
  /**
   * Set human color
   */
  setHumanColor(color) {
    // Track if color was changed mid-game by comparing to original color
    // Only track for human-vs-bot mode (doesn't apply to human-vs-human)
    // In bot mode, changing color always requires new game, regardless of moves
    if (this.gameMode === 'human-vs-bot' && this.modeSettings['human-vs-bot']) {
      // Check if color is different from what it was when menu opened
      this.modeSettings['human-vs-bot'].colorChangedMidGame =
        (color !== this.modeSettings['human-vs-bot'].originalHumanColor);
    }
    this.humanColor = color;
    this.boardFlipped = this.determineOrientation();
  }

  /**
   * Set bot difficulty
   */
  setBotDifficulty(difficulty) {
    // Track if difficulty was changed mid-game by comparing to original difficulty
    // Only track for human-vs-bot mode
    // In bot mode, changing difficulty always requires new game, regardless of moves
    if (this.gameMode === 'human-vs-bot' && this.modeSettings['human-vs-bot']) {
      // Check if difficulty is different from what it was when menu opened
      this.modeSettings['human-vs-bot'].difficultyChangedMidGame =
        (difficulty !== this.modeSettings['human-vs-bot'].originalBotDifficulty);
    }
    this.botDifficulty = difficulty;
  }

  /**
   * Get game mode
   */
  getGameMode() {
    return this.gameMode;
  }
  
  /**
   * Get human color
   */
  getHumanColor() {
    return this.humanColor;
  }
  
  /**
   * Check if board should be flipped (human-vs-bot mode)
   */
  shouldFlipBoard() {
    return this.gameMode === 'human-vs-bot' && this.humanColor === 'black';
  }

  /**
   * Determine correct orientation based on game mode and current player
   * This is the single source of truth for orientation logic
   */
  determineOrientation() {
    const prevFlipped = this.boardFlipped;
    let shouldFlip = false;

    if (this.gameMode === 'human-vs-human') {
      // In human vs human, orientation depends on mode and current player
      if (this.orientationMode === 'none') {
        shouldFlip = false; // Never flip
      } else if (this.orientationMode === 'table') {
        // Table mode: Players sit across from each other
        // Board flips so current player sees their pieces at bottom
        // White's turn = normal view (white at bottom for white player)
        // Black's turn = flipped view (rotates 180° so black player sees black at bottom)
        shouldFlip = this.currentPlayer === 'black';
      } else if (this.orientationMode === 'handoff') {
        // Handoff mode: Dynamic flip based on whose turn it is
        // Device rotates when passed between players
        shouldFlip = this.currentPlayer === 'black';
      }
      
    } else {
      // In human vs bot, flip when playing as black so black pieces are at bottom
      shouldFlip = this.humanColor === 'black';
      
    }

    if (prevFlipped !== shouldFlip) {
      
    }

    return shouldFlip;
  }

  /**
   * Set correct board perspective (legacy - for human-vs-bot)
   */
  setCorrectBoardPerspective() {
    const shouldFlip = this.shouldFlipBoard();
    if (this.boardFlipped !== shouldFlip) {
      this.boardFlipped = shouldFlip;
      return true; // Board was flipped
    }
    return false; // No change needed
  }
  
  // ============================================
  // SAVE/LOAD METHODS
  // ============================================
  
  /**
   * Get game state for saving
   */
  getGameState() {
    const engineState = this.engine.exportJson();

    // CRITICAL FIX: Never save selectedSquare if we're in an interrupted state
    const shouldSaveSelection = !this.isInUndoRedoState && !this.botWasCancelled;

    return {
      board: this.board,
      currentPlayer: this.currentPlayer,
      gameStatus: this.gameStatus,
      moveHistory: this.moveHistory,
      // NEW: Save state history system
      stateHistory: this.stateHistory,
      currentStateIndex: this.currentStateIndex,
      // Remove OLD undo system fields
      // currentMoveIndex: this.currentMoveIndex,
      // initialEngineState: this.initialEngineState,
      selectedSquare: shouldSaveSelection ? this.selectedSquare : null,
      possibleMoves: shouldSaveSelection ? this.possibleMoves : [],
      gameMode: this.gameMode,
      humanColor: this.humanColor,
      botDifficulty: this.botDifficulty,
      allowUndo: this.allowUndo,
      boardFlipped: this.boardFlipped,
      orientationMode: this.orientationMode,
      castlingRights: this.castlingRights,
      enPassantTarget: this.enPassantTarget,
      soundEnabled: this.soundEnabled, // Store sound preference
      currentDialogue: this.currentDialogue, // Store current dialogue for persistence
      engineState: engineState // Store engine state for perfect restoration
    };
  }
  
  /**
   * Load game state
   */
  loadGameState(state, options = {}) {
    // Restore engine state if available
    if (state.engineState) {
      this.engine = new window.jsChessEngine.Game(state.engineState);
    } else {
      // Fallback: recreate from board position
      const config = {
        pieces: {},
        turn: state.currentPlayer,
        castling: {
          whiteShort: state.castlingRights?.white?.kingside || false,
          whiteLong: state.castlingRights?.white?.queenside || false,
          blackShort: state.castlingRights?.black?.kingside || false,
          blackLong: state.castlingRights?.black?.queenside || false
        },
        enPassant: state.enPassantTarget || null
      };
      
      // Convert board to engine format
      const files = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
      const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];
      
      for (let row = 0; row < 8; row++) {
        for (let col = 0; col < 8; col++) {
          const piece = state.board[row][col];
          if (piece) {
            const square = files[col] + ranks[row];
            const typeMap = {
              'pawn': 'P', 'rook': 'R', 'knight': 'N',
              'bishop': 'B', 'queen': 'Q', 'king': 'K'
            };
            const notation = typeMap[piece.type];
            config.pieces[square] = piece.color === 'white' ? notation : notation.toLowerCase();
          }
        }
      }
      
      this.engine = new window.jsChessEngine.Game(config);
    }
    
    // Restore UI state
    // CRITICAL FIX: Don't restore selectedSquare if bot was cancelled
    if (this.botWasCancelled) {
      this.selectedSquare = null;
      this.possibleMoves = [];
    } else {
      this.selectedSquare = state.selectedSquare || null;
      this.possibleMoves = state.possibleMoves || [];
    }
    // Only restore gameMode if not explicitly preserving the current one
    if (!options.preserveGameMode) {
      
      this.gameMode = state.gameMode || 'human-vs-bot';
    } else {
      
    }
    this.humanColor = state.humanColor || 'white';
    this.botDifficulty = state.botDifficulty !== undefined ? state.botDifficulty : 1;
    this.allowUndo = state.allowUndo !== undefined ? state.allowUndo : true;
    // Load orientation mode but DON'T recalculate flip state yet (currentPlayer not set)
    this.orientationMode = state.orientationMode || 'handoff';
    // Temporarily set boardFlipped to saved value or false
    this.boardFlipped = false; // Will be recalculated after updateCachedState()
    this.soundEnabled = state.soundEnabled !== undefined ? state.soundEnabled : true; // Restore sound preference
    this.currentDialogue = state.currentDialogue || { text: '', botName: '' }; // Restore dialogue
    this.moveHistory = state.moveHistory || [];

    // R1 Memory Management: Apply same limit to moveHistory
    const MAX_HISTORY_LENGTH = 100;
    if (this.moveHistory.length > MAX_HISTORY_LENGTH - 1) {
      
      this.moveHistory = this.moveHistory.slice(-(MAX_HISTORY_LENGTH - 1));
    }

    this.currentMoveIndex = state.currentMoveIndex !== undefined ? state.currentMoveIndex : this.moveHistory.length - 1;

    // Ensure initial state is properly cloned and validated
    if (state.initialEngineState) {
      this.initialEngineState = JSON.parse(JSON.stringify(state.initialEngineState));
    } else {
      // If no initial state in save, create fresh one
      const freshGame = new window.jsChessEngine.Game();
      this.initialEngineState = JSON.parse(JSON.stringify(freshGame.exportJson()));
    }

    // Validate loaded initial state
    if (!this.initialEngineState.pieces || !this.initialEngineState.pieces['E2']) {
      
      const freshGame = new window.jsChessEngine.Game();
      this.initialEngineState = JSON.parse(JSON.stringify(freshGame.exportJson()));
    }

    // Update cached state
    this.updateCachedState();

    // NOW recalculate boardFlipped after currentPlayer is set
    this.boardFlipped = this.determineOrientation();
    

    // CRITICAL FIX: Handle stateHistory for the new undo/redo system
    // Check if we have saved stateHistory (new saves) or need to rebuild it (old saves)
    if (state.stateHistory && state.stateHistory.length > 0) {
      // NEW: Restore saved stateHistory directly
      
      this.stateHistory = state.stateHistory;
      this.currentStateIndex = state.currentStateIndex || (state.stateHistory.length - 1);

      // R1 Memory Management: Apply history limit during load
      const MAX_HISTORY_LENGTH = 100;
      if (this.stateHistory.length > MAX_HISTORY_LENGTH) {
        const removedCount = this.stateHistory.length - MAX_HISTORY_LENGTH;
        

        // Keep initial state + most recent states
        this.stateHistory = [
          this.stateHistory[0],  // Always keep initial state
          ...this.stateHistory.slice(-(MAX_HISTORY_LENGTH - 1))
        ];

        // Adjust current index if needed
        const wasAtEnd = this.currentStateIndex === state.stateHistory.length - 1;
        if (wasAtEnd) {
          // If we were at the last state, stay at the last state
          this.currentStateIndex = this.stateHistory.length - 1;
        } else {
          // Otherwise, clamp to valid range
          this.currentStateIndex = Math.min(this.currentStateIndex, this.stateHistory.length - 1);
        }

        
      }
    } else {
      // OLD: Rebuild stateHistory from moveHistory for backward compatibility
      
      this.stateHistory = [];
      this.currentStateIndex = 0;

      // First, store the TRUE initial state (empty board)
      const freshGame = new window.jsChessEngine.Game();
      this.stateHistory.push({
        engineState: JSON.parse(JSON.stringify(freshGame.exportJson())),
        move: null,
        notation: null,
        dialogue: { text: '', botName: '' }, // No dialogue initially
        timestamp: Date.now()
      });

      // If we have moves in history, rebuild states by replaying them
      if (state.moveHistory && state.moveHistory.length > 0) {
        

        // Start with a fresh engine to replay moves
        const replayEngine = new window.jsChessEngine.Game();

        // Replay each move and store the state after each move
        for (let i = 0; i < state.moveHistory.length; i++) {
          const move = state.moveHistory[i];
          const from = this.coordsToSquare(move.from.row, move.from.col);
          const to = this.coordsToSquare(move.to.row, move.to.col);

          try {
            replayEngine.move(from, to);

            // Store the state after this move
            this.stateHistory.push({
              engineState: JSON.parse(JSON.stringify(replayEngine.exportJson())),
              move: move,
              notation: move.notation || `${from}-${to}`,
              dialogue: move.dialogue || { text: '', botName: '' }, // Preserve dialogue if available
              timestamp: Date.now()
            });
            this.currentStateIndex++;
          } catch (error) {
            
            // Stop rebuilding if a move fails
            break;
          }
        }

        
      } else {
        // No moves, just the initial state
        
      }
    }
  }
  
  /**
   * Auto-save the game
   */
  async autoSave() {
    try {
      const state = this.getGameState();
      const key = this.getStorageKey();
      await saveToStorage(key, state);

      // Also save the current game mode separately so we know which to load
      await saveToStorage('last_game_mode', { mode: this.gameMode, timestamp: Date.now() });

      
      return true;
    } catch (error) {
      
      return false;
    }
  }
  
  /**
   * Get storage key for current game mode
   */
  getStorageKey() {
    // Replace hyphens with underscores for consistent storage keys
    return `chess_game_state_${this.gameMode.replace(/-/g, '_')}`;
  }
  
  // ============================================
  // UI HELPER METHODS
  // ============================================
  
  /**
   * Check if it's human's turn
   */
  isHumanTurn() {
    if (this.gameMode === 'human-vs-human') {
      return true; // Always human's turn in this mode
    }
    return this.currentPlayer === this.humanColor;
  }
  
  /**
   * Get game mode display text
   */
  getGameModeDisplayText() {
    if (this.gameMode === 'human-vs-human') {
      return 'Human vs Human';
    } else {
      return `Human (${this.humanColor}) vs Bot`;
    }
  }

  /**
   * Get bot difficulty text
   */
  getBotDifficultyText() {
    const difficulties = {
      0: 'Evy',   // Easy
      1: 'Emmy',  // Normal (was Evy)
      2: 'Asa'    // Hard (was Emmy, removed old Asa at 3)
    };
    return difficulties[this.botDifficulty] || 'Evy';
  }

  /**
   * Detect current game phase based on move count and remaining pieces
   */
  detectGamePhase() {
    const moveCount = this.moveHistory.length;
    const pieceCount = this.countPieces();

    // Opening: First 10-15 moves or many pieces remain
    if (moveCount <= 10 || pieceCount.total >= 28) {
      return 'opening';
    }

    // Endgame: Few pieces remain (typically 12 or fewer)
    if (pieceCount.total <= 12) {
      return 'endgame';
    }

    // Middle game: Everything else
    return 'middlegame';
  }

  /**
   * Detect momentum shift based on material balance changes
   */
  detectMomentumShift() {
    return gameStateTracker.detectMomentumShift();
  }

  /**
   * Categorize move by piece type and special characteristics
   */
  categorizeMove(piece, captured, special) {
    // Special moves take priority
    if (special) {
      if (special.includes('castling')) return 'castling';
      if (special.includes('promotion')) return 'promotion';
      if (special.includes('enPassant')) return 'enPassant';
    }

    // Capture moves
    if (captured) {
      return captured.type === 'queen' ? 'capturedQueen' :
             captured.type === 'rook' ? 'capturedRook' :
             captured.type === 'bishop' ? 'capturedBishop' :
             captured.type === 'knight' ? 'capturedKnight' :
             'capturedPawn';
    }

    // Regular piece moves
    if (piece) {
      return piece.type === 'queen' ? 'queenMove' :
             piece.type === 'rook' ? 'rookMove' :
             piece.type === 'bishop' ? 'bishopMove' :
             piece.type === 'knight' ? 'knightMove' :
             piece.type === 'king' ? 'kingMove' :
             'pawnMove';
    }

    return 'humanMove'; // fallback
  }

  /**
   * Get contextual dialogue category based on game state
   */
  getContextualDialogueCategory(baseCategory, isCheck, gamePhase, momentum) {
    // Check takes highest priority
    if (isCheck) {
      // After a move, currentPlayer has already switched
      // If currentPlayer is human, BOT just delivered check
      // If currentPlayer is bot, HUMAN just delivered check
      return this.gameMode === 'human-vs-bot' ?
        (gameStateTracker.currentPlayer === this.humanColor ? 'botCheck' : 'humanCheck') :
        'inCheck';
    }

    // Special game state categories
    if (momentum) {
      return 'tidesTurning';
    }

    // Phase-specific categories
    if (gamePhase) {
      const phaseCategories = {
        'opening': 'opening',
        'middlegame': 'middleGame',
        'endgame': 'endgame'
      };
      if (phaseCategories[gamePhase] !== phaseCategories[gameStateTracker.gamePhase]) {
        return phaseCategories[gamePhase];
      }
    }

    return baseCategory;
  }

  /**
   * Generate description of special moves (castling, promotion, en passant)
   */
  generateSpecialMoveDescription(fromRow, fromCol, toRow, toCol, piece, capturedPiece) {
    if (!piece) return null;

    // Check for castling
    if (piece.type === 'king' && Math.abs(toCol - fromCol) > 1) {
      return toCol > fromCol ? 'castlingKingside' : 'castlingQueenside';
    }

    // Check for pawn promotion (pawn reaching opposite end)
    if (piece.type === 'pawn') {
      if ((piece.color === 'white' && toRow === 0) || (piece.color === 'black' && toRow === 7)) {
        return 'promotion';
      }

      // Check for en passant (pawn captures diagonally with no piece at destination)
      if (Math.abs(toCol - fromCol) === 1 && !capturedPiece) {
        return 'enPassant';
      }
    }

    return null;
  }

  /**
   * Track recently used filler phrases to avoid repetition
   */
  recentFillers = [];
  maxRecentFillers = 5;

  /**
   * Classify event importance for dialogue probability
   */
  getEventImportance(category) {
    // KEY MOMENTS - Always show special dialogue (100%)
    const keyMoments = [
      'checkmate', 'humanCheck', 'botCheck', 'inCheck',
      'capturedQueen', 'capturedPawn', 'capturedKnight', 'capturedBishop',
      'capturedRook', 'humanCapture', 'botCapture', // ALL captures are key moments
      'castling', 'enPassant', 'promotion', 'sacrifice',
      'brilliantMove', 'blunder', 'gameEnd', 'resignation',
      'humanWins', 'botWins', 'gameStart',
      'winning', 'losing', 'materialAdvantage', 'materialDisadvantage',
      'opening' // Important game phases
    ];

    // MINOR EVENTS - Sometimes show special (30% chance)
    const minorEvents = [
      'middleGame', 'endgame', 'tactical', 'positional'
    ];

    // REGULAR MOVES - Sometimes show special (10% chance)
    // Everything else: pawnMove, knightMove, bishopMove, rookMove,
    // queenMove, kingMove, etc.

    if (keyMoments.includes(category)) {
      return 'key';
    } else if (minorEvents.includes(category)) {
      return 'minor';
    } else {
      return 'regular';
    }
  }

  /**
   * Determine if we should use filler based on event importance
   */
  shouldUseFiller(category) {
    const importance = this.getEventImportance(category);

    if (importance === 'key') {
      return false; // Never use filler for key moments (captures, checks, etc.)
    } else if (importance === 'minor') {
      return Math.random() > 0.30; // 70% chance of filler for game phases
    } else {
      return Math.random() > 0.10; // 90% chance of filler for regular moves
    }
  }

  /**
   * Get a non-repeating filler phrase
   */
  getNonRepeatingFiller(getDialogueFunc, personality) {
    let attempts = 0;
    let filler = null;

    while (attempts < 10) {
      if (personality) {
        filler = getDialogueFunc(personality, 'filler');
      } else {
        filler = getDialogueFunc('filler');
      }

      if (!this.recentFillers.includes(filler)) {
        break;
      }
      attempts++;
    }

    // Track this filler
    if (filler) {
      this.recentFillers.push(filler);
      if (this.recentFillers.length > this.maxRecentFillers) {
        this.recentFillers.shift();
      }
    }

    return filler;
  }

  /**
   * Show bot dialogue if appropriate
   */
  showBotDialogue(category, forceShow = false, moveContext = null) {
    // console.log(`[showBotDialogue] Called with category: ${category}, forceShow: ${forceShow}, gameMode: ${this.gameMode}`);
    if (moveContext) {
    // console.log(`[showBotDialogue] moveContext: piece=${moveContext.piece?.type}, captured=${moveContext.captured?.type}, isCheck=${moveContext.isCheck}, special=${moveContext.special}`);
    }

    // Enhanced dialogue selection for different game modes
    let dialogue = null;
    let displayName = '';

    if (this.gameMode === 'human-vs-bot') {
      // Bot mode dialogues with enhanced context awareness
      const botName = this.getBotDifficultyText();

      // Always show dialogue on every bot move (like Human vs Human mode)
      // Removed frequency limiting to make bots comment on every move
      // if (!forceShow && !dialogueManager.shouldShowDialogue()) {
      //   console.log(`[showBotDialogue] Skipping - dialogue manager says no`);
      //   return null;
      // }

      // Update game state tracker
      const currentPhase = this.detectGamePhase();
      const hasMomentumShift = this.detectMomentumShift();

      // Get enhanced category based on context
      let enhancedCategory = category;
      if (moveContext) {
        const materialBalance = this.calculateMaterialBalance();
        gameStateTracker.updateMaterialBalance(materialBalance);
        gameStateTracker.gamePhase = currentPhase;

        // Use move context to get more specific category
        if (!forceShow) { // Don't override forced categories like gameStart
          enhancedCategory = this.getContextualDialogueCategory(
            this.categorizeMove(moveContext.piece, moveContext.captured, moveContext.special),
            moveContext.isCheck,
            currentPhase,
            hasMomentumShift
          );
        }
      }

      // Probability-based selection: Should we use filler instead?
      // NEVER use filler when forceShow is true (key moments like checks)
      let finalCategory = enhancedCategory;
      if (!forceShow && this.shouldUseFiller(enhancedCategory)) {
        finalCategory = 'filler';
    // console.log(`[showBotDialogue] Using filler instead of ${enhancedCategory}`);
      }

      // Get dialogue for the final category
      if (finalCategory === 'filler') {
        dialogue = this.getNonRepeatingFiller(getRandomDialogue, botName);
      } else {
        // Map specific capture categories to generic bot dialogue categories
        let dialogueCategory = finalCategory;
        const specificCaptures = ['capturedQueen', 'capturedRook', 'capturedBishop', 'capturedKnight', 'capturedPawn'];

        if (specificCaptures.includes(finalCategory)) {
          // After a move, currentPlayer has already switched, so:
          // If current is white, black (bot) just moved
          // If current is black, white (human) just moved
          const botMadeMove = gameStateTracker.currentPlayer === 'white';
          dialogueCategory = botMadeMove ? 'botCapture' : 'humanCapture';
    // console.log(`[showBotDialogue] Mapping ${finalCategory} to ${dialogueCategory}`);
        }

        dialogue = getRandomDialogue(botName, dialogueCategory);
        if (!dialogue) {
    // console.log(`[showBotDialogue] WARNING: No dialogue found for bot=${botName}, category=${dialogueCategory}`);
        }
      }

      // If no dialogue for the category, use filler as fallback
      if (!dialogue && forceShow) {
    // console.log(`[showBotDialogue] Using filler fallback for forced category ${finalCategory}`);
        dialogue = this.getNonRepeatingFiller(getRandomDialogue, botName);
      }

      displayName = botName;

      // Track used dialogue to prevent repetition
      if (dialogue) {
        gameStateTracker.trackUsedDialogue(enhancedCategory, botName);
      }

    } else if (this.gameMode === 'human-vs-human') {
      // Human vs Human mode with contextual king dialogues
      // In Human vs Human mode, always show dialogue on every move (no frequency limiting)
      // The royal kings should comment on every move to create an engaging narrative

      // Determine which king should speak based on current player
      const isWhitePlayer = gameStateTracker.currentPlayer === 'white';
      displayName = 'Human';

      // Probability-based selection: Should we use filler instead?
      // NEVER use filler when forceShow is true (key moments like checks)
      let finalCategory = category;
      if (!forceShow && this.shouldUseFiller(category)) {
        finalCategory = 'filler';
    // console.log(`[showBotDialogue] H vs H: Using filler instead of ${category}`);
      }

      // Use appropriate king dialogue based on current player
      if (isWhitePlayer) {
        if (finalCategory === 'filler') {
          dialogue = this.getNonRepeatingFiller(getWhiteKingDialogue);
        } else {
          dialogue = getWhiteKingDialogue(finalCategory);
        }
        // If no dialogue for the category, use filler
        if (!dialogue && forceShow) {
          dialogue = this.getNonRepeatingFiller(getWhiteKingDialogue);
        }
      } else {
        if (finalCategory === 'filler') {
          dialogue = this.getNonRepeatingFiller(getBlackKingDialogue);
        } else {
          dialogue = getBlackKingDialogue(finalCategory);
        }
        // If no dialogue for the category, use filler
        if (!dialogue && forceShow) {
          dialogue = this.getNonRepeatingFiller(getBlackKingDialogue);
        }
      }

      // Fallback to bot commentary if no king dialogue available
      if (!dialogue) {
        const commentators = ['Evy', 'Emmy', 'Asa'];
        const randomBot = commentators[Math.floor(Math.random() * commentators.length)];
        dialogue = getRandomDialogue(randomBot, category);
        // If still no dialogue and forced, use bot filler
        if (!dialogue && forceShow) {
          dialogue = getRandomDialogue(randomBot, 'filler');
        }
      }
    }

    // console.log(`[showBotDialogue] Got dialogue: "${dialogue}" for display name: ${displayName}`);

    if (dialogue) {
    // console.log(`[showBotDialogue] Has dialogue, checking for window.gameUI...`);

      if (window.gameUI) {
    // console.log(`[showBotDialogue] window.gameUI exists, showing persistent dialogue`);

        // Clear any active thinking interval to allow dialogue to show
        if (window.gameUI.thinkingInterval) {
    // console.log(`[showBotDialogue] Clearing thinking interval to show dialogue`);
          clearInterval(window.gameUI.thinkingInterval);
          window.gameUI.thinkingInterval = null;
        }

        // Show persistent dialogue at bottom of screen
        window.gameUI.showBotDialoguePersistent(dialogue, displayName);

        // Store dialogue in game state for persistence
        this.currentDialogue = { text: dialogue, botName: displayName };

        // Update the last state entry with the new dialogue
        // This ensures undo/redo will restore the correct dialogue
        if (this.stateHistory.length > 0 && this.currentStateIndex === this.stateHistory.length - 1) {
          // We're at the latest state, update it with the new dialogue
          this.stateHistory[this.currentStateIndex].dialogue = { ...this.currentDialogue };
    // console.log(`[showBotDialogue] Updated state history entry ${this.currentStateIndex} with dialogue`);
        }
      } else {
        console.error(`[showBotDialogue] ERROR: window.gameUI is not available!`);
      }
    } else {
    // console.log(`[showBotDialogue] No dialogue returned`);
    }

    return dialogue;
  }

  /**
   * Get color options for UI
   */
  getColorOptions() {
    return [
      { value: 'white', label: 'White' },
      { value: 'black', label: 'Black' }
    ];
  }
  
  /**
   * Get game mode options for UI
   */
  getGameModeOptions() {
    return [
      { value: 'human-vs-bot', label: 'Human vs Bot' },
      { value: 'human-vs-human', label: 'Human vs Human' }
    ];
  }
  
  // ============================================
  // SOUND SYSTEM
  // ============================================
  
  /**
   * Create smart wooden sound system
   */
  createSoundSystem() {
    const sounds = {};

    // Use imported wooden sound data (no longer need window global)
    const woodenData = woodenSoundData;

    // Organize sounds for smart system
    const soundFiles = {
      moves: [
        woodenData.move_1,
        woodenData.move_2,
        woodenData.move_3,
        woodenData.move_4,
        woodenData.move_5
      ],
      quick: [
        woodenData.quick_1,
        woodenData.quick_2
      ],
      pop_check: woodenData.pop_check
    };

    // Track last played move sound to avoid repeats
    let lastMoveIndex = -1;

    // Track if audio has been initialized (for Chrome/Android)
    let audioInitialized = false;
    let audioContext = null;

    // Initialize audio context on first user interaction
    const initializeAudio = () => {
      if (audioInitialized) return;

      try {
        // Create AudioContext for Chrome/Android compatibility
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext && !audioContext) {
          audioContext = new AudioContext();
          // Resume if suspended (Chrome autoplay policy)
          if (audioContext.state === 'suspended') {
            audioContext.resume();
          }
        }

        // Play a silent sound to unlock audio
        const silentAudio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhCDS');
        silentAudio.volume = 0.01;
        silentAudio.play().catch(() => {});

        audioInitialized = true;
      } catch (e) {
      }
    };

    // Helper to play audio with volume control
    const playAudio = (base64Data, volume = 0.4) => {
      if (!this.soundEnabled || !base64Data) return Promise.resolve();

      // Initialize audio on first play attempt
      initializeAudio();

      const audio = new Audio(base64Data);
      audio.volume = volume;

      // Handle Chrome/Android autoplay restrictions
      const playPromise = audio.play();
      if (playPromise !== undefined) {
        return playPromise.catch((error) => {
          // If autoplay blocked, just silently fail
          // Don't try to play on next interaction as it consumes the first tap
          // Audio will work on subsequent actual moves
        });
      }
      return Promise.resolve();
    };

    // Smart move sound - no repeats
    sounds.move = () => {
      const availableIndices = soundFiles.moves
        .map((_, i) => i)
        .filter(i => i !== lastMoveIndex);

      const randomIndex = Math.floor(Math.random() * availableIndices.length);
      lastMoveIndex = availableIndices[randomIndex];

      playAudio(soundFiles.moves[lastMoveIndex]);
      return lastMoveIndex; // Return the index for metadata
    };

    // Capture sound - two different sounds with volume variation
    // First sound softer (piece touching), second normal (piece being placed)
    sounds.capture = () => {
      const allSounds = [...soundFiles.moves, ...soundFiles.quick];

      // Pick first sound randomly
      const index1 = Math.floor(Math.random() * allSounds.length);
      const sound1 = allSounds[index1];

      // Pick second sound (different from first)
      const availableSounds = allSounds.filter((_, i) => i !== index1);
      const index2Raw = Math.floor(Math.random() * availableSounds.length);
      const sound2 = availableSounds[index2Raw];

      // Find actual index of second sound in allSounds array
      let actualIndex2 = 0;
      for (let i = 0, j = 0; i < allSounds.length; i++) {
        if (i !== index1) {
          if (j === index2Raw) {
            actualIndex2 = i;
            break;
          }
          j++;
        }
      }

      // Play first sound softer (0.25 volume), second normal (0.4 volume)
      playAudio(sound1, 0.25);  // Soft touch as piece is picked up
      setTimeout(() => playAudio(sound2, 0.4), 50);  // Normal volume for placing piece

      return [index1, actualIndex2]; // Return both indices for metadata
    };

    // Check sound
    sounds.check = () => {
      playAudio(soundFiles.pop_check);
    };

    // Checkmate sound (same as check)
    sounds.checkmate = () => {
      playAudio(soundFiles.pop_check);
    };

    // New game sound (random move sound)
    sounds.newGame = () => {
      const randomIndex = Math.floor(Math.random() * soundFiles.moves.length);
      playAudio(soundFiles.moves[randomIndex]);
    };

    // Victory sound (same as check) - ADDED
    sounds.victory = () => {
      playAudio(soundFiles.pop_check);
    };

    // Game end sound (random move sound) - ADDED
    sounds.gameEnd = () => {
      const randomIndex = Math.floor(Math.random() * soundFiles.moves.length);
      playAudio(soundFiles.moves[randomIndex]);
    };

    // Store soundFiles for access from other methods
    sounds.soundFiles = soundFiles;
    sounds.lastMoveIndex = lastMoveIndex;

    // Create a method to get capture indices without playing
    sounds.getCaptureIndices = () => {
      const allSounds = [...soundFiles.moves, ...soundFiles.quick];

      // Pick first sound randomly
      const index1 = Math.floor(Math.random() * allSounds.length);

      // Pick second sound (different from first)
      const availableSounds = allSounds.filter((_, i) => i !== index1);
      const index2Raw = Math.floor(Math.random() * availableSounds.length);

      // Find actual index of second sound in allSounds array
      let actualIndex2 = 0;
      for (let i = 0, j = 0; i < allSounds.length; i++) {
        if (i !== index1) {
          if (j === index2Raw) {
            actualIndex2 = i;
            break;
          }
          j++;
        }
      }

      return [index1, actualIndex2];
    };

    return sounds;
  }
  
  /**
   * Play a sound
   */
  playSound(soundName) {

    if (this.sounds && this.sounds[soundName]) {
      return this.sounds[soundName](); // Return any metadata
    }
    return null;
  }

  /**
   * Play specific sounds for undo/redo faithful replay
   */
  playReplayedSounds(sounds, reverse = false) {
    if (!sounds || !this.sounds) return;

    // Reconstruct the sound arrays from imported data
    const soundFiles = {
      moves: [
        woodenSoundData.move_1,
        woodenSoundData.move_2,
        woodenSoundData.move_3,
        woodenSoundData.move_4,
        woodenSoundData.move_5
      ],
      quick: [
        woodenSoundData.quick_1,
        woodenSoundData.quick_2
      ],
      pop_check: woodenSoundData.pop_check
    };
    const allSounds = [...soundFiles.moves, ...soundFiles.quick];

    // Helper to play audio directly
    const playAudio = (base64Data, volume = 0.4) => {
      if (!this.soundEnabled || !base64Data) return;
      const audio = new Audio(base64Data);
      audio.volume = volume;
      audio.play().catch(() => {});
    };

    // Handle both undo (reverse) and redo (forward) sounds
    if (sounds.action) {
      if (sounds.action.type === 'move' && typeof sounds.action.index === 'number') {
        // Play the exact move sound that was originally played
        if (soundFiles.moves[sounds.action.index]) {
          playAudio(soundFiles.moves[sounds.action.index]);
        }
      } else if (sounds.action.type === 'capture' && sounds.action.indices) {
        const [idx1, idx2] = sounds.action.indices;
        if (reverse) {
          // For undo, play capture sounds in reverse order
          if (allSounds[idx2]) {
            playAudio(allSounds[idx2], 0.4);  // Second sound first at normal volume
          }
          if (allSounds[idx1]) {
            setTimeout(() => playAudio(allSounds[idx1], 0.25), 150);  // First sound second, softer
          }
        } else {
          // For redo, play in original order
          if (allSounds[idx1]) {
            playAudio(allSounds[idx1], 0.25);  // Soft touch
          }
          if (allSounds[idx2]) {
            setTimeout(() => playAudio(allSounds[idx2], 0.4), 150);  // Normal volume with proper delay
          }
        }
      }
    }

    // Play status sounds after a delay (only for redo, not undo)
    if (!reverse) {
      const statusDelay = (sounds.action && sounds.action.type === 'capture') ? 100 : 0;
      if (sounds.status === 'checkmate' || sounds.status === 'check') {
        setTimeout(() => {
          if (soundFiles.pop_check) {
            playAudio(soundFiles.pop_check);
          }
        }, statusDelay);
      }
    }
  }

  // ============================================
  // METHODS FOR COMPATIBILITY (NO-OP OR SIMPLE)
  // ============================================
  
  // These methods are kept for UI compatibility but don't do complex logic
  
  initializeBoard() {
    // Not needed - engine handles board state
  }
  
  isValidPosition(row, col) {
    return row >= 0 && row < 8 && col >= 0 && col < 8;
  }
  
  canUndo() {
    // NEW SIMPLIFIED LOGIC
    // Basic check: Can undo if we're not at the initial state (index 0)
    if (!this.allowUndo || this.currentStateIndex <= 0) {
      return false;
    }

    // In human-vs-human mode, any move can be undone
    if (this.gameMode === 'human-vs-human') {
      return true;
    }

    // In human-vs-bot mode, check if there's a human turn to undo to
    // We need to simulate undoing to see if we'd land on a human turn
    let checkIndex = this.currentStateIndex - 1;

    // Keep checking backwards until we find a human turn or reach the start
    while (checkIndex >= 0) {
      // Temporarily reconstruct the state at checkIndex to test turn
      const tempEngineState = checkIndex === 0
        ? this.stateHistory[0].engineState
        : this.reconstructEngineState(checkIndex);

      if (tempEngineState) {
        const tempEngine = new window.jsChessEngine.Game(tempEngineState);
        const tempState = tempEngine.exportJson();

        // Check if this would be a human turn
        const wouldBeHumanTurn = (this.humanColor === 'white' && tempState.turn === 'white') ||
                                  (this.humanColor === 'black' && tempState.turn === 'black');

        if (wouldBeHumanTurn) {
          return true; // Found a human turn to undo to
        }
      }

      checkIndex--;
    }

    return false; // No human turn found to undo to
  }

  canRedo() {
    // NEW SIMPLIFIED LOGIC
    // Basic check: Can redo if we're not at the last state
    if (!this.allowUndo || this.currentStateIndex >= this.stateHistory.length - 1) {
      return false;
    }

    // In human-vs-human mode, any move can be redone
    if (this.gameMode === 'human-vs-human') {
      return true;
    }

    // In human-vs-bot mode, check if there's a human turn to redo to
    // We need to simulate redoing to see if we'd land on a human turn
    let checkIndex = this.currentStateIndex + 1;

    // Keep checking forwards until we find a human turn or reach the end
    while (checkIndex < this.stateHistory.length) {
      // Temporarily reconstruct the state at checkIndex to test turn
      const tempEngineState = checkIndex === 0
        ? this.stateHistory[0].engineState
        : this.reconstructEngineState(checkIndex);

      if (tempEngineState) {
        const tempEngine = new window.jsChessEngine.Game(tempEngineState);
        const tempState = tempEngine.exportJson();

        // Check if this would be a human turn
        const wouldBeHumanTurn = (this.humanColor === 'white' && tempState.turn === 'white') ||
                                  (this.humanColor === 'black' && tempState.turn === 'black');

        if (wouldBeHumanTurn) {
          return true; // Found a human turn to redo to
        }
      }

      checkIndex++;
    }

    return false; // No human turn found to redo to
  }

  // Reconstruct engine state by replaying moves from initial state
  reconstructEngineState(targetIndex) {
    if (targetIndex === 0) {
      return this.stateHistory[0].engineState;
    }

    // Start with initial state
    const initialState = this.stateHistory[0].engineState;
    if (!initialState) {
      
      return null;
    }

    // Create new engine with initial state
    const tempEngine = new window.jsChessEngine.Game(JSON.parse(JSON.stringify(initialState)));

    // Replay moves up to target index
    for (let i = 1; i <= targetIndex; i++) {
      const moveData = this.stateHistory[i].move;
      if (!moveData) {
        
        break;
      }

      const from = this.coordsToSquare(moveData.from.row, moveData.from.col);
      const to = this.coordsToSquare(moveData.to.row, moveData.to.col);

      try {
        tempEngine.move(from, to);
      } catch (e) {
        
        break;
      }
    }

    return tempEngine.exportJson();
  }

  undoMove() {
    // NEW SIMPLIFIED UNDO - Direct state restoration
    if (!this.canUndo()) {
      return false;
    }

    // Store initial state for sound tracking
    const initialIndex = this.currentStateIndex;

    // Perform the initial undo
    const performSingleUndo = () => {
      // Check if the move we're undoing was a capture (for sound replay)
      const undoingState = this.stateHistory[this.currentStateIndex];
      const wasCapture = undoingState && undoingState.captured;

      // Move index back
      this.currentStateIndex--;

      // Restore the engine to the previous state
      const targetState = this.stateHistory[this.currentStateIndex];

      // Get engine state - either stored or reconstructed
      let engineState;
      if (targetState.engineState) {
        // Use stored state if available (index 0)
        engineState = JSON.parse(JSON.stringify(targetState.engineState));
      } else {
        // Reconstruct state by replaying moves from initial
        engineState = this.reconstructEngineState(this.currentStateIndex);
      }

      if (!engineState) {
        return false;
      }

      this.engine = new window.jsChessEngine.Game(engineState);

      // Update cached state (this will call engineStateToBoard internally)
      this.updateCachedState();
      this.updateGameStatus();

      // Force immediate board update to ensure UI synchronization
      this.board = this.engineStateToBoard();

      // Clear selection
      this.selectedSquare = null;
      this.possibleMoves = [];

      // Restore dialogue from target state
      if (targetState.dialogue) {
        this.currentDialogue = { ...targetState.dialogue };
        // Display the restored dialogue
        if (window.gameUI && this.currentDialogue.text) {
          window.gameUI.showBotDialoguePersistent(this.currentDialogue.text, this.currentDialogue.botName);
        }
      }

      // Set flag to indicate we're in undo/redo state
      this.isInUndoRedoState = true;

      return true;
    };

    // Perform the first undo
    if (!performSingleUndo()) {
      return false;
    }

    // In human-vs-bot mode, continue undoing if we landed on a bot turn
    if (this.gameMode === 'human-vs-bot') {
      // Keep undoing while we're on a bot turn and have moves to undo
      while (this.currentStateIndex > 0 && this.isBotTurn()) {
        if (!performSingleUndo()) {
          break;
        }
      }
    }

    // Play sounds from the final state we landed on
    const finalState = this.stateHistory[this.currentStateIndex];
    if (this.currentStateIndex > 0 && finalState && finalState.sounds) {
      setTimeout(() => {
        // Play the exact sounds from the target state (where we're arriving)
        // Use reverse=true to play capture sounds in reverse order
        this.playReplayedSounds(finalState.sounds, true);
      }, 100);
    }
    // No sounds when undoing to index 0 (initial state) - this is correct

    return true;
  }

  redoMove() {
    // NEW SIMPLIFIED REDO - Direct state restoration
    if (!this.canRedo()) {

      return false;
    }

    // Store initial state for sound tracking
    const initialIndex = this.currentStateIndex;

    // Perform the initial redo
    const performSingleRedo = () => {
      // Move index forward
      this.currentStateIndex++;

      // Restore the engine to the next state
      const targetState = this.stateHistory[this.currentStateIndex];

      // Get engine state - either stored or reconstructed
      let engineState;
      if (targetState.engineState) {
        // Use stored state if available (index 0)
        engineState = JSON.parse(JSON.stringify(targetState.engineState));
      } else {
        // Reconstruct state by replaying moves from initial
        engineState = this.reconstructEngineState(this.currentStateIndex);
      }

      if (!engineState) {
        return false;
      }

      this.engine = new window.jsChessEngine.Game(engineState);

      // Update cached state (this will call engineStateToBoard internally)
      this.updateCachedState();
      this.updateGameStatus();

      // Force immediate board update to ensure UI synchronization
      this.board = this.engineStateToBoard();

      // Clear selection
      this.selectedSquare = null;
      this.possibleMoves = [];

      // Restore dialogue from target state
      if (targetState.dialogue) {
        this.currentDialogue = { ...targetState.dialogue };
        // Display the restored dialogue
        if (window.gameUI && this.currentDialogue.text) {
          window.gameUI.showBotDialoguePersistent(this.currentDialogue.text, this.currentDialogue.botName);
        }
      }

      // Set flag to indicate we're in undo/redo state
      this.isInUndoRedoState = true;

      return true;
    };

    // Perform the first redo
    if (!performSingleRedo()) {
      return false;
    }

    // In human-vs-bot mode, continue redoing if we landed on a bot turn
    if (this.gameMode === 'human-vs-bot') {
      // Keep redoing while we're on a bot turn and have moves to redo
      while (this.currentStateIndex < this.stateHistory.length - 1 && this.isBotTurn()) {
        if (!performSingleRedo()) {
          break;
        }
      }
    }

    // Play sounds from the final state we landed on
    const finalState = this.stateHistory[this.currentStateIndex];
    if (finalState && finalState.sounds) {
      this.playReplayedSounds(finalState.sounds, false);  // false = forward order for redo
    }

    return true;
  }

  getCurrentMoveIndex() {
    // NEW: Return current state index minus 1 (since index 0 is initial state)
    // This maintains backward compatibility with UI expectations
    return this.currentStateIndex - 1;
  }

  getCapturedPieces() {
    const whiteCaptured = [];
    const blackCaptured = [];

    // NEW: Use state history, skip index 0 (initial state)
    // Only count captures up to currentStateIndex
    for (let i = 1; i <= this.currentStateIndex && i < this.stateHistory.length; i++) {
      const state = this.stateHistory[i];
      if (state.move && state.move.captured) {
        if (state.move.captured.color === 'white') {
          whiteCaptured.push(state.move.captured);
        } else {
          blackCaptured.push(state.move.captured);
        }
      }
    }

    // Sort by piece value for better display
    const pieceOrder = { 'queen': 1, 'rook': 2, 'bishop': 3, 'knight': 4, 'pawn': 5 };
    whiteCaptured.sort((a, b) => (pieceOrder[a.type] || 6) - (pieceOrder[b.type] || 6));
    blackCaptured.sort((a, b) => (pieceOrder[a.type] || 6) - (pieceOrder[b.type] || 6));

    return { whiteCaptured, blackCaptured };
  }
  
  validateGameState() {
    // Always valid when using engine
    return true;
  }
  
  coordsToChessNotation(row, col) {
    return this.coordsToSquare(row, col);
  }
  
  generateMoveNotation(fromRow, fromCol, toRow, toCol, piece, capturedPiece, isCheck, isCheckmate) {
    const from = this.coordsToSquare(fromRow, fromCol);
    const to = this.coordsToSquare(toRow, toCol);
    return `${from}-${to}`;
  }
  
  generateMoveCommentary(fromRow, fromCol, toRow, toCol, piece, capturedPiece, special) {
    const from = this.coordsToSquare(fromRow, fromCol);
    const to = this.coordsToSquare(toRow, toCol);
    const pieceColor = piece.color.charAt(0).toUpperCase() + piece.color.slice(1);

    if (capturedPiece) {
      return `${pieceColor} ${piece.type} captures ${to} ${capturedPiece.type}`;
    }
    return `${pieceColor} ${piece.type} to ${to}`;
  }
  
  calculateMaterialBalance() {
    const pieceValues = {
      pawn: 1,
      knight: 3,
      bishop: 3,
      rook: 5,
      queen: 9,
      king: 0
    };
    
    let whiteValue = 0;
    let blackValue = 0;
    
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = this.board[row][col];
        if (piece) {
          const value = pieceValues[piece.type] || 0;
          if (piece.color === 'white') {
            whiteValue += value;
          } else {
            blackValue += value;
          }
        }
      }
    }
    
    return whiteValue - blackValue;
  }
  
  countPieces() {
    let count = 0;
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        if (this.board[row][col]) {
          count++;
        }
      }
    }
    return count;
  }
  
  calculateBoardChecksum(board) {
    // Simple checksum for compatibility
    return JSON.stringify(board).length;
  }
  
  calculateMoveHistoryChecksum(moveHistory) {
    // Simple checksum for compatibility
    return moveHistory.length;
  }
  
  testSaveLoadCycle() {
    // Always return true - save/load is simplified
    return Promise.resolve(true);
  }

  getPieceSymbol(piece) {
    if (!piece) return '';
    const symbols = {
      // Use black (solid) Unicode symbols for both colors - CSS handles the white appearance
      'king': { white: '♚', black: '♚' },
      'queen': { white: '♛', black: '♛' },
      'rook': { white: '♜', black: '♜' },
      'bishop': { white: '♝', black: '♝' },
      'knight': { white: '♞', black: '♞' },
      // Use pawn with variation selector to force text rendering (not emoji)
      'pawn': { white: '♟︎', black: '♟︎' }  // U+265F + U+FE0E
    };
    return symbols[piece.type]?.[piece.color] || '';
  }
  
  // ============================================
  // UI COMPATIBILITY METHODS
  // ============================================
  // These methods are needed by ChessUI for error feedback
  
  /**
   * Check if player is currently in check
   * Delegates directly to engine for single source of truth
   */
  isInCheck() {
    const state = this.engine.exportJson();
    return state.check || state.checkMate;
  }
  
  // REMOVED: wouldBeInCheck() method
  // This was redundant since js-chess-engine already handles all check validation
  // The engine's getPossibleMoves() already filters out any moves that would leave king in check
  
  // ============================================
  // DELETED METHODS (800+ lines eliminated!)
  // ============================================
  // The following methods have been completely removed:
  // - getPawnMoves, getRookMoves, getKnightMoves, getBishopMoves, getQueenMoves, getKingMoves
  // - canCastle, isSquareAttacked, getPieceAttacks, getPawnAttacks, getKingAttacks
  // - wouldCaptureKing (NOTE: wouldBeInCheck still exists at lines 911-920)
  // - hasValidMoves, isInCheck, isPlayerInCheck, isCheckmate
  // - getSimplePieceMoves, evaluateQuickMove, evaluateMove
  // - getCenterControlBonus, getDevelopmentBonus, getKingSafetyBonus, getMobilityBonus
  // - isPieceHanging, getPositionalBonus, isPassedPawn, isOnLongDiagonal, isOpenFile
  // - getPieceValue, getGamePhase, getPhaseMultiplier, countTotalPieces
  // - evaluateTacticalThreats, evaluateStrategicPositioning, evaluateKingSafety
  // - evaluatePieceCoordination, detectForkTargets, createsPinAfterMove
  // - evaluatePieceActivity, getKingActivityBonus, findKing, countSupportedPieces
  // - getPieceAttackDirections, getPossibleMovesForPieceAt, evaluatePawnStructure
  // - evaluateDefensiveValue, evaluateAdvancedPositional, blocksCheck
  // - calculateBoardStateHash, calculateBotDelay
  // Total: ~800 lines eliminated!
}
// Global game instance
let chessGame;
let gameUI;

// ===========================================
// Chess Game UI
// ===========================================

class ChessUI {
  // Static flag to prevent multiple concurrent bot turns
  static _globalBotProcessing = false;

  constructor(game) {
    this.game = game;
    this.boardElement = document.getElementById('chess-board');
    this.moveDisplayElement = document.getElementById('move-display');
    this.gameStatusElement = document.getElementById('game-status');
    this.isFlipping = false; // Flag to prevent interactions during flip animation
    this.inputEnabled = true; // Flag to control user input during bot turns
    this.lastAlertTime = 0; // Prevent double alerts
    this.alertCooldown = 1000; // Minimum time between alerts (ms)
    this.audioInitialized = false; // Track audio initialization for Chrome/Android
    this.isBotProcessing = false; // Flag to prevent multiple concurrent bot turns
    this.thinkingInterval = null; // Store interval for message rotation
    this.isR1Device = this.detectR1Device(); // Detect if running on R1
    this.useR1CoordinateFix = true; // FIX IS ALWAYS ON FOR THIS BUILD
    this.enableR1Logging = this.shouldEnableR1Logging(); // Check if R1 debug logging is enabled
    this.botTurnTimer = null; // Global timer to prevent multiple queued bot turn calls
    this.thinkingMessageTimer = null; // Store timeout for initial thinking message display
    this.handledByTouch = false; // Flag to prevent double-handling of touch+click

    // Track event listeners for proper cleanup
    this.optionListeners = [];
    this.boardListeners = [];  // Track board square listeners
    this.menuOpen = false;

    // Track paused timers for menu
    this.pausedTimerStates = null;

    // Removed audio initialization - audio should only play on actual moves/undo/redo
    // This was causing first tap to be consumed without performing the intended action

    // Expand button removed - no longer needed

    this.initializeBoard();
    // Don't call updateDisplay() here - it will be called after game state is loaded
    // this.updateDisplay();

    // Don't check for bot turn here - will be done after game state is loaded
    // this.checkInitialBotTurn();
  }

  removeBoardEventListeners() {
    // Remove all board square event listeners
    this.boardListeners.forEach(({ element, event, handler, options }) => {
      if (element) {
        element.removeEventListener(event, handler, options);
      }
    });
    this.boardListeners = [];
  }

  initializeBoard() {
    // Clean up any existing board listeners before re-initializing
    this.removeBoardEventListeners();

    this.boardElement.innerHTML = '';

    // Initialize touch tracking
    this.activeTouchId = null;
    this.lastTouchTime = 0;

    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const square = document.createElement('div');
        square.className = 'chess-square';
        square.dataset.row = row;
        square.dataset.col = col;

        // Add alternating colors based on position
        const isLight = (row + col) % 2 === 0;
        square.classList.add(isLight ? 'light-square' : 'dark-square');

        // Keep click handler on each square (works fine on desktop)
        const clickHandler = async (e) => await this.handleSquareClick(e);
        square.addEventListener('click', clickHandler);

        // Track click listener for cleanup
        this.boardListeners.push(
          { element: square, event: 'click', handler: clickHandler }
        );

        this.boardElement.appendChild(square);
      }
    }

    // Use event delegation for touch handlers to fix R1 WebView issue with transformed elements
    // Attach touch handlers to board container instead of individual squares
    const delegatedTouchStartHandler = (e) => {
      // Prevent event bubbling issues
      e.stopPropagation();

      const square = e.target.closest('.chess-square');
      if (square) {
        // Validate coordinates before processing
        const row = parseInt(square.dataset.row);
        const col = parseInt(square.dataset.col);

        if (row >= 0 && row <= 7 && col >= 0 && col <= 7) {
          // Call the original handler with a modified event that has the square as target
          this.handleTouchStart({ ...e, target: square });
        }
      }
    };

    const delegatedTouchEndHandler = async (e) => {
      // Prevent event bubbling issues
      e.stopPropagation();

      const square = e.target.closest('.chess-square');
      if (square) {
        // Validate coordinates before processing
        const row = parseInt(square.dataset.row);
        const col = parseInt(square.dataset.col);

        if (row >= 0 && row <= 7 && col >= 0 && col <= 7) {
          // Call the original handler with a modified event that has the square as target
          await this.handleTouchEnd({ ...e, target: square });
        }
      }
    };

    const delegatedTouchCancelHandler = (e) => {
      const square = e.target.closest('.chess-square');
      if (square) {
        // Call the original handler with a modified event that has the square as target
        this.handleTouchCancel({ ...e, target: square });
      }
    };

    // Add delegated touch handlers to board element
    this.boardElement.addEventListener('touchstart', delegatedTouchStartHandler, { passive: false });
    this.boardElement.addEventListener('touchend', delegatedTouchEndHandler, { passive: false });
    this.boardElement.addEventListener('touchcancel', delegatedTouchCancelHandler, { passive: false });

    // Track delegated listeners for cleanup
    this.boardListeners.push(
      { element: this.boardElement, event: 'touchstart', handler: delegatedTouchStartHandler, options: { passive: false } },
      { element: this.boardElement, event: 'touchend', handler: delegatedTouchEndHandler, options: { passive: false } },
      { element: this.boardElement, event: 'touchcancel', handler: delegatedTouchCancelHandler, options: { passive: false } }
    );

    this.applyTheme();
  }

  async handleSquareClick(event) {
    // Skip if this was triggered by a touch event (touch events also trigger click)
    if (this.handledByTouch) {
      this.handledByTouch = false;
      return;
    }

    let row = parseInt(event.target.dataset.row);
    let col = parseInt(event.target.dataset.col);

    // Clicks in Chrome work correctly - no fix needed
    await this.handleSquareSelection(row, col);
  }

  handleTouchStart(event) {
    // Only preventDefault if we're actually on a chess square to avoid blocking other interactions
    if (event.target.classList.contains('chess-square')) {
      event.preventDefault();
    }

    // Store touch identifier for multi-touch scenarios
    this.activeTouchId = event.touches?.[0]?.identifier;
    this.touchStartCoordinates = {
      x: event.touches?.[0]?.clientX,
      y: event.touches?.[0]?.clientY
    };

    this.touchStartTime = Date.now();
    this.touchTarget = event.target;

    // Add immediate visual feedback using class instead of inline style
    if (event.target.classList.contains('chess-square')) {
      event.target.classList.add('touch-active');
    }
  }

  async handleTouchEnd(event) {
    // Only preventDefault if we're actually on a chess square
    if (event.target.classList.contains('chess-square')) {
      event.preventDefault();
    }

    // Validate this is the same touch that started
    if (this.activeTouchId !== null && this.activeTouchId !== undefined) {
      const endTouch = [...(event.changedTouches || [])].find(t => t.identifier === this.activeTouchId);
      if (!endTouch) {
        // Different touch, ignore
        return;
      }
    }

    // Prevent rapid-fire touches (debouncing)
    const now = Date.now();
    if (this.lastTouchTime && now - this.lastTouchTime < 100) {
      return; // Debounce rapid touches
    }
    this.lastTouchTime = now;

    // Remove visual feedback immediately
    if (this.touchTarget && this.touchTarget.classList.contains('chess-square')) {
      this.touchTarget.classList.remove('touch-active');
    }

    // Process touch immediately for better responsiveness (reduced from 500ms to 300ms)
    if (this.touchStartTime && Date.now() - this.touchStartTime < 300) {
      // Get the square from the touch target
      let square = event.target;
      while (square && !square.dataset.row) {
        square = square.parentElement;
      }
      
      if (square && square.dataset.row !== undefined) {
        let row = parseInt(square.dataset.row);
        let col = parseInt(square.dataset.col);

        // Validate coordinates before processing
        if (isNaN(row) || isNaN(col) || row < 0 || row > 7 || col < 0 || col > 7) {
          console.warn('[Touch] Invalid coordinates detected:', { row, col });
          return;
        }

        // Mark that we handled this via touch to prevent double-handling with click
        this.handledByTouch = true;

        // No coordinate fix needed - CSS now rotates container for both table and handoff modes

        await this.handleSquareSelection(row, col);
      }
    }
    
    this.touchStartTime = null;
    this.touchTarget = null;
  }

  handleTouchCancel(event) {
    // Only preventDefault if we're actually on a chess square
    if (event.target.classList.contains('chess-square')) {
      event.preventDefault();
    }

    // Remove visual feedback immediately
    if (this.touchTarget && this.touchTarget.classList.contains('chess-square')) {
      this.touchTarget.classList.remove('touch-active');
    }

    this.touchStartTime = null;
    this.touchTarget = null;
  }

  // Detect if running on Rabbit R1 device
  detectR1Device() {
    // Allow testing R1 features in Chrome with ?r1test=true
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('r1test') === 'true') {
      if (this.shouldEnableR1Logging()) {
    // console.log('[R1 Test Mode] Simulating R1 device in Chrome');
      }
      return true;
    }

    // Check for R1-specific characteristics
    // R1 has specific viewport dimensions and user agent patterns
    const isR1Viewport = window.innerWidth === 240 && window.innerHeight === 320;
    const hasFlutterChannel = typeof window.flutter_inappwebview !== 'undefined';
    const hasR1UserAgent = navigator.userAgent.includes('Rabbit') ||
                           navigator.userAgent.includes('R1') ||
                           navigator.userAgent.includes('Flutter');

    // Also check if running in a WebView context with specific R1 characteristics
    const isWebView = window.webkit || window.flutter_inappwebview;

    // Simplified detection - just check viewport size as primary indicator
    const isR1 = isR1Viewport || hasFlutterChannel || hasR1UserAgent;

    // Apply R1-specific touch optimizations
    if (isR1) {
      // Optimize touch handling for WebView
      document.body.style.touchAction = 'manipulation';
      document.body.style.webkitTouchCallout = 'none';
      document.body.style.webkitUserSelect = 'none';
      document.body.style.userSelect = 'none';

      // Force hardware acceleration
      this.boardElement.style.transform = 'translateZ(0)';
    }

    // Log detection result
    if (this.shouldEnableR1Logging()) {
      // console.log('[R1 Detection]', {
      //   isR1Viewport,
      //   hasFlutterChannel,
      //   hasR1UserAgent,
      //   isWebView,
      //   result: isR1,
      //   viewport: `${window.innerWidth}x${window.innerHeight}`,
      //   userAgent: navigator.userAgent
      // });
    }

    return isR1;
  }

  // Check if R1 coordinate fix should be applied (can be disabled via URL param)
  shouldUseR1CoordinateFix() {
    // Check localStorage first for persistent setting
    const storedFix = localStorage.getItem('r1CoordinateFix');
    if (storedFix !== null) {
      return storedFix === 'true';
    }

    // Then check URL params
    const urlParams = new URLSearchParams(window.location.search);
    const fixParam = urlParams.get('r1fix');

    // Default to disabled since it used to work without the fix
    return fixParam === 'true';
  }

  // Check if R1 debug logging is enabled
  shouldEnableR1Logging() {
    // Only enable logging with explicit debug flag
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('debug') === 'true' || urlParams.get('r1debug') === 'true';
  }

  // Convert display coordinates to logical coordinates based on board flip
  getLogicalCoordinates(displayRow, displayCol) {
    // Apply coordinate reversal based on game mode:
    // - Bot games: Always use coordinate reversal when boardFlipped (black at bottom)
    // - Table mode: ALSO uses coordinate reversal (different from CSS-only modes)
    // - Handoff mode: NO coordinate reversal (CSS rotation only)
    // - None mode in human-vs-human: No reversal
    const isBotGame = this.game.gameMode === 'human-vs-bot';
    const isTableMode = this.game.orientationMode === 'table';

    // Both bot games AND table mode need coordinate reversal when board is flipped
    // EXCEPTION: Handoff mode uses CSS rotation only, never coordinate reversal
    const isHandoffMode = this.game.orientationMode === 'handoff';
    const needsCoordinateReversal = this.game.boardFlipped &&
                                    (isBotGame || (isTableMode && !isHandoffMode));

    if (needsCoordinateReversal) {
      return {
        row: 7 - displayRow,
        col: 7 - displayCol
      };
    }
    return { row: displayRow, col: displayCol };
  }

  // Convert logical coordinates to display coordinates based on board flip
  getDisplayCoordinates(logicalRow, logicalCol) {
    // Apply coordinate reversal based on game mode:
    // - Bot games: Always use coordinate reversal when boardFlipped (black at bottom)
    // - Table mode: ALSO uses coordinate reversal (different from CSS-only modes)
    // - Handoff mode: NO coordinate reversal (CSS rotation only)
    // - None mode in human-vs-human: No reversal
    const isBotGame = this.game.gameMode === 'human-vs-bot';
    const isTableMode = this.game.orientationMode === 'table';

    // Both bot games AND table mode need coordinate reversal when board is flipped
    // EXCEPTION: Handoff mode uses CSS rotation only, never coordinate reversal
    const isHandoffMode = this.game.orientationMode === 'handoff';
    const needsCoordinateReversal = this.game.boardFlipped &&
                                    (isBotGame || (isTableMode && !isHandoffMode));

    if (needsCoordinateReversal) {
      return {
        row: 7 - logicalRow,
        col: 7 - logicalCol
      };
    }
    return { row: logicalRow, col: logicalCol };
  }

  // Flip the board with animation
  flipBoard(callback) {
    if (this.isFlipping) return; // Prevent multiple simultaneous flips

    this.isFlipping = true;
    // Add flip animation class
    this.boardElement.style.transform = 'rotateY(90deg)';
    this.boardElement.style.transition = 'transform 0.3s ease-in-out';

    setTimeout(() => {
      // Use deterministic orientation instead of blind toggle
      const shouldFlip = this.game.determineOrientation();
      this.game.boardFlipped = shouldFlip;
      this.updateDisplay();
      
      // Complete the flip
      this.boardElement.style.transform = 'rotateY(0deg)';
      
      setTimeout(() => {
        this.boardElement.style.transition = '';
        this.isFlipping = false;
        if (callback) callback();
      }, 150);
    }, 150);
  }

  // Update board perspective without animation (for undo/redo)
  updateBoardPerspective() {
    if (this.isFlipping) return; // Don't interfere with ongoing animation

    const currentFlipState = this.game.boardFlipped;
    const wasFlipped = this.boardElement.classList.contains('flipped');

    

    // Update the board flip state immediately without animation
    if (currentFlipState && !wasFlipped) {
      this.boardElement.classList.add('flipped');
    } else if (!currentFlipState && wasFlipped) {
      this.boardElement.classList.remove('flipped');
    }
    
    // Update the display with the current flip state
    this.updateDisplay();
  }

  // Handle bot turn in human-vs-bot mode
  // Enhanced bot move activation system for initial and subsequent turns
  async handleBotTurn() {
    // Clear any pending bot turn timer since we're handling it now
    if (this.botTurnTimer) {
      clearTimeout(this.botTurnTimer);
      this.botTurnTimer = null;
    }

    // If flag wasn't already set (direct call), set it now
    if (!ChessUI._globalBotProcessing) {
      ChessUI._globalBotProcessing = true;
    }

    // CRITICAL: Clear bot cancellation flag when starting a new bot turn
    // This ensures previous cancellations don't affect new bot moves
    if (this.game && this.game.botWasCancelled) {
      this.game.botWasCancelled = false;
    }

    // CRITICAL: Never trigger bot during redo
    if (this.game.isPerformingRedo) {
      ChessUI._globalBotProcessing = false; // Reset flag
      return;
    }

    const gameMode = this.game.gameMode;
    const isBotTurn = this.game.isBotTurn();
    const gameStatus = this.game.gameStatus;

    // Validate bot turn conditions
    if (gameMode !== 'human-vs-bot' || !isBotTurn) {
      ChessUI._globalBotProcessing = false; // Reset flag
      return;
    }

    // Check if game is over
    if (gameStatus !== 'playing' && gameStatus !== 'check') {
      this.showBotThinking(false);
      this.setInputEnabled(false); // Keep disabled for game end
      ChessUI._globalBotProcessing = false; // Reset flag
      return;
    }

    try {
      // Continue with bot turn after validations
      await this.continueBotTurn();
    } catch (error) {
      console.error('Error in continueBotTurn:', error);
      // Reset flag if continueBotTurn throws an error
      ChessUI._globalBotProcessing = false;
    }
  }

  async continueBotTurn() {
    // Flag is already set in handleBotTurn, no need to check or set it here

    // Track timing for minimum display
    const thinkingStartTime = Date.now();
    let notificationShown = false;

    try {
      const isBotTurn = this.game.isBotTurn();

      // Determine if this is an initial bot move (first move of game)
      const isInitialBotMove = (!this.game.moveHistory || this.game.moveHistory.length === 0) && isBotTurn;
      const moveType = isInitialBotMove ? 'INITIAL' : 'SUBSEQUENT';

      // Always ensure user input is disabled and thinking indicator is shown
      this.setInputEnabled(false);
      this.showBotThinking(true);

      // Update UI state to reflect bot's turn
      this.updateGameStateIndicators();

      // Bot thinking messages that rotate
      const thinkingMessages = [
        'analyzing the board',
        'considering options',
        'evaluating threats',
        'contemplating moves',
        'weighing possibilities',
        'calculating variations',
        'examining positions',
        'planning strategy',
        'searching for tactics',
        'assessing material',
        'checking for pins',
        'looking for forks',
        'studying patterns',
        'pondering deeply',
        'processing combinations'
      ];

      // Show thinking message after 4 seconds delay and rotate every 4 seconds
      let messageIndex = Math.floor(Math.random() * thinkingMessages.length);
      let rotationCount = 0;

      // Clear any existing notification setup first
      if (this.thinkingInterval) {
        clearInterval(this.thinkingInterval);
        this.thinkingInterval = null;
      }

      // Clear any existing thinking message timer
      if (this.thinkingMessageTimer) {
        clearTimeout(this.thinkingMessageTimer);
        this.thinkingMessageTimer = null;
      }

      // Show initial message after 4 seconds delay (unless menu is open)
      this.thinkingMessageTimer = setTimeout(() => {
        // Don't show message if menu is open
        if (this.menuOpen) {
          return;
        }
        const label = document.getElementById('instruction-label');
        const botName = this.game.getBotDifficultyText();

        if (label) {
          const initialMessage = `${botName} is ${thinkingMessages[messageIndex]}...`;
          label.textContent = initialMessage;
          label.classList.remove('hidden');
          label.style.backgroundColor = '#FE5F00';
          label.style.color = 'white';
          label.style.fontWeight = 'bold';
          notificationShown = true;

          // Start rotating messages every 4 seconds (unless menu is open)
          this.thinkingInterval = setInterval(() => {
            // Skip rotation if menu is open
            if (this.menuOpen) {
              return;
            }
            rotationCount++;
            messageIndex = (messageIndex + 1) % thinkingMessages.length;
            const currentLabel = document.getElementById('instruction-label');
            if (currentLabel && !currentLabel.classList.contains('hidden')) {
              const dots = '.'.repeat((rotationCount % 3) + 1);
              const newMessage = `${botName} is ${thinkingMessages[messageIndex]}${dots}`;
              currentLabel.textContent = newMessage;
              currentLabel.style.backgroundColor = '#FE5F00';
              currentLabel.style.color = 'white';
              currentLabel.style.fontWeight = 'bold';
            }
          }, 4000); // Rotate every 4 seconds
        }
      }, 4000); // 4 seconds delay before showing

      // Removed delay - bot should move immediately

      // Execute bot move with enhanced error handling
      const botResult = await this.game.executeBotMove();

      // Remove artificial delay - bot should move as fast as it calculates
      // The thinking message is nice but shouldn't slow down gameplay

      // Clear thinking message timer and interval
      if (this.thinkingMessageTimer) {
        clearTimeout(this.thinkingMessageTimer);
        this.thinkingMessageTimer = null;
      }
      if (this.thinkingInterval) {
        clearInterval(this.thinkingInterval);
        this.thinkingInterval = null;
      }

      // Always hide the thinking label (whether it was shown or not)
      const label = document.getElementById('instruction-label');
      if (label) {
        label.classList.add('hidden');
        // Reset styles
        label.style.backgroundColor = '';
        label.style.color = '';
        label.style.fontWeight = '';
        label.textContent = '';
      }

      if (botResult && botResult.success) {
        // Update display after bot move
        this.updateDisplay();

        // Update gameStateTracker to reflect bot's move
        gameStateTracker.lastPlayer = gameStateTracker.currentPlayer;
        gameStateTracker.currentPlayer = this.game.currentPlayer;

        // Check if bot put human in check
        if (botResult.enteredCheck) {
          // Bot put human in check - highlight human's king
          // After bot moves, currentPlayer is now humanColor (it's human's turn)
          // So we should highlight the human's king who is in check
          this.highlightKing(this.game.humanColor);
        }

        // Show bot dialogue after move - force show for captures and checks
        if (this.game.pendingBotSounds) {
          const { capturedPiece } = this.game.pendingBotSounds;

          // Determine dialogue category
          let category = 'botMove';
          if (botResult.enteredCheck) {
            category = 'botCheck';
          } else if (capturedPiece) {
            // Specific capture categories based on piece type
            if (capturedPiece.type === 'queen') {
              category = 'capturedQueen';
            } else if (capturedPiece.type === 'rook') {
              category = 'capturedRook';
            } else if (capturedPiece.type === 'bishop' || capturedPiece.type === 'knight') {
              category = capturedPiece.type === 'bishop' ? 'capturedBishop' : 'capturedKnight';
            } else {
              category = 'botCapture';
            }
          }

          // Determine if we should force show based on event importance
          const eventImportance = this.game.getEventImportance(category);
          const forceShow = eventImportance === 'key'; // Only force for key moments

          // Show the dialogue
          this.game.showBotDialogue(category, forceShow);
        }

        // Play bot sounds after display update with a small delay to sync with visual
        if (this.game.pendingBotSounds) {
          const { soundsPlayed, capturedPiece } = this.game.pendingBotSounds;

          // Small delay to let display update render
          setTimeout(() => {
            // Play the pre-selected sounds
            if (soundsPlayed.action) {
              if (soundsPlayed.action.type === 'capture' && soundsPlayed.action.indices) {
                // Play capture sound
                this.game.playSound('capture');
              } else if (soundsPlayed.action.type === 'move') {
                // Play move sound
                this.game.playSound('move');
              }
            }

            // Play status sounds
            if (soundsPlayed.status === 'checkmate') {
              setTimeout(() => this.game.playSound('checkmate'), capturedPiece ? 100 : 0);
            } else if (soundsPlayed.status === 'check') {
              setTimeout(() => this.game.playSound('check'), capturedPiece ? 100 : 0);
            }
          }, 100); // Small delay to sync with visual update

          // Clear pending sounds
          this.game.pendingBotSounds = null;
        }

        // Hide thinking indicator and re-enable input only after successful move
        this.showBotThinking(false);

        // Check if game ended after bot move
        if (this.game.gameStatus === 'checkmate' || this.game.gameStatus === 'stalemate') {
          this.setInputEnabled(false); // Keep disabled for game end
          this.handleGameEnd();
        } else {
          // Game continues - enable input for human's turn
          this.setInputEnabled(true);
        }

      } else {
        // Hide thinking indicator
        this.showBotThinking(false);

        // Bot move failed - no notification needed

        this.setInputEnabled(true);

        // Bot move failed - cleanup done
      }
    } catch (error) {
      // Ensure minimum display time even on error (enough to at least show the message)
      const minThinkingTime = 5000; // 5 seconds minimum on error (4s delay + 1s showing)
      const elapsed = Date.now() - thinkingStartTime;
      if (elapsed < minThinkingTime) {
        await new Promise(resolve => setTimeout(resolve, minThinkingTime - elapsed));
      }

      // Clear thinking message timer and interval
      if (this.thinkingMessageTimer) {
        clearTimeout(this.thinkingMessageTimer);
        this.thinkingMessageTimer = null;
      }
      if (this.thinkingInterval) {
        clearInterval(this.thinkingInterval);
        this.thinkingInterval = null;
      }

      // Always hide the thinking label (whether it was shown or not)
      const label = document.getElementById('instruction-label');
      if (label) {
        label.classList.add('hidden');
        label.style.backgroundColor = '';
        label.style.color = '';
        label.style.fontWeight = '';
        label.textContent = '';
      }

      // Hide thinking indicator and re-enable input on error
      this.showBotThinking(false);
      this.setInputEnabled(true);
      // Bot error - no notification needed

      // Error handled - cleanup done
    } finally {
      // Reset flag only after ALL operations are complete
      ChessUI._globalBotProcessing = false;
    }
  }

  // Cancel bot thinking when user interrupts (e.g., undo)
  cancelBotThinking() {
    // Note: Web Worker cancellation removed since we no longer use Web Workers
    // Bot thinking can still be interrupted via timers and flags

    // Clear bot turn timer (prevents delayed bot execution)
    if (this.botTurnTimer) {
      clearTimeout(this.botTurnTimer);
      this.botTurnTimer = null;
    }

    // Clear thinking message timer
    if (this.thinkingMessageTimer) {
      clearTimeout(this.thinkingMessageTimer);
      this.thinkingMessageTimer = null;
    }

    // Clear thinking interval (stops message rotation)
    if (this.thinkingInterval) {
      clearInterval(this.thinkingInterval);
      this.thinkingInterval = null;
    }

    // Reset global bot processing flag
    ChessUI._globalBotProcessing = false;

    // Hide thinking UI immediately
    this.showBotThinking(false);

    // Hide instruction label
    const label = document.getElementById('instruction-label');
    if (label) {
      label.classList.add('hidden');
      label.style.backgroundColor = '';
      label.style.color = '';
      label.style.fontWeight = '';
      label.textContent = '';
    }

    // Clear any selected piece to prevent auto-moves
    if (this.game) {
      this.game.selectedSquare = null;
      this.game.possibleMoves = [];
    }
    // Highlights will be cleared by updateDisplay() after undo

    // Re-enable user input
    this.setInputEnabled(true);

    // Mark that we've cancelled the bot (so we can bypass turn validation)
    this.botCancelled = true;

    // Also mark it in the game state so it persists
    if (this.game) {
      // Bot cancellation - setting flag
      this.game.botWasCancelled = true;
    }

    // Set flag to prevent immediate selection on next click
    this.justCancelledBot = true;

    // Clear this flag after a short delay
    setTimeout(() => {
      this.justCancelledBot = false;
    }, 500);

    // NUCLEAR OPTION: Keep clearing selectedSquare repeatedly
    // This catches any async state restoration
    const clearingInterval = setInterval(() => {
      if (this.game && this.game.selectedSquare) {
        this.game.selectedSquare = null;
        this.game.possibleMoves = [];
      }
    }, 50);

    // Stop clearing after 1 second
    setTimeout(() => {
      clearInterval(clearingInterval);
    }, 1000);
  }

  // Enable/disable user input
  setInputEnabled(enabled) {
    this.inputEnabled = enabled;

    // Visual feedback for disabled state
    if (enabled) {
      this.boardElement.style.opacity = '1';
      this.boardElement.style.pointerEvents = 'auto';
    } else {
      this.boardElement.style.opacity = '0.7';
      this.boardElement.style.pointerEvents = 'none';
    }
  }

  // Enhanced bot thinking indicator with state synchronization and styling
  showBotThinking(show) {
    const gameMode = this.game.gameMode;
    const isBotTurn = this.game.isBotTurn();
    const gameStatus = this.game.gameStatus;

    const instructionLabel = document.getElementById('instruction-label');
    const moveDisplay = document.getElementById('move-display');

    if (show && gameMode === 'human-vs-bot' && isBotTurn && (gameStatus === 'playing' || gameStatus === 'check')) {
      // Don't hide instruction label if it contains bot thinking message
      if (instructionLabel && !instructionLabel.textContent.includes('analyzing deeply')) {
        this.hideInstructionLabel();
      }

      // Add spinner to move display
      if (moveDisplay && !document.querySelector('.bot-thinking-spinner')) {
        const spinner = document.createElement('div');
        spinner.className = 'bot-thinking-spinner';
        moveDisplay.parentElement.appendChild(spinner);
      }

      // Ensure input is disabled when bot is thinking
      if (this.inputEnabled) {
        this.setInputEnabled(false);
      }

      // Update turn indicator to reflect bot thinking state
      this.updatePlayerTurnIndicator(this.game.currentPlayer, gameMode);

    } else {
    // console.log(`[showBotThinking] Hiding thinking indicator, showingBotDialogue: ${this.showingBotDialogue}, pendingBotDialogue: ${this.pendingBotDialogue}`);
      // Don't hide instruction label if we're showing or about to show a bot dialogue
      if (!this.showingBotDialogue && !this.pendingBotDialogue) {
        this.hideInstructionLabel();
      }

      // Remove spinner
      const spinner = document.querySelector('.bot-thinking-spinner');
      if (spinner) {
        spinner.remove();
      }

      // Update turn indicator when thinking stops
      if (gameMode === 'human-vs-bot') {
        this.updatePlayerTurnIndicator(this.game.currentPlayer, gameMode);
      }
    }
  }

  hideInstructionLabel() {
    const instructionLabel = document.getElementById('instruction-label');
    if (instructionLabel) {
      instructionLabel.classList.add('hidden');
      instructionLabel.textContent = '';
    }
  }

  // Enhanced UI feedback system for game state transitions
  handleGameEnd() {
    const gameStatus = this.game.gameStatus;
    const currentPlayer = this.game.currentPlayer;

    // Disable all input
    this.setInputEnabled(false);

    // Determine if player won for sound effects
    let isVictory = false;

    if (gameStatus === 'checkmate') {
      const winner = currentPlayer === 'white' ? 'Black' : 'White';
      if (this.game.gameMode === 'human-vs-bot') {
        if ((this.game.humanColor === 'white' && winner === 'White') ||
            (this.game.humanColor === 'black' && winner === 'Black')) {
          isVictory = true;
        }
        // Show bot dialogue for game end
        setTimeout(() => {
          if (isVictory) {
            this.game.showBotDialogue('humanWins', true);
          } else {
            this.game.showBotDialogue('botWins', true);
          }
        }, 1000);
      } else {
        // In human vs human, show king victory dialogue
        isVictory = true;
        setTimeout(() => {
          this.game.showBotDialogue('humanWins', true); // Use enhanced showBotDialogue for consistency
        }, 1000);
      }
    }

    // Game status is already shown in header, no notification needed

    // Play appropriate sound
    if (this.game.soundEnabled && this.game.sounds) {
      if (isVictory) {
        this.game.sounds.victory();
      } else {
        this.game.sounds.gameEnd();
      }
    }
  }

  // Show game end message with enhanced visual feedback
  // showGameEndMessage removed - game status shown in header

  // Enhanced game state feedback
  updateGameStateIndicators() {
    const gameStatus = this.game.gameStatus;
    const currentPlayer = this.game.currentPlayer;
    const gameMode = this.game.gameMode;

    // Update player turn indicator
    this.updatePlayerTurnIndicator(currentPlayer, gameMode);

    // Update captured pieces display
    this.updateCapturedPiecesDisplay();

    // Update move history display
    this.updateMoveHistoryDisplay();
  }

  // Enhanced player turn indicator with synchronized bot state
  updatePlayerTurnIndicator(currentPlayer, gameMode) {
    const turnIndicator = document.getElementById('current-player');
    if (!turnIndicator) return;

    // Calculate material balance to include in display
    let balanceText = '';
    try {
      const materialBalance = this.game.calculateMaterialBalance();

      // Show positive for current player if they have advantage, negative if disadvantage
      if (currentPlayer === 'white') {
        if (materialBalance > 0) {
          balanceText = ` (+${materialBalance})`;
        } else if (materialBalance < 0) {
          balanceText = ` (${materialBalance})`;
        }
      } else {
        // For black player, flip the sign
        if (materialBalance < 0) {
          balanceText = ` (+${Math.abs(materialBalance)})`;
        } else if (materialBalance > 0) {
          balanceText = ` (-${materialBalance})`;
        }
      }
    } catch (e) {
      // If material balance calculation fails, just skip it
      
    }

    let message = '';
    let indicatorClass = `player-indicator ${currentPlayer}`;

    if (gameMode === 'human-vs-bot') {
      const humanColor = this.game.getHumanColor();
      const isBotTurn = this.game.isBotTurn();
      const gameStatus = this.game.gameStatus;

      if (gameStatus === 'checkmate' || gameStatus === 'stalemate') {
        // Game actually ended - show final state
        message = `Game Over (${gameStatus})`;
        indicatorClass += ' game-ended';
      } else if (gameStatus === 'check') {
        // In check but not game over
        if (isBotTurn) {
          message = `Bot's turn`;
          indicatorClass += ' bot-turn check';
        } else {
          message = `Your turn`;
          indicatorClass += ' human-turn check';
        }
      } else if (isBotTurn) {
        // Check if bot is currently thinking
        const instructionLabel = document.getElementById('instruction-label');
        const isBotThinking = instructionLabel &&
                             !instructionLabel.classList.contains('hidden') &&
                             instructionLabel.textContent.includes('Bot is thinking');

        if (isBotThinking) {
          message = `Bot is thinking...`;
          indicatorClass += ' bot-thinking';
        } else {
          message = `Bot's turn`;
          indicatorClass += ' bot-turn';
        }
      } else {
        // Human's turn
        message = `Your turn`;
        indicatorClass += ' human-turn';
      }
    } else {
      // Human vs Human mode - no bot difficulty needed
      message = `${currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1)}'s turn`;
    }

    turnIndicator.textContent = message;
    turnIndicator.className = indicatorClass;
    
    }

  // Update captured pieces display
  updateCapturedPiecesDisplay() {
    const capturedContainer = document.getElementById('captured-pieces');
    if (!capturedContainer) {

      return;
    }

    const { whiteCaptured, blackCaptured } = this.game.getCapturedPieces();
    const gameMode = this.game.gameMode;
    const humanColor = this.game.getHumanColor();

    // Clear existing content
    capturedContainer.innerHTML = '';

    // Update the existing material balance bar (don't create a new one)
    const materialBalance = this.game.calculateMaterialBalance();
    this.updateMaterialBalanceBar(materialBalance, gameMode, humanColor);

    // Create left and right sections
    const leftSection = document.createElement('div');
    leftSection.className = 'captured-section left';

    const rightSection = document.createElement('div');
    rightSection.className = 'captured-section right';

    if (gameMode === 'human-vs-bot') {
      // Human vs Bot mode - show "White" and "Black" based on who plays which color
      const humanIsWhite = humanColor === 'white';
      const whitePieces = humanIsWhite ? blackCaptured : whiteCaptured;
      const blackPieces = humanIsWhite ? whiteCaptured : blackCaptured;

      // White section - always show label
      const whiteLabel = document.createElement('span');
      whiteLabel.className = 'captured-label';
      whiteLabel.textContent = 'White';
      leftSection.appendChild(whiteLabel);

      const whitePiecesList = document.createElement('span');
      whitePiecesList.className = 'captured-pieces-list';
      if (whitePieces.length > 0) {
        whitePiecesList.innerHTML = whitePieces.map(p =>
          `<span class="captured-piece captured-${p.type}">${this.game.getPieceSymbol(p)}</span>`
        ).join('');
      } else {
        whitePiecesList.textContent = '-';
      }
      leftSection.appendChild(whitePiecesList);
      leftSection.dataset.pieceCount = whitePieces.length;

      // Black section - always show label
      const blackLabel = document.createElement('span');
      blackLabel.className = 'captured-label';
      blackLabel.textContent = 'Black';
      rightSection.appendChild(blackLabel);

      const blackPiecesList = document.createElement('span');
      blackPiecesList.className = 'captured-pieces-list';
      if (blackPieces.length > 0) {
        blackPiecesList.innerHTML = blackPieces.map(p =>
          `<span class="captured-piece captured-${p.type}">${this.game.getPieceSymbol(p)}</span>`
        ).join('');
      } else {
        blackPiecesList.textContent = '-';
      }
      rightSection.appendChild(blackPiecesList);
      rightSection.dataset.pieceCount = blackPieces.length;
    } else {
      // Human vs Human mode - show "White" and "Black"
      // White section - always show label
      const whiteLabel = document.createElement('span');
      whiteLabel.className = 'captured-label';
      whiteLabel.textContent = 'White';
      leftSection.appendChild(whiteLabel);

      const whitePieces = document.createElement('span');
      whitePieces.className = 'captured-pieces-list';
      if (blackCaptured.length > 0) {
        whitePieces.innerHTML = blackCaptured.map(p =>
          `<span class="captured-piece captured-${p.type}">${this.game.getPieceSymbol(p)}</span>`
        ).join('');
      } else {
        whitePieces.textContent = '-';
      }
      leftSection.appendChild(whitePieces);
      leftSection.dataset.pieceCount = blackCaptured.length;

      // Black section - always show label
      const blackLabel = document.createElement('span');
      blackLabel.className = 'captured-label';
      blackLabel.textContent = 'Black';
      rightSection.appendChild(blackLabel);

      const blackPieces = document.createElement('span');
      blackPieces.className = 'captured-pieces-list';
      if (whiteCaptured.length > 0) {
        blackPieces.innerHTML = whiteCaptured.map(p =>
          `<span class="captured-piece captured-${p.type}">${this.game.getPieceSymbol(p)}</span>`
        ).join('');
      } else {
        blackPieces.textContent = '-';
      }
      rightSection.appendChild(blackPieces);
      rightSection.dataset.pieceCount = whiteCaptured.length;
    }

    // Always append sections for consistent spacing
    const sectionsWrapper = document.createElement('div');
    sectionsWrapper.className = 'captured-sections-wrapper';
    sectionsWrapper.appendChild(leftSection);
    sectionsWrapper.appendChild(rightSection);
    capturedContainer.appendChild(sectionsWrapper);

    capturedContainer.style.display = 'flex';
  }

  // Create material balance progress bar
  createMaterialBalanceBar(balance, gameMode, humanColor) {
    const barContainer = document.createElement('div');
    barContainer.className = 'material-balance-bar';

    // Normalize balance to 0-100% scale (50% = balanced)
    // Material balance ranges from -39 (black advantage) to +39 (white advantage)
    const percentage = Math.max(0, Math.min(100, ((balance + 39) / 78) * 100));

    const indicator = document.createElement('div');
    // Set initial className with appropriate advantage class to prevent color flash
    let className = 'balance-indicator';
    if (gameMode === 'human-vs-bot') {
      const humanAdvantage = (humanColor === 'white' && balance > 0) ||
                            (humanColor === 'black' && balance < 0);
      if (humanAdvantage) {
        className += ' human-advantage';
      } else if (balance !== 0) {
        className += ' bot-advantage';
      }
    }
    indicator.className = className;
    indicator.style.width = `${percentage}%`;

    barContainer.appendChild(indicator);
    return barContainer;
  }

  // Update existing material balance bar in DOM
  updateMaterialBalanceBar(balance, gameMode, humanColor) {
    const indicator = document.getElementById('balance-indicator');
    if (!indicator) {
      return;
    }

    // Normalize balance to 0-100% scale (50% = balanced)
    // Material balance ranges from -39 (black advantage) to +39 (white advantage)
    const percentage = Math.max(0, Math.min(100, ((balance + 39) / 78) * 100));

    // Set className with appropriate advantage class
    let className = 'balance-indicator';
    if (gameMode === 'human-vs-bot') {
      const humanAdvantage = (humanColor === 'white' && balance > 0) ||
                            (humanColor === 'black' && balance < 0);
      if (humanAdvantage) {
        className += ' human-advantage';
      } else if (balance !== 0) {
        className += ' bot-advantage';
      }
    }

    indicator.className = className;
    indicator.style.width = `${percentage}%`;
  }

  // Enhanced move history display
  updateMoveHistoryDisplay() {
    const moveHistoryElement = document.getElementById('move-history');
    if (!moveHistoryElement || this.game.currentStateIndex <= 0) return;

    // Use stateHistory instead of moveHistory for correct order after undo/redo
    const validStates = this.game.stateHistory.slice(1, this.game.currentStateIndex + 1);
    const recentMoves = validStates.slice(-6); // Show last 6 moves
    let historyHTML = '<div class="move-history-title">Recent Moves:</div>';

    recentMoves.forEach((state, index) => {
      // Determine if bot move based on whose turn it was
      const moveNumber = validStates.indexOf(state) + 1;
      const isBotMove = (this.game.gameMode === 'human-vs-bot' &&
                        state.move && state.move.piece &&
                        state.move.piece.color !== this.game.humanColor);
      const moveClass = isBotMove ? 'bot-move' : 'human-move';
      const playerIcon = isBotMove ? '🤖' : '👤';

      historyHTML += `
        <div class="move-entry ${moveClass}">
          <span class="move-player">${playerIcon}</span>
          <span class="move-notation">${state.notation}</span>
          <span class="move-number">#${moveNumber}</span>
        </div>
      `;
    });

    moveHistoryElement.innerHTML = historyHTML;
  }

  // Enhanced bot initialization for both human white/black scenarios
  checkInitialBotTurn() {


    // For Human vs Human, just enable input and return
    if (this.game.gameMode !== 'human-vs-bot') {
      this.setInputEnabled(true);
      this.showBotThinking(false);
      this.updateGameStateIndicators();
      return;
    }

    const humanColor = this.game.getHumanColor();
    const currentPlayer = this.game.currentPlayer;
    const isBotTurn = this.game.isBotTurn();
    const moveCount = this.game.moveHistory ? this.game.moveHistory.length : 0;

    // If moves have already been made, don't try to make initial bot move
    if (moveCount > 0) {
      
      return;
    }

    // Ensure game is not ended
    if (this.game.gameStatus === 'checkmate' || this.game.gameStatus === 'stalemate') {
      return;
    }

    // CRITICAL: Ensure game status is 'playing' before attempting bot move
    // This prevents the "bot move failed" error
    if (this.game.gameStatus !== 'playing') {
      
      setTimeout(() => {
        this.checkInitialBotTurn();
      }, 500);
      return;
    }

    // Check if bot should make the first move
    if (isBotTurn) {
      
      // Show bot thinking immediately
      this.showBotThinking(true);
      this.setInputEnabled(false);

      // Ensure UI is properly updated before bot move
      this.updateGameStateIndicators();

      // Execute bot move with a delay to ensure everything is ready
      // Clear any existing bot turn timer
      if (this.botTurnTimer) {
        clearTimeout(this.botTurnTimer);
        this.botTurnTimer = null;
      }

      this.botTurnTimer = setTimeout(() => {
        // Double-check conditions haven't changed
        const stillBotTurn = this.game.isBotTurn();
        const stillNoMoves = !this.game.moveHistory || this.game.moveHistory.length === 0;

        if (this.game.gameStatus === 'playing' && stillBotTurn && stillNoMoves) {

          this.handleBotTurn();
        } else {
          
          // Reset UI if bot already moved
          if (!stillNoMoves) {
            this.showBotThinking(false);
            this.setInputEnabled(true);
            this.updateGameStateIndicators();
          }
        }
      }, 1000); // Reduced delay since we have better checks
    } else {
      // Ensure human can make moves
      this.setInputEnabled(true);
      this.showBotThinking(false);

      // Update UI to show it's human's turn
      this.updateGameStateIndicators();
    }
  }

  // Handle new game start
  onNewGameStart() {
    this.updateDisplay();

    // Only check for initial bot turn if no moves have been made yet
    if (!this.game.moveHistory || this.game.moveHistory.length === 0) {
      this.checkInitialBotTurn();
    }
  }

  async handleSquareSelection(row, col) {
    // Prevent interactions during board flip or when input is disabled
    if (this.isFlipping || this.inputEnabled === false) {
      // Input disabled - no notification needed
      return;
    }

    // REMOVED: This was clearing selectedSquare on EVERY click after bot cancellation!
    // The clearing should only happen once, not on every click
    // if (this.botCancelled || this.game.botWasCancelled) {
    //   this.game.selectedSquare = null;
    //   this.game.possibleMoves = [];
    // }

    // Prevent auto-selection immediately after bot cancellation
    // But only if there was a previously selected square that might auto-move
    if (this.justCancelledBot) {
      this.justCancelledBot = false;
      // Only block if there's a risk of auto-move (i.e., selectedSquare exists)
      if (this.game.selectedSquare) {
        this.game.selectedSquare = null;
        this.game.possibleMoves = [];
        this.updateDisplay();
        return;
      }
      // If no selected square, allow the click to proceed normally
    }

    // In human-vs-bot mode, prevent human from moving during bot's turn
    // BUT allow moves if bot was cancelled via undo
    if (this.game.gameMode === 'human-vs-bot' && this.game.isBotTurn() && !this.botCancelled && !this.game.botWasCancelled) {
      // If we're in undo/redo state, allow the user to make a move for bot
      if (this.game.isInUndoRedoState) {
        // Convert display coordinates to logical coordinates first
        const logical = this.getLogicalCoordinates(row, col);
        const logicalRow = logical.row;
        const logicalCol = logical.col;

        // Check if user is clicking on their own piece
        const piece = this.game.board[logicalRow][logicalCol];

        // In undo state - no notification needed

        // Only proceed with piece selection if they clicked their own piece
        if (piece && piece.color === this.game.humanColor) {
          // User is selecting their own piece
          // DON'T clear the flags yet - only clear when they actually make a move
          // This keeps the message showing even after selecting a piece
          // Continue to piece selection logic below
        } else {
          // User clicked empty square or bot piece - keep showing message
          // Don't clear any flags, keep showing the same message
          return;
        }
      } else {
        // Bot's turn - no notification needed
        return;
      }
    }
    
    // Convert display coordinates to logical coordinates
    const logical = this.getLogicalCoordinates(row, col);
    const logicalRow = logical.row;
    const logicalCol = logical.col;

    // Piece selection logic

    if (this.game.selectedSquare) {
      const fromRow = this.game.selectedSquare.row;
      const fromCol = this.game.selectedSquare.col;

      // Get piece at selected square
      const selectedPiece = this.game.board[fromRow][fromCol];

      if (fromRow === logicalRow && fromCol === logicalCol) {
        // Deselect if clicking same square
        this.game.selectedSquare = null;
      } else {
        // Check if the attempted move is valid before trying to make it
        const possibleMoves = this.game.getPossibleMoves(fromRow, fromCol);
        const attemptedMove = possibleMoves.find(m => m.row === logicalRow && m.col === logicalCol);

        if (attemptedMove) {
          // Move is valid, attempt to make it
          const wasInCheck = this.game.gameStatus === 'check';
          const moveResult = await this.game.makeMove(fromRow, fromCol, logicalRow, logicalCol);
          if (moveResult && moveResult.success) {

            // Clear undo/redo flags now that a move was successfully made
            this.game.isInUndoRedoState = false;
            this.game.lastUndoWasBotMove = false;

            // CRITICAL: Clear bot cancelled flags since we've made a successful move
            // This ensures the bot will run on the next turn
            this.botCancelled = false;
            this.game.botWasCancelled = false;

            this.game.selectedSquare = null;

            // Orientation is now handled automatically in makeMove()

            // Check if we need to show check alert
            if (moveResult.enteredCheck) {
              // Someone just entered check - status shown in header
              // After a move, currentPlayer has switched to the opponent
              // So we need to highlight the opponent's king (who is now in check)
              this.highlightKing(this.game.currentPlayer);
            }

            // Handle post-move actions based on game mode
            if (this.game.gameMode === 'human-vs-human' && !this.game.isUndoRedoAction) {
              // Orientation already determined above, no need for setTimeout
              // Just update display if needed later
            } else if (this.game.gameMode === 'human-vs-bot' && !this.game.isUndoRedoAction) {
              // In vs Bot mode, board remains static - no flipping
              
              // Check if game is still in progress and it's bot's turn
              // Bot should play when status is 'playing' OR 'check' (not checkmate/stalemate)
              const statusOk = this.game.gameStatus === 'playing' || this.game.gameStatus === 'check';
              const isBotTurn = this.game.isBotTurn();
              
              if (statusOk && isBotTurn) {
                // Show bot thinking message immediately after human move
                this.showBotThinking(true);
                this.setInputEnabled(false);
                
                // Update UI to reflect bot's turn
                this.updateGameStateIndicators();

                // Clear any existing bot turn timer
                if (this.botTurnTimer) {
                  clearTimeout(this.botTurnTimer);
                  this.botTurnTimer = null;
                }

                // Set flag immediately when scheduling to prevent duplicate scheduling
                if (!ChessUI._globalBotProcessing) {
                  ChessUI._globalBotProcessing = true;
                  // Trigger bot move with small delay to allow UI update
                  this.botTurnTimer = setTimeout(() => {
                    // Flag is already set, just call handleBotTurn
                    this.handleBotTurn();
                  }, 150);
                } else {
                  // Bot already processing, skipping bot turn scheduling
                }
              } else {
                
                // Ensure input is enabled if game ended
                if (this.game.gameStatus === 'checkmate' || this.game.gameStatus === 'stalemate') {
                  this.setInputEnabled(false); // Disable for game end
                } else {
                  this.setInputEnabled(true); // Enable if still human's turn somehow
                }
              }
            }
            
            // Auto-save is now handled in makeMove method
          } else {
            // This shouldn't happen if move was in possibleMoves, but handle gracefully
            this.game.selectedSquare = null;
          }
        } else {
          // Move is not in possible moves
          // Move is not in possible moves
          // Check if clicking own piece for selection
          const targetPiece = this.game.board[logicalRow][logicalCol];
          
          if (targetPiece && targetPiece.color === this.game.currentPlayer) {
            // This is piece selection, not a move attempt
            // Select the piece
            this.game.selectedSquare = { row: logicalRow, col: logicalCol };
            this.updateDisplay(); // Update display before returning
            return; // Exit early - no need for move validation
          }
          
          // Move is invalid (js-chess-engine already handles all validation including check)
          // Check if we're currently in check to show appropriate message
          if (this.game.isInCheck()) {
            // Player is currently in check and this move doesn't resolve it - status shown in header
            // this.showCheckAlert("You're in check! Must move to safety.");
            this.highlightKing(this.game.currentPlayer);
          } else {
            // Move is simply invalid - just deselect
            // The engine already prevents all illegal moves including those that would put king in check
            this.game.selectedSquare = null;
          }
        }
      }
    } else {
      // Select piece if it belongs to current player
      const piece = this.game.board[logicalRow][logicalCol];

      // FIX: When bot is cancelled, allow selecting human pieces regardless of whose turn it is
      const canSelectPiece = (this.botCancelled || this.game.botWasCancelled)
        ? (piece && piece.color === this.game.humanColor)  // After bot cancel, select human pieces
        : (piece && piece.color === this.game.currentPlayer); // Normal: select current player's pieces


      if (canSelectPiece) {
        this.game.selectedSquare = { row: logicalRow, col: logicalCol };
      } else {
      }
    }
    
    this.updateDisplay();
  }

  updateDisplay() {
    // Debug logging for undo issue
    // Specific debug for E7 and E5 positions
    

    // Apply orientation data attributes - robust single source of truth
    const gameContainer = document.getElementById('game-container');

    // Remove old classes (temporary - for backwards compatibility during transition)
    gameContainer.classList.remove('orientation-table', 'orientation-handoff', 'orientation-none');

    // Set data attributes that determine orientation
    // For bot mode, use 'none' to prevent CSS rotation (coordinate reversal handles it)
    const orientationMode = this.game.gameMode === 'human-vs-bot' ?
                           'none' : this.game.orientationMode;

    gameContainer.setAttribute('data-orientation-mode', orientationMode);
    gameContainer.setAttribute('data-board-flipped', this.game.boardFlipped.toString());
    gameContainer.setAttribute('data-game-mode', this.game.gameMode);
    gameContainer.setAttribute('data-current-player', this.game.currentPlayer);

    // Remove old class-based logic entirely - data attributes handle everything now
    // The CSS will use the data attributes to determine transforms

    // Update board pieces
    const squares = this.boardElement.children;
    for (let i = 0; i < squares.length; i++) {
      const square = squares[i];
      const displayRow = parseInt(square.dataset.row);
      const displayCol = parseInt(square.dataset.col);

      // Convert display coordinates to logical coordinates
      const logical = this.getLogicalCoordinates(displayRow, displayCol);
      const piece = this.game.board[logical.row][logical.col];
      
      // Clear previous content and classes
      square.innerHTML = '';
      square.classList.remove('selected', 'valid-move', 'white-move', 'black-move', 'last-move');
      
      // Add piece
      if (piece) {
        const pieceElement = document.createElement('div');
        pieceElement.className = `chess-piece ${piece.color}`;
        pieceElement.setAttribute('data-piece', piece.type); // Add piece type for CSS targeting
        pieceElement.textContent = this.game.getPieceSymbol(piece);

        // Slightly raise the king piece
        if (piece.type === 'king') {
          pieceElement.style.position = 'relative';
          pieceElement.style.top = '-1px';
        }

        square.appendChild(pieceElement);

        // Debug logging for key positions
        if ((logical.row === 1 && logical.col === 4) || (logical.row === 3 && logical.col === 4)) {
          
        }
      }
      
      // Highlight selected square
      if (this.game.selectedSquare && 
          this.game.selectedSquare.row === logical.row && 
          this.game.selectedSquare.col === logical.col) {
        square.classList.add('selected');
      }
      
      // Highlight valid moves
      if (this.game.selectedSquare) {
        const moves = this.game.getPossibleMoves(this.game.selectedSquare.row, this.game.selectedSquare.col);
        if (moves.some(move => move.row === logical.row && move.col === logical.col)) {
          square.classList.add('valid-move');
          // Add player-specific border color
          square.classList.add(this.game.currentPlayer === 'white' ? 'white-move' : 'black-move');
        }
      }
      
      // Highlight last move (based on current position in state history)
      // Use stateHistory instead of old moveHistory
      if (this.game.currentStateIndex > 0 && this.game.currentStateIndex < this.game.stateHistory.length) {
        const currentState = this.game.stateHistory[this.game.currentStateIndex];
        if (currentState && currentState.move) {
          const lastMove = currentState.move;
          if ((lastMove.from.row === logical.row && lastMove.from.col === logical.col) ||
              (lastMove.to.row === logical.row && lastMove.to.col === logical.col)) {
            square.classList.add('last-move');
          }
        }
      }
    }
    
    // Update game info with material balance
    const materialBalance = this.game.calculateMaterialBalance();
    let balanceText = '';
    
    // Show positive for current player if they have advantage, negative if disadvantage
    if (this.game.currentPlayer === 'white') {
      if (materialBalance > 0) {
        balanceText = ` (+${materialBalance})`;
      } else if (materialBalance < 0) {
        balanceText = ` (${materialBalance})`;
      }
    } else {
      // For black player, flip the sign
      if (materialBalance < 0) {
        balanceText = ` (+${Math.abs(materialBalance)})`;
      } else if (materialBalance > 0) {
        balanceText = ` (-${materialBalance})`;
      }
    }
    
    // Update simplified header display
    const moveDisplayElement = document.getElementById('move-display');
    const moveInfo = document.getElementById('move-info');

    if (moveDisplayElement) {
      let displayText = '';

      // Check if there's a move to display
      if (this.game.currentStateIndex > 0 && this.game.currentStateIndex < this.game.stateHistory.length) {
        const currentState = this.game.stateHistory[this.game.currentStateIndex];
        if (currentState && currentState.move) {
          const commentary = currentState.commentary || currentState.notation;

          // Add game status if applicable
          let statusText = '';
          if (this.game.gameStatus === 'checkmate') {
            statusText = '<span style="color: #FE5F00;"> - Checkmate!</span>';
          } else if (this.game.gameStatus === 'check') {
            statusText = '<span style="color: #FE5F00;"> - Check!</span>';
          } else if (this.game.gameStatus === 'stalemate') {
            statusText = '<span style="color: #FE5F00;"> - Stalemate!</span>';
          }

          displayText = commentary + statusText;
        }
      }

      // If no move yet, show initial state with game mode
      if (!displayText) {
        if (this.game.gameMode === 'human-vs-human') {
          displayText = 'Human vs Human • Ready to play';
        } else {
          const difficulty = this.game.getBotDifficultyText();
          displayText = `Bot (${difficulty}) • Ready to play`;
        }
      }

      // Use innerHTML to support colored status text
      if (displayText.includes('<span')) {
        moveDisplayElement.innerHTML = displayText;
      } else {
        moveDisplayElement.textContent = displayText;
      }

      // Expand button removed - overflow handling no longer needed
    }
    
    // Game status is now displayed inline with move commentary, so clear the separate status element
    this.gameStatusElement.textContent = '';
    
    // Enhanced UI feedback for game state
    this.updateGameStateIndicators();
    
    // Check for game end conditions and provide feedback
    if (this.game.gameStatus !== 'playing' && this.game.gameStatus !== 'check') {
      // Small delay to allow move animation to complete
      setTimeout(() => {
        this.handleGameEnd();
      }, 300);
    }
  }

  applyTheme() {
    // Fixed classic wooden theme with detailed textures
    const classicTheme = { 
      light: '#ddb88c', 
      dark: '#a0522d',
      lightTexture: 'radial-gradient(circle at 25% 25%, #c9a876 0%, transparent 50%), radial-gradient(circle at 75% 75%, #c9a876 0%, transparent 50%)',
      darkTexture: 'radial-gradient(circle at 25% 25%, #8b4513 0%, transparent 50%), radial-gradient(circle at 75% 75%, #8b4513 0%, transparent 50%)'
    };
    
    document.documentElement.style.setProperty('--light-square', classicTheme.light);
    document.documentElement.style.setProperty('--dark-square', classicTheme.dark);
    
    // Apply colors and textures to squares
    const squares = this.boardElement.children;
    for (let i = 0; i < squares.length; i++) {
      const square = squares[i];
      const row = parseInt(square.dataset.row);
      const col = parseInt(square.dataset.col);
      const isLight = (row + col) % 2 === 0;
      
      if (isLight) {
        square.style.backgroundColor = classicTheme.light;
        square.style.backgroundImage = classicTheme.lightTexture;
      } else {
        square.style.backgroundColor = classicTheme.dark;
        square.style.backgroundImage = classicTheme.darkTexture;
      }
    }
  }

  // showMessage removed - no longer needed

  showOptionsMenu() {
    const overlay = document.getElementById('options-overlay');
    if (overlay) {
      // Check if menu is already visible
      if (!overlay.classList.contains('hidden')) {
        return; // Menu already visible, don't show again
      }
      overlay.classList.remove('hidden');
      this.menuOpen = true;

      // Pause bot thinking timers if they're running
      this.pauseBotTimers();

      // Track the original game mode when menu opens (only if not already tracking)
      if (this.game.originalGameMode === undefined) {
        this.game.originalGameMode = this.game.gameMode;
      }

      // Update original values for current mode if not already tracking changes
      if (this.game.gameMode === 'human-vs-bot' && this.game.modeSettings['human-vs-bot']) {
        const settings = this.game.modeSettings['human-vs-bot'];
        if (!settings.colorChangedMidGame) {
          settings.originalHumanColor = this.game.humanColor;
        }
        if (!settings.difficultyChangedMidGame) {
          settings.originalBotDifficulty = this.game.botDifficulty;
        }
      }

      // Always scroll to top when opening options menu
      const optionsMenu = document.getElementById('options-menu');
      if (optionsMenu) {
        optionsMenu.scrollTop = 0;
      }

      // Update button states
      this.updateOptionsButtons();

      // Clean up any existing listeners first
      this.removeOptionsEventListeners();

      // Add fresh event listeners
      this.setupOptionsEventListeners();
    }
  }

  hideOptionsMenu() {
    const overlay = document.getElementById('options-overlay');
    if (overlay) {
      overlay.classList.add('hidden');
    }
    this.menuOpen = false;

    // Clean up event listeners to prevent memory leak
    this.removeOptionsEventListeners();

    // Resume bot timers if they were paused
    this.resumeBotTimers();

    // Apply correct orientation when menu closes using deterministic logic
    const shouldFlip = this.game.determineOrientation();
    if (this.game.boardFlipped !== shouldFlip) {
      this.game.boardFlipped = shouldFlip;
      this.updateDisplay();
    }

    // Restore the bot/human dialogue area when returning to game
    const dialogueArea = document.getElementById('bot-dialogue-area');
    if (dialogueArea && dialogueArea.classList.contains('hidden')) {
      // Check if there's a game in progress (has moves)
      const hasGameInProgress = this.game.stateHistory && this.game.stateHistory.length > 1;

      if (hasGameInProgress || this.game.gameStatus === 'playing') {
        // Restore the actual dialogue text from currentDialogue
        const dialogueText = this.game.currentDialogue?.text || "";

        if (this.game.gameMode === 'human-vs-bot') {
          // Show the bot dialogue area with current bot and saved text
          const botName = this.game.getBotDifficultyText();
          this.showBotDialoguePersistent(dialogueText, botName);
        } else if (this.game.gameMode === 'human-vs-human') {
          // Show the human dialogue area with saved text
          this.showBotDialoguePersistent(dialogueText, 'Human');
        }
      }
    }

    // Check if bot should make initial move after returning from options
    // This handles the case where user changed color and clicked "Back to game"
    if (this.game.gameMode === 'human-vs-bot' && this.game.moveHistory.length === 0) {

      // Use a small delay to let UI settle
      setTimeout(() => {
        this.checkInitialBotTurn();
      }, 100);
    }
  }

  updateOptionsButtons() {
    // Debug: Show current mode in the menu title
    const optionsTitle = document.getElementById('options-title');
    if (optionsTitle) {
      const modeText = this.game.gameMode === 'human-vs-human' ? 'Human vs Human' : 'Human vs Bot';
      optionsTitle.textContent = `Chess R1 - ${modeText}`;
    }

    // Update back button state - disable if color/difficulty changed mid-game or no moves made
    const backBtn = document.getElementById('back-btn');
    const newGameBtn = document.getElementById('new-game-btn');

    if (backBtn) {
      // Check both moveHistory and stateHistory for moves (stateHistory > 1 means has moves)
      const hasMoveHistory = this.game.moveHistory && this.game.moveHistory.length > 0;
      const hasStateHistory = this.game.stateHistory && this.game.stateHistory.length > 1;
      const hasMoves = hasMoveHistory || hasStateHistory;

      const modeChanged = this.game.gameMode !== this.game.originalGameMode;

      // Get settings changes for current mode
      let colorChanged = false;
      let difficultyChanged = false;
      if (this.game.gameMode === 'human-vs-bot' && this.game.modeSettings['human-vs-bot']) {
        colorChanged = this.game.modeSettings['human-vs-bot'].colorChangedMidGame;
        difficultyChanged = this.game.modeSettings['human-vs-bot'].difficultyChangedMidGame;
      }

      // Settings only matter if we're in the same mode
      const settingsChangedWithinMode = (colorChanged || difficultyChanged) && !modeChanged;

      // Remove all highlight classes first
      backBtn.classList.remove('active-button');
      if (newGameBtn) {
        newGameBtn.classList.remove('active-button');
      }

      if (!hasMoves) {
        // No moves made yet in this game mode
        backBtn.disabled = true;
        backBtn.textContent = 'Back to game (no moves yet)';
        backBtn.classList.add('disabled');
        // Highlight New Game button since Back is disabled
        if (newGameBtn) {
          newGameBtn.classList.add('active-button');
        }
      } else if (settingsChangedWithinMode) {
        // Settings changed within the same mode - requires new game
        backBtn.disabled = true;
        if (colorChanged && difficultyChanged) {
          backBtn.textContent = 'Start new game (settings changed)';
        } else if (colorChanged) {
          backBtn.textContent = 'Start new game (color changed)';
        } else {
          backBtn.textContent = 'Start new game (difficulty changed)';
        }
        backBtn.classList.add('disabled');
        // Highlight New Game button since Back is disabled
        if (newGameBtn) {
          newGameBtn.classList.add('active-button');
        }
      } else {
        // Pure mode switch or no changes - can go back
        backBtn.disabled = false;
        backBtn.textContent = 'Back to game';
        backBtn.classList.remove('disabled');
        // Highlight Back to Game button since it's enabled
        backBtn.classList.add('active-button');
      }
    }
    // Update game mode radio buttons
    const gameModeRadios = document.querySelectorAll('input[name="gameMode"]');
    gameModeRadios.forEach(radio => {
      radio.checked = radio.value === this.game.gameMode;
    });
    
    // Update player color radio buttons
    const colorRadios = document.querySelectorAll('input[name="playerColor"]');
    colorRadios.forEach(radio => {
      radio.checked = radio.value === this.game.humanColor;
    });
    
    // Update sound effects radio buttons
    const soundRadios = document.querySelectorAll('input[name="soundEffects"]');
    soundRadios.forEach(radio => {
      radio.checked = (radio.value === 'on') === this.game.soundEnabled;
    });
    
    // Update undo radio buttons
    const undoRadios = document.querySelectorAll('input[name="allowUndo"]');
    undoRadios.forEach(radio => {
      radio.checked = (radio.value === 'on') === this.game.allowUndo;
    });

    // Update bot difficulty radio buttons
    const difficultyRadios = document.querySelectorAll('input[name="botDifficulty"]');
    difficultyRadios.forEach(radio => {
      radio.checked = radio.value === String(this.game.botDifficulty);
    });

    // Show/hide color group based on game mode
    const colorGroup = document.getElementById('color-group');
    
    if (colorGroup) {
      if (this.game.gameMode === 'human-vs-bot') {
        
        colorGroup.style.display = 'block';
        // Force browser to recalculate
        colorGroup.offsetHeight;
      } else {
        
        colorGroup.style.display = 'none';
      }
      
      
    }

    // Show/hide difficulty group based on game mode
    const difficultyGroup = document.getElementById('difficulty-group');
    if (difficultyGroup) {
      if (this.game.gameMode === 'human-vs-bot') {
        difficultyGroup.style.display = 'block';
        difficultyGroup.offsetHeight; // Force reflow
      } else {
        difficultyGroup.style.display = 'none';
      }
      
    }

    // Show/hide orientation mode options based on game mode
    const orientationModeGroup = document.getElementById('orientation-mode-group');
    if (orientationModeGroup) {
      if (this.game.gameMode === 'human-vs-human') {
        orientationModeGroup.style.display = 'block';
        orientationModeGroup.offsetHeight; // Force reflow
      } else {
        orientationModeGroup.style.display = 'none';
      }
      
    }

    // Show undo options for both game modes
    const undoGroup = document.getElementById('undo-group');
    if (undoGroup) {
      // Always show undo options since it works well for both modes
      undoGroup.style.display = 'block';
      undoGroup.offsetHeight; // Force reflow
      
    }

    // Update orientation mode radio selection
    const orientationModeRadios = document.querySelectorAll('input[name="orientationMode"]');
    orientationModeRadios.forEach(radio => {
      radio.checked = (radio.value === this.game.orientationMode);
    });
  }

  removeOptionsEventListeners() {
    // Remove all stored listeners
    this.optionListeners.forEach(({ element, event, handler }) => {
      if (element) {
        element.removeEventListener(event, handler);
      }
    });
    this.optionListeners = [];
  }

  pauseBotTimers() {
    // Hide bot dialogue when pausing for menu
    this.hideBotDialogue();

    // Only pause if bot is actually thinking
    if (!this.isBotProcessing) {
      return;
    }

    this.pausedTimerStates = {
      wasThinking: this.isBotProcessing,
      hadThinkingInterval: !!this.thinkingInterval,
      hadThinkingMessageTimer: !!this.thinkingMessageTimer,
      hadBotTurnTimer: !!this.botTurnTimer,
      thinkingStartTime: Date.now() // Track when we paused
    };

    // Clear all bot thinking timers
    if (this.thinkingInterval) {
      clearInterval(this.thinkingInterval);
      this.thinkingInterval = null;
    }

    if (this.thinkingMessageTimer) {
      clearTimeout(this.thinkingMessageTimer);
      this.thinkingMessageTimer = null;
    }

    if (this.botTurnTimer) {
      clearTimeout(this.botTurnTimer);
      this.botTurnTimer = null;
    }

    // Hide thinking notification while menu is open
    const label = document.getElementById('instruction-label');
    if (label && !label.classList.contains('hidden')) {
      label.classList.add('hidden');
    }
  }

  resumeBotTimers() {
    // Only resume if we had paused timers and bot was thinking
    if (!this.pausedTimerStates || !this.pausedTimerStates.wasThinking) {
      this.pausedTimerStates = null;
      return;
    }

    // If bot is still thinking, show the indicator again
    if (this.isBotProcessing) {
      // Restore thinking notification
      const label = document.getElementById('instruction-label');
      const botName = this.game.getBotDifficultyText();
      if (label) {
        label.textContent = `${botName} is thinking...`;
        label.classList.remove('hidden');
        label.style.backgroundColor = '#FE5F00';
        label.style.color = 'white';
        label.style.fontWeight = 'bold';
      }
    }

    // Clear the paused state
    this.pausedTimerStates = null;
  }

  setupOptionsEventListeners() {
    // Clear any existing listeners first
    this.removeOptionsEventListeners();

    // Game Mode radio buttons
    const gameModeRadios = document.querySelectorAll('input[name="gameMode"]');
    gameModeRadios.forEach(radio => {
      const handler = async () => {
        if (radio.checked && radio.value !== this.game.gameMode) {
          try {
            // Save current game state before switching (save to current mode's key)
            const oldMode = this.game.gameMode;
            await this.game.autoSave();
            

            // Switch to new game mode
            this.game.setGameMode(radio.value);

            // Save last game mode
            saveToStorage('last_game_mode', {
              mode: radio.value,
              timestamp: Date.now()
            });

            // When switching modes, handle change tracking appropriately
            // Only reset if this is a different mode from where we started
            if (this.game.originalGameMode !== radio.value) {
                // Switching to a different mode - update the original mode
                this.game.originalGameMode = radio.value;
            }

            // No need to reset flags here - they're tracked per mode

            // Try to load saved state for the new game mode
            const newModeKey = this.game.getStorageKey();
            

            // Check localStorage directly to debug
            const localStorageState = localStorage.getItem(newModeKey);
            if (localStorageState) {
              try {
                const parsed = JSON.parse(localStorageState);
                } catch (e) {
                
              }
            } else {
              
            }

            const savedState = await loadFromStorage(newModeKey);
            let validState = false;
            try {
              validState = savedState && this.isValidSavedState(savedState);
            } catch (e) {
              
              validState = false;
            }
            

            if (validState) {
            // Load saved state but preserve the newly selected game mode
            this.game.loadGameState(savedState, { preserveGameMode: true });
            
            this.updateDisplay();
            // Game mode switched - no notification needed
          } else {
            this.game.newGame();
            this.onNewGameStart();
            // Save minimal state for the new mode even with no moves
            await this.game.autoSave();
            // New game started - no notification needed
          }

          } catch (error) {
            
            // Even if there's an error, ensure we're in a valid state
            this.game.newGame();
            this.onNewGameStart();
          } finally {
            // ALWAYS update the menu buttons regardless of errors
            

            // Update immediately first
            this.updateOptionsButtons();
            

            // Then also update with a small delay to ensure DOM is fully settled
            setTimeout(() => {
              this.updateOptionsButtons(); // Double update to ensure changes stick
              

              // Force check the visibility after update
              const colorGroup = document.getElementById('color-group');
              const difficultyGroup = document.getElementById('difficulty-group');
              const orientationGroup = document.getElementById('orientation-mode-group');
              const undoGroup = document.getElementById('undo-group');

              
              
              
              

            }, 10);
          }
        }
      };
      radio.addEventListener('change', handler);
      this.optionListeners.push({ element: radio, event: 'change', handler });
    });

    // Player Color radio buttons
    const colorRadios = document.querySelectorAll('input[name="playerColor"]');
    colorRadios.forEach(radio => {
      const handler = () => {
        if (radio.checked) {
          this.game.setHumanColor(radio.value);
          this.game.autoSave();
          // Update button states after color change
          this.updateOptionsButtons();
        }
      };
      radio.addEventListener('change', handler);
      this.optionListeners.push({ element: radio, event: 'change', handler });
    });

    // Sound Effects radio buttons
    const soundRadios = document.querySelectorAll('input[name="soundEffects"]');
    soundRadios.forEach(radio => {
      const handler = () => {
        if (radio.checked) {
          const soundEnabled = radio.value === 'on';
          this.game.soundEnabled = soundEnabled;
          this.game.autoSave();
        }
      };
      radio.addEventListener('change', handler);
      this.optionListeners.push({ element: radio, event: 'change', handler });
    });

    // Allow Undo radio buttons
    const undoRadios = document.querySelectorAll('input[name="allowUndo"]');
    undoRadios.forEach(radio => {
      const handler = () => {
        if (radio.checked) {
          const allowUndo = radio.value === 'on';
          this.game.allowUndo = allowUndo;
          this.game.autoSave();
        }
      };
      radio.addEventListener('change', handler);
      this.optionListeners.push({ element: radio, event: 'change', handler });
    });

    // Bot Difficulty radio buttons
    const difficultyRadios = document.querySelectorAll('input[name="botDifficulty"]');
    difficultyRadios.forEach(radio => {
      const handler = () => {
        if (radio.checked) {
          const difficulty = parseInt(radio.value);
          this.game.setBotDifficulty(difficulty);
          this.game.autoSave();
          // Update button states after difficulty change
          this.updateOptionsButtons();
        }
      };
      radio.addEventListener('change', handler);
      this.optionListeners.push({ element: radio, event: 'change', handler });
    });

    // Action buttons
    const newGameBtn = document.getElementById('new-game-btn');
    const backBtn = document.getElementById('back-btn');
    const overlay = document.getElementById('options-overlay');

    if (newGameBtn) {
      const handler = () => {
        this.confirmNewGame();
      };
      newGameBtn.addEventListener('click', handler);
      this.optionListeners.push({ element: newGameBtn, event: 'click', handler });
    }

    if (backBtn) {
      const handler = () => {
        this.hideOptionsMenu();
      };
      backBtn.addEventListener('click', handler);
      this.optionListeners.push({ element: backBtn, event: 'click', handler });
    }

    // Help button
    const helpBtn = document.getElementById('help-btn');
    if (helpBtn) {
      const handler = () => {
        // Don't hide the menu - just show help on top
        showHelpDialog(true); // Pass fromMenu = true
      };
      helpBtn.addEventListener('click', handler);
      this.optionListeners.push({ element: helpBtn, event: 'click', handler });
    }

    // Orientation Mode radio buttons
    const orientationModeRadios = document.querySelectorAll('input[name="orientationMode"]');
    orientationModeRadios.forEach(radio => {
      const handler = () => {
        if (radio.checked) {
          this.game.orientationMode = radio.value;

          // DO NOT apply orientation immediately - wait until menu closes
          // This prevents the menu from flipping while still open

          const modeMessages = {
            'table': 'Table mode: Entire screen rotates for players sitting across',
            'handoff': 'Handoff mode: Pass device between players',
            'none': 'No rotation: Board stays fixed'
          };
          // Board rotation changed - no notification needed
          this.game.autoSave();
        }
      };
      radio.addEventListener('change', handler);
      this.optionListeners.push({ element: radio, event: 'change', handler });
    });

    // Smart overlay click handler - uses same logic as PTT button
    if (overlay) {
      const handler = (event) => {
        // Only handle clicks on the overlay itself, not the menu
        if (event.target === overlay) {
          // Use same logic as PTT button press (lines 4390-4397)
          const backBtn = document.getElementById('back-btn');
          const newGameBtn = document.getElementById('new-game-btn');

          if (backBtn && !backBtn.disabled) {
            // Back to Game is available - close menu
            this.hideOptionsMenu();
          } else if (newGameBtn && !newGameBtn.disabled) {
            // Back to Game is disabled (no game in progress) - scroll to show buttons
            const optionsMenu = document.getElementById('options-menu');
            if (optionsMenu) {
              // Smooth scroll to bottom to show the action buttons
              optionsMenu.scrollTo({
                top: optionsMenu.scrollHeight,
                behavior: 'smooth'
              });
            }
          }
        }
      };
      overlay.addEventListener('click', handler);
      this.optionListeners.push({ element: overlay, event: 'click', handler });
    }
  }

  confirmNewGame() {

    // Clear saved state and start new game BEFORE hiding menu
    this.clearSavedState();
    this.game.newGame();

    // Update the display to reflect the new game
    this.updateDisplay();

    // Now hide the menu AFTER game is initialized
    this.hideOptionsMenu();

    // Check if bot should make the first move AFTER menu is hidden
    // Use longer delay to ensure UI is fully settled
    if (this.game.gameMode === 'human-vs-bot' && this.game.humanColor === 'black') {
      
      setTimeout(() => {
        // Double-check conditions before executing bot move
        if (this.game.gameStatus === 'playing' && this.game.isBotTurn()) {
          this.checkInitialBotTurn();
        }
      }, 1500); // Increased delay to ensure game is fully ready
    }

    // New game started - no notification needed
  }

  async clearSavedState() {
    // Only clear the current mode's saved state, not all modes
    const currentKey = this.game.getStorageKey();
    const keysToRemove = [
      currentKey,
      'chess_game_state' // Legacy key
    ];
    
    
    if (window.creationStorage) {
      try {
        for (const key of keysToRemove) {
          await window.creationStorage.plain.removeItem(key);
        }
        } catch (e) {
        }
    } else {
      // Also clear from localStorage fallback
      try {
        for (const key of keysToRemove) {
          localStorage.removeItem(key);
        }
        } catch (e) {
        }
    }
  }

  /**
   * Unified notification system - single method for all notifications
   * @param {string} message - The message to display
   * @param {string} type - Type of notification: 'default', 'warning', 'error', 'success', 'info'
   * @param {number} duration - Optional duration in ms (defaults based on type)
   */
  showNotification(message, type = 'default', duration = null) {
    // Check if this is an undo/redo notification (move count display)
    const isUndoRedoNotification = message.includes('At move') || message.includes('At start of game');

    // Check if this is the special "Push button to enable undo" notification
    const isPushButtonUndoNotification = message === 'Push button to enable undo';

    // Check if this is a bot dialogue (bot personality messages)
    const isBotDialogue = this.showingBotDialogue || this.pendingBotDialogue;

    // Don't interfere with rotating bot thinking messages UNLESS it's an undo/redo notification or bot dialogue
    if (this.thinkingInterval && !isUndoRedoNotification && !isBotDialogue) {
    // console.log(`[showNotification] Skipping notification during bot thinking: "${message}"`);
      // Skipping notification during bot thinking (except for undo/redo and bot dialogues)
      return;
    }

    // If showing undo/redo notification during bot thinking, temporarily stop the thinking animation
    if (this.thinkingInterval && isUndoRedoNotification) {
      clearInterval(this.thinkingInterval);
      this.thinkingInterval = null;
    }

    const label = document.getElementById('instruction-label');
    if (!label) return;

    // Determine duration based on type if not specified
    if (duration === null) {
      duration = (type === 'warning' || type === 'error') ? 3000 : 2000;
    }

    // For warning/error types, check cooldown to prevent spam
    // Exception: bot undo messages should always show
    const isBotUndoMessage = message.includes('Bot move undone') || message.includes('Bot turn');
    if ((type === 'warning' || type === 'error') && this.notificationCooldown && !isBotUndoMessage) {
      return; // Skip if in cooldown period (unless it's a bot undo message)
    }

    // Clear any existing timeout
    if (this.notificationTimeout) {
      clearTimeout(this.notificationTimeout);
    }

    // Set message
    label.textContent = message;
    label.classList.remove('hidden');

    // Remove any special classes first
    label.classList.remove('undo-notification', 'bot-thinking', 'game-end', 'victory', 'defeat');

    // Apply special class for "Push button to enable undo" notification
    if (isPushButtonUndoNotification) {
      label.classList.add('undo-notification');
      // Clear inline styles for this special notification (let CSS handle it)
      label.style = '';
    } else {
      // Apply styling - enhanced for better text visibility with semi-transparent backdrop
      label.style.backgroundColor = 'rgba(254, 95, 0, 0.95)';  // Semi-transparent orange background
      label.style.backdropFilter = 'blur(8px)';  // Blur the background for better contrast
      label.style.webkitBackdropFilter = 'blur(8px)';  // Safari support
      label.style.color = 'white';
      label.style.fontWeight = '900';  // Extra bold for better visibility
      label.style.fontSize = '14px';  // Increased from 12px
      label.style.padding = '12px 20px';  // More padding for better readability
      label.style.textAlign = 'center';
      label.style.position = 'fixed';
      label.style.top = '50%';
      label.style.left = '50%';
      label.style.transform = 'translate(-50%, -50%)';
      label.style.borderRadius = '10px';
      label.style.boxShadow = '0 8px 32px rgba(0,0,0,0.6), 0 4px 8px rgba(0,0,0,0.4), inset 0 0 0 1px rgba(255,255,255,0.1)';  // Multi-layer shadow
      label.style.zIndex = '200';  // Higher than bot dialogue to ensure visibility
      label.style.textShadow = '2px 2px 4px rgba(0,0,0,0.7), 0 0 8px rgba(0,0,0,0.5)';  // Enhanced text shadow
      label.style.letterSpacing = '0.5px';  // Slight letter spacing for readability
      label.style.lineHeight = '1.4';  // Better line height for multi-line text
      label.style.border = '2px solid rgba(255,255,255,0.25)';  // Stronger border for definition
      label.style.background = 'linear-gradient(135deg, rgba(254, 95, 0, 0.98) 0%, rgba(254, 95, 0, 0.92) 100%)';  // Gradient for depth
    }

    // console.log(`[showNotification] Displayed: "${message}" with type: ${type}, duration: ${duration}ms`);

    // Set cooldown for warning/error types to prevent spam
    if (type === 'warning' || type === 'error') {
      this.notificationCooldown = true;
    }

    // Auto-hide after duration
    this.notificationTimeout = setTimeout(() => {
      label.classList.add('hidden');
      label.classList.remove('undo-notification');
      // Clear all custom styles
      label.style.backgroundColor = '';
      label.style.backdropFilter = '';
      label.style.webkitBackdropFilter = '';
      label.style.color = '';
      label.style.fontWeight = '';
      label.style.fontSize = '';
      label.style.padding = '';
      label.style.textShadow = '';
      label.style.letterSpacing = '';
      label.style.lineHeight = '';
      label.style.border = '';
      label.style.boxShadow = '';
      label.style.background = '';
      label.style = '';  // Clear all inline styles

      // Clear cooldown after hiding (for warning/error types)
      if (type === 'warning' || type === 'error') {
        setTimeout(() => {
          this.notificationCooldown = false;
        }, 500);
      }
    }, duration);
  }

  showInstructionLabel(text) {
    // console.log(`[showInstructionLabel] Called with text: "${text}"`);
    // Delegate to unified notification system
    this.showNotification(text, 'default', 2000);
  }

  /**
   * Show persistent bot dialogue at bottom of screen
   * @param {string} dialogue - The bot's dialogue text
   * @param {string} botName - The bot's name (Evy, Emmy, Asa)
   */
  showBotDialoguePersistent(dialogue, botName) {
    const dialogueArea = document.getElementById('bot-dialogue-area');
    if (!dialogueArea) return;

    // Get responsive sizes from UI design system
    const botUISizes = uiDesign.getBotUISizes();

    // Check if this is human vs human mode
    const isHumanMode = botName === 'Human' || this.game?.gameMode === 'human-vs-human';

    // Clear and rebuild content structure
    dialogueArea.innerHTML = '';
    dialogueArea.className = isHumanMode ? 'bot-dialogue-human' : `bot-dialogue-${botName.toLowerCase()}`;
    dialogueArea.classList.remove('hidden');

    // Update dialogue area height - keep it constrained
    dialogueArea.style.minHeight = botUISizes.dialogue.height;
    dialogueArea.style.height = botUISizes.dialogue.height;  // Fixed height
    dialogueArea.style.maxHeight = botUISizes.dialogue.height;  // Don't grow

    // Create layout structure - orange button area with responsive sizing
    const botInfo = document.createElement('div');
    botInfo.style.display = 'flex';
    botInfo.style.flexDirection = 'column';
    botInfo.style.alignItems = 'center';
    botInfo.style.justifyContent = 'center';
    botInfo.style.padding = '2px';
    botInfo.style.minWidth = botUISizes.button.width;
    botInfo.style.width = botUISizes.button.width;
    botInfo.style.maxWidth = botUISizes.button.width;
    botInfo.style.minHeight = botUISizes.button.height;
    botInfo.style.height = botUISizes.button.height;
    botInfo.style.maxHeight = botUISizes.button.height;
    botInfo.style.textAlign = 'center';
    botInfo.style.backgroundColor = '#FE5F00';  // Orange button background
    botInfo.style.borderRadius = '4px';  // Rounded corners for button look
    botInfo.style.boxShadow = 'inset 0 1px 0 rgba(255,255,255,0.3), inset 0 -1px 0 rgba(0,0,0,0.3)';  // Button depth
    botInfo.style.cursor = 'pointer';
    botInfo.style.margin = '2px 0';  // Small vertical margin like before

    // Add click handler to open menu
    botInfo.addEventListener('click', (e) => {
      e.stopPropagation(); // Prevent event bubbling
      if (window.gameUI) {
        window.gameUI.showOptionsMenu();
      }
    });

    // Icon (using chess piece emoji based on mode) with responsive sizing
    const botIcon = document.createElement('div');
    if (isHumanMode) {
      // Fixed position kings - white always on left, black always on right
      // Current player's king is larger
      const isWhiteTurn = this.game?.currentPlayer === 'white';
      // Use larger icon sizes for Human vs Human mode kings
      // For R1: 18px large, 14px small (was 12px and 8.4px)
      // For larger screens: scale appropriately
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const isR1 = vw <= 240 && vh <= 320;

      let largeSize, smallSize;
      if (isR1) {
        // Much greater size difference for R1
        largeSize = '22px';
        smallSize = '10px';
      } else {
        // Scale up proportionally for larger screens with greater contrast
        largeSize = 'max(22px, min(44px, 6.4vw))';
        smallSize = 'max(10px, min(20px, 2.9vw))';
      }

      if (isWhiteTurn) {
        // White's turn - black king large (opposite), white king small (current)
        botIcon.innerHTML = `<span style="font-size: ${smallSize}; opacity: 0.4;">♔</span><span style="font-size: ${largeSize};">♚</span>`;
      } else {
        // Black's turn - white king large (opposite), black king small (current)
        botIcon.innerHTML = `<span style="font-size: ${largeSize};">♔</span><span style="font-size: ${smallSize}; opacity: 0.4;">♚</span>`;
      }
    } else {
      const icons = { 'Evy': '♟', 'Emmy': '♞', 'Asa': '♛' };
      botIcon.textContent = icons[botName] || '♟';
      botIcon.style.fontSize = botUISizes.button.iconSize;
    }
    botIcon.style.color = '#000';  // Black icon on orange background
    botIcon.style.lineHeight = '1';
    botIcon.style.display = 'flex';
    botIcon.style.alignItems = 'center';
    botIcon.style.justifyContent = 'center';
    botIcon.style.gap = '2px';
    botInfo.appendChild(botIcon);

    // Label - only show for bot mode with responsive sizing
    if (!isHumanMode) {
      const botNameLabel = document.createElement('div');
      botNameLabel.textContent = botName;
      botNameLabel.style.fontSize = botUISizes.button.labelSize;
      botNameLabel.style.color = '#000';  // Black text on orange background
      botNameLabel.style.fontWeight = '900';  // Extra bold for visibility
      botNameLabel.style.marginTop = '1px';
      botNameLabel.style.lineHeight = '1';
      botNameLabel.style.textShadow = '0 0 1px rgba(255,255,255,0.3)';  // Subtle white outline
      botInfo.appendChild(botNameLabel);
    }

    // Dialogue text (no divider needed) with responsive sizing
    const dialogueText = document.createElement('div');
    // If dialogue is empty, show a default message
    if (!dialogue || dialogue.trim() === '') {
      if (isHumanMode) {
        dialogueText.textContent = 'Human vs Human mode';
      } else {
        dialogueText.textContent = `Playing against ${botName}`;
      }
    } else {
      dialogueText.textContent = dialogue;
    }
    dialogueText.style.flex = '1';
    dialogueText.style.color = '#FE5F00';
    dialogueText.style.fontSize = botUISizes.dialogue.fontSize;
    dialogueText.style.textAlign = 'left';
    dialogueText.style.padding = botUISizes.dialogue.padding;
    dialogueText.style.lineHeight = '1.2';  // Tighter line height for multi-line
    dialogueText.style.fontWeight = '600';  // Bolder for visibility
    dialogueText.style.maxHeight = botUISizes.dialogue.height;  // Stay within dialogue area
    dialogueText.style.overflow = 'hidden';  // Hide overflow text
    dialogueText.style.display = 'flex';
    dialogueText.style.alignItems = 'center';
    dialogueText.style.textShadow = '0 0 2px rgba(254,95,0,0.3), 1px 1px 1px rgba(0,0,0,0.5)';  // Glow effect + shadow
    dialogueText.style.letterSpacing = '0.3px';  // Slight letter spacing
    dialogueText.style.paddingRight = '4px';  // Small right padding
    dialogueText.style.whiteSpace = 'normal';  // Allow wrapping
    dialogueText.style.wordBreak = 'break-word';  // Break long words if needed

    // Dynamic font size adjustment to optimize line usage
    setTimeout(() => {
      const container = dialogueText;
      // Account for button width when calculating available space
      const buttonWidth = botInfo.offsetWidth;
      // Recalculate dialogue area width in case of resize
      const dialogueAreaWidth = document.getElementById('bot-dialogue-area').offsetWidth;
      const maxWidth = dialogueAreaWidth - buttonWidth - 10; // Extra padding

      // Get the responsive sizes
      const maxFontSize = parseFloat(botUISizes.dialogue.fontSize);
      const minFontSize = Math.min(parseFloat(botUISizes.dialogue.minFontSize), 6);

      // Try largest size first and see how many lines it needs
      let fontSize = maxFontSize;
      container.style.fontSize = fontSize + 'px';
      container.style.maxWidth = maxWidth + 'px';

      // Calculate line height for measuring
      const lineHeight = fontSize * 1.2; // Match the lineHeight style
      const maxLines = 3;
      const maxTotalHeight = lineHeight * maxLines;

      // Reduce font size until text fits within 3 lines
      while (container.scrollHeight > maxTotalHeight && fontSize > minFontSize) {
        fontSize -= 0.5;
        container.style.fontSize = fontSize + 'px';
      }

      // Now optimize: try to use fewer lines with larger font if possible
      // If it fits in 1 line at current size, try increasing font
      if (container.scrollHeight <= lineHeight * 1.5) { // ~1 line
        while (fontSize < maxFontSize) {
          fontSize += 0.5;
          container.style.fontSize = fontSize + 'px';
          if (container.scrollHeight > lineHeight * 1.5) {
            fontSize -= 0.5; // Back off if it wraps
            container.style.fontSize = fontSize + 'px';
            break;
          }
        }
      }
      // If it fits in 2 lines, optimize for 2
      else if (container.scrollHeight <= lineHeight * 2.5) { // ~2 lines
        while (fontSize < maxFontSize) {
          fontSize += 0.5;
          container.style.fontSize = fontSize + 'px';
          if (container.scrollHeight > lineHeight * 2.5) {
            fontSize -= 0.5; // Back off if it needs 3 lines
            container.style.fontSize = fontSize + 'px';
            break;
          }
        }
      }
    }, 0);

    // Apply container styling - button-like appearance
    dialogueArea.style.display = 'flex';
    dialogueArea.style.alignItems = 'center';  // Center vertically
    dialogueArea.style.backgroundColor = '#000';  // Black background
    dialogueArea.style.position = 'relative';  // In document flow
    dialogueArea.style.width = '100%';  // Fill wrapper width
    dialogueArea.style.borderRadius = '0';  // No rounded corners
    dialogueArea.style.border = 'none';
    dialogueArea.style.margin = '0';  // No margin to ensure left alignment with board
    dialogueArea.style.padding = '0';  // No padding
    dialogueArea.style.cursor = 'pointer';  // Show it's clickable
    dialogueArea.style.transition = 'all 0.2s ease';  // Smooth hover effect

    // Add all elements (no divider)
    dialogueArea.appendChild(botInfo);
    dialogueArea.appendChild(dialogueText);

    // console.log(`[showBotDialoguePersistent] Displayed: "${dialogue}" for bot: ${botName}`);
  }

  /**
   * Refresh the dialogue button to update turn indicator in Human vs Human mode
   */
  refreshDialogueButton() {
    // Only refresh if we have a current dialogue to display
    if (this.game?.currentDialogue && this.game.gameMode === 'human-vs-human') {
      this.showBotDialoguePersistent(this.game.currentDialogue.text, 'Human');
    }
  }

  /**
   * Hide the persistent bot dialogue area
   */
  hideBotDialogue() {
    const dialogueArea = document.getElementById('bot-dialogue-area');
    if (dialogueArea) {
      dialogueArea.classList.add('hidden');
    // console.log(`[hideBotDialogue] Bot dialogue hidden`);
    }
  }

  // showBotUndoAlert and showCheckAlert removed - no longer needed

  // Highlight king piece to indicate check condition
  highlightKing(color) {
    // Find the king of the specified color
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const piece = this.game.board[row][col];
        if (piece && piece.type === 'king' && piece.color === color) {
          // Convert logical coordinates to display coordinates for proper highlighting
          const display = this.getDisplayCoordinates(row, col);
          const square = this.boardElement.children[display.row * 8 + display.col];
          if (square) {
            // Prevent double highlighting - only add if not already highlighted
            if (!square.classList.contains('king-warning')) {
              square.classList.add('king-warning');

              // Remove highlight after 2 seconds
              setTimeout(() => {
                square.classList.remove('king-warning');
              }, 2000);
            }
          }
          return;
        }
      }
    }
  }

  animateUndoRedo(type, isBotMove = false) {
    // Add a subtle animation effect for undo/redo
    const board = this.boardElement;
    if (board) {
      // Get current transform from computed styles before animation
      const computed = window.getComputedStyle(board);
      const currentTransform = computed.transform;
      const hasRotation = currentTransform && currentTransform !== 'none';

      // Apply scale animation on top of existing transform
      const scaleValue = type === 'undo' ? 0.98 : 1.02;
      if (hasRotation) {
        board.style.transform = `${currentTransform} scale(${scaleValue})`;
      } else {
        board.style.transform = `scale(${scaleValue})`;
      }
      board.style.transition = 'transform 0.1s ease';

      setTimeout(() => {
        // Return to original transform or scale(1)
        if (hasRotation) {
          board.style.transform = currentTransform;
        } else {
          board.style.transform = 'scale(1)';
        }

        setTimeout(() => {
          // CRITICAL: Clear inline styles completely so CSS can take over
          board.style.transform = '';
          board.style.transition = '';
        }, 100);
      }, 100);
    }

    // Show move information
    const currentIndex = this.game.getCurrentMoveIndex();
    const totalMoves = this.game.moveHistory ? this.game.moveHistory.length : 0;
    const currentMoveNumber = Math.ceil((currentIndex + 1) / 2);

    // Store if we just undid a bot move for later notification
    // Keep the flag true if it was already true (user may have undone multiple moves)
    if (type === 'undo') {
      if (isBotMove) {
        this.game.lastUndoWasBotMove = true;
      }
      // Don't set to false - keep the flag if any bot move was undone
    }

    // Move count notifications removed - not needed
  }

  // Verify UI consistency with game state
  verifyUIConsistency() {
    const issues = [];
    
    try {
      // Check if current player display matches game state
      const currentPlayerElement = document.getElementById('current-player');
      if (currentPlayerElement) {
        const displayedPlayer = currentPlayerElement.textContent.toLowerCase();
        if (!displayedPlayer.includes(this.game.currentPlayer)) {
          issues.push(`Current player display mismatch: UI shows "${displayedPlayer}", game state is "${this.game.currentPlayer}"`);
        }
      }
      
      // Check move count display
      const moveCountElement = document.getElementById('move-count');
      if (moveCountElement) {
        const currentIndex = this.game.getCurrentMoveIndex();
        const expectedMoveNumber = currentIndex >= 0 ? Math.ceil((currentIndex + 1) / 2) : 0;
        const displayedText = moveCountElement.textContent;
        if (!displayedText.includes(expectedMoveNumber.toString())) {
          issues.push(`Move count display mismatch: UI shows "${displayedText}", expected move number ${expectedMoveNumber}`);
        }
      }
      
      // Check board piece consistency
      const squares = this.boardElement.children;
      let boardMismatches = 0;
      
      for (let i = 0; i < squares.length; i++) {
        const square = squares[i];
        const row = parseInt(square.dataset.row);
        const col = parseInt(square.dataset.col);
        const gamePiece = this.game.board[row][col];
        
        const pieceElements = square.querySelectorAll('.chess-piece');
        const hasPieceInUI = pieceElements.length > 0;
        const hasPieceInGame = gamePiece !== null;
        
        if (hasPieceInUI !== hasPieceInGame) {
          boardMismatches++;
        } else if (hasPieceInGame && hasPieceInUI) {
          const uiPiece = pieceElements[0];
          const expectedSymbol = this.game.getPieceSymbol(gamePiece);
          if (uiPiece.textContent !== expectedSymbol) {
            boardMismatches++;
          }
        }
      }
      
      if (boardMismatches > 0) {
        issues.push(`Board display has ${boardMismatches} piece mismatches with game state`);
      }
      
      // Check game status consistency
      const gameStatusElement = document.getElementById('game-status');
      if (gameStatusElement && gameStatusElement.textContent.trim()) {
        // Only check if there's a status message displayed
        const statusText = gameStatusElement.textContent.toLowerCase();
        if (this.game.gameStatus === 'checkmate' && !statusText.includes('checkmate')) {
          issues.push(`Game status display mismatch: game is checkmate but UI shows "${statusText}"`);
        } else if (this.game.gameStatus === 'stalemate' && !statusText.includes('stalemate')) {
          issues.push(`Game status display mismatch: game is stalemate but UI shows "${statusText}"`);
        }
      }
      
      if (issues.length > 0) {
        return false;
      } else {
        return true;
      }
      
    } catch (error) {
      return false;
    }
  }

  // Update menu visibility based on game mode
  updateMenuVisibility() {
    const colorGroup = document.getElementById('color-group');
    const difficultyGroup = document.getElementById('difficulty-group');
    const orientationGroup = document.getElementById('orientation-mode-group');

    if (this.game.gameMode === 'human-vs-human') {
      // Human vs Human mode
      if (colorGroup) colorGroup.style.display = 'none';
      if (difficultyGroup) difficultyGroup.style.display = 'none';
      if (orientationGroup) orientationGroup.style.display = 'block';
    } else {
      // Human vs Bot mode
      if (colorGroup) colorGroup.style.display = 'block';
      if (difficultyGroup) difficultyGroup.style.display = 'block';
      if (orientationGroup) orientationGroup.style.display = 'none';
    }
  }

  // Helper to get the latest timestamp from a saved state
  getLatestTimestamp(state) {
    if (!state) return 0;

    // Check stateHistory for timestamp
    if (state.stateHistory && state.stateHistory.length > 0) {
      const lastState = state.stateHistory[state.stateHistory.length - 1];
      if (lastState && lastState.timestamp) {
        return lastState.timestamp;
      }
    }

    // Fallback to checking if there are moves (assume older save)
    if (state.moveHistory && state.moveHistory.length > 0) {
      return 1; // Return 1 to indicate it exists but has no timestamp
    }

    return 0;
  }

  async loadGameState() {
    try {
      // First check what was the last game mode used
      const lastModeData = await loadFromStorage('last_game_mode');
      const preferredMode = lastModeData?.mode || null;

      // Load states from both game modes
      const humanVsBotKey = 'chess_game_state_human_vs_bot';
      const humanVsHumanKey = 'chess_game_state_human_vs_human';

      const humanVsBotState = await loadFromStorage(humanVsBotKey);
      const humanVsHumanState = await loadFromStorage(humanVsHumanKey);

      let state = null;
      let selectedMode = null;

      // If we have a preferred mode saved, use that mode regardless of state availability
      if (preferredMode) {
        selectedMode = preferredMode; // Always respect the user's last mode choice

        if (preferredMode === 'human-vs-human') {
          state = humanVsHumanState; // May be null, that's ok
        } else if (preferredMode === 'human-vs-bot') {
          state = humanVsBotState; // May be null, that's ok
        }
      }

      // Only fall back to timestamp comparison if we don't have a preferred mode
      if (!selectedMode && !state) {
        if (humanVsBotState && humanVsHumanState) {
          // Both states exist - load the most recently saved one
          const botTimestamp = this.getLatestTimestamp(humanVsBotState);
          const humanTimestamp = this.getLatestTimestamp(humanVsHumanState);

          

          if (humanTimestamp > botTimestamp) {
            state = humanVsHumanState;
            selectedMode = 'human-vs-human';
            
          } else {
            state = humanVsBotState;
            selectedMode = 'human-vs-bot';
            
          }
        } else if (humanVsHumanState) {
          state = humanVsHumanState;
          selectedMode = 'human-vs-human';
          
        } else if (humanVsBotState) {
          state = humanVsBotState;
          selectedMode = 'human-vs-bot';
          
        }
      }

      if (!state) {
        // Try legacy key for backward compatibility
        state = await loadFromStorage('chess_game_state');
        if (state) {
          selectedMode = state.gameMode || 'human-vs-bot';
        }
      }
      
      // If we have a selected mode but no state, start a new game in that mode
      if (!state && selectedMode) {
        this.game.setGameMode(selectedMode);
        this.game.newGame();
        this.onNewGameStart();
        this.updateMenuVisibility();
        return true;
      }

      if (!state) {
        return false;
      }

      if (this.isValidSavedState(state)) {
        // CRITICAL: Set the correct game mode BEFORE loading state
        if (selectedMode) {
          this.game.gameMode = selectedMode;
        }

        this.game.loadGameState(state);
        this.applyTheme();
        this.updateDisplay();

        // Restore dialogue if present
        if (this.game.currentDialogue && this.game.currentDialogue.text) {
          this.showBotDialoguePersistent(this.game.currentDialogue.text, this.game.currentDialogue.botName);
        }

        // Update menu visibility based on loaded game mode
        this.updateMenuVisibility();

        return true;
      } else {
        // Clear invalid saved state
        await this.clearSavedState();
        return false;
      }
    } catch (error) {
      // Clear potentially corrupted data
      await this.clearSavedState();
      return false;
    }
  }

  isValidSavedState(state) {
    // Basic structure validation
    if (!state || typeof state !== 'object') {
      return false;
    }
    
    // Validate required properties exist
    if (!state.board || !Array.isArray(state.board)) {
      return false;
    }
    
    // Allow missing moveHistory for backward compatibility
    if (state.moveHistory && !Array.isArray(state.moveHistory)) {
      return false;
    }
    
    // Validate board structure (8x8 array)
    if (state.board.length !== 8) {
      return false;
    }
    
    for (let i = 0; i < state.board.length; i++) {
      const row = state.board[i];
      if (!Array.isArray(row) || row.length !== 8) {
        return false;
      }
    }
    
    // Validate current player
    if (!state.currentPlayer || (state.currentPlayer !== 'white' && state.currentPlayer !== 'black')) {
      return false;
    }
    
    // Enhanced validation logic - be more permissive for valid game states
    const moveHistory = state.moveHistory || [];
    const moveCount = moveHistory.length;
    const totalMoves = state.totalMoves || moveCount;
    
    // Accept any state that has move history
    if (moveCount > 0) {
      return true;
    }
    
    // Accept states where the current player is black (white made first move)
    if (state.currentPlayer === 'black') {
      return true;
    }
    
    // Accept completed games regardless of move count
    if (state.gameStatus && (state.gameStatus === 'checkmate' || state.gameStatus === 'stalemate')) {
      return true;
    }
    
    // Accept states with explicit move index (indicates game progression)
    if (state.currentMoveIndex !== undefined && state.currentMoveIndex >= 0) {
      return true;
    }
    
    // Accept states that have been explicitly saved with totalMoves > 0
    if (totalMoves > 0) {
      return true;
    }
    
    // Check if board position differs from initial setup (indicates game has progressed)
    if (this.boardDiffersFromInitial(state.board)) {
      return true;
    }
    
    // If we reach here, it's likely an untouched initial state
    return false;
  }
  
  boardDiffersFromInitial(board) {
    // Check if board differs from standard chess starting position
    if (!board || !Array.isArray(board)) {
      
      return false;
    }

    const initialBoard = this.game ? this.game.initializeBoard() : this.initializeBoard();

    for (let row = 0; row < 8; row++) {
      if (!board[row] || !Array.isArray(board[row])) {
        
        return false;
      }
      for (let col = 0; col < 8; col++) {
        const currentPiece = board[row][col];
        const initialPiece = initialBoard[row][col];
        
        // Compare pieces (both null, or both have same type and color)
        if (currentPiece === null && initialPiece === null) continue;
        if (currentPiece === null || initialPiece === null) return true;
        if (currentPiece.type !== initialPiece.type || currentPiece.color !== initialPiece.color) {
          return true;
        }
      }
    }
    
    return false;
  }
}

// ===========================================
// Physical Input Handling
// ===========================================

// Handle R1 scroll wheel events for undo/redo (reversed direction) or menu navigation
window.addEventListener('scrollUp', async () => {


  // Check if options menu is visible
  const overlay = document.getElementById('options-overlay');
  if (overlay && !overlay.classList.contains('hidden')) {
    // Menu is open - handle menu scrolling
    const optionsMenu = document.getElementById('options-menu');
    if (optionsMenu) {
      optionsMenu.scrollTop = Math.max(0, optionsMenu.scrollTop - 50); // Scroll up
    }
    return;
  }

  if (chessGame && gameUI) {
    if (chessGame.allowUndo) {
      // Check if we're redoing a bot move
      let isRedoingBotMove = false;
      if (chessGame.gameMode === 'human-vs-bot' && chessGame.currentStateIndex < chessGame.stateHistory.length - 1) {
        const targetState = chessGame.stateHistory[chessGame.currentStateIndex + 1];
        if (targetState && targetState.move && targetState.move.piece) {
          isRedoingBotMove = targetState.move.piece.color !== chessGame.humanColor;
        }
      }


      if (chessGame.redoMove()) {
        chessGame.selectedSquare = null; // Clear any selected piece
        // Removed updateBoardPerspective() - orientation is handled by data attributes now
        gameUI.updateDisplay();
        
        gameUI.animateUndoRedo('redo', isRedoingBotMove);
        
        // Update UI elements after redo
        gameUI.updatePlayerTurnIndicator(chessGame.currentPlayer, chessGame.gameMode);
        gameUI.updateCapturedPiecesDisplay();
        gameUI.updateMoveHistoryDisplay();

        // Save state after redo
        await chessGame.autoSave();

        // Just update UI state - NO bot triggering on undo/redo!
        if (chessGame.gameMode === 'human-vs-bot') {
          // Only update UI state based on whose turn it is
          if (chessGame.isBotTurn()) {
            // It's bot's turn after redo, but DON'T trigger a move
            // User needs to decide if they want bot to move
            gameUI.showBotThinking(false);
            gameUI.setInputEnabled(true);
          } else {
            // Human's turn - enable input
            gameUI.showBotThinking(false);
            gameUI.setInputEnabled(true);
          }
        } else if (chessGame.gameMode === 'human-vs-human') {
          // In human vs human, ensure input is enabled
          gameUI.setInputEnabled(true);
        }
        // Don't save state during undo/redo operations
      }
    } else {
      gameUI.showInstructionLabel('Push button to enable undo');
    }
  }
});

window.addEventListener('scrollDown', async () => {


  // Check if options menu is visible
  const overlay = document.getElementById('options-overlay');
  if (overlay && !overlay.classList.contains('hidden')) {
    // Menu is open - handle menu scrolling
    const optionsMenu = document.getElementById('options-menu');
    if (optionsMenu) {
      optionsMenu.scrollTop = Math.min(
        optionsMenu.scrollHeight - optionsMenu.clientHeight,
        optionsMenu.scrollTop + 50
      ); // Scroll down
    }
    return;
  }

  if (chessGame && gameUI) {
    // Track if we cancelled bot thinking
    const wasBotThinking = ChessUI._globalBotProcessing;

    // Check if bot is currently thinking and cancel it FIRST
    let botWasCancelled = false;
    if (wasBotThinking) {
      gameUI.cancelBotThinking();
      botWasCancelled = true;

      // IMPORTANT: When cancelling bot thinking during undo:
      // - The bot's aiMove() may have already executed in the engine
      // - generateBotMove() will restore the engine state if needed
      // - We still need to undo the human's last move
    }

    if (chessGame.allowUndo) {
      // When bot was cancelled, we may need to undo twice:
      // 1. Once for the bot move (if it was recorded)
      // 2. Once for the human move

      if (botWasCancelled) {
        // Check if the current state is a bot move
        const currentState = chessGame.stateHistory[chessGame.currentStateIndex];
        const isCurrentStateBotMove = currentState && currentState.move &&
                                     currentState.move.piece &&
                                     currentState.move.piece.color !== chessGame.humanColor;

        if (isCurrentStateBotMove) {
          // First undo the bot move
          chessGame.undoMove();
        }
      }

      // Now undo the human move (or the only move if no bot cancellation)
      const undoResult = chessGame.undoMove();

      // Determine if we're undoing a bot move for animation purposes
      let isUndoingBotMove = false;
      if (!botWasCancelled && chessGame.gameMode === 'human-vs-bot' && chessGame.currentStateIndex >= 0) {
        const currentState = chessGame.stateHistory[chessGame.currentStateIndex + 1]; // Check the move we just undid
        if (currentState && currentState.move && currentState.move.piece) {
          isUndoingBotMove = currentState.move.piece.color !== chessGame.humanColor;
        }
      }

      if (undoResult) {
        // CRITICAL: Clear selection immediately after undo, before ANY other operations
        chessGame.selectedSquare = null;
        chessGame.possibleMoves = [];

        // Removed updateBoardPerspective() - orientation is handled by data attributes now
        gameUI.updateDisplay();

        // Bot thinking was cancelled - no notification needed
        if (wasBotThinking) {
          // Extra clearing when bot was cancelled to prevent auto-moves
          chessGame.selectedSquare = null;
          chessGame.possibleMoves = [];

          // CRITICAL: Truncate redo history when cancelling bot thinking
          // This prevents redoing the move that triggered bot thinking
          // The bot never made its move, so we can't redo past this point
          if (chessGame.currentStateIndex < chessGame.stateHistory.length - 1) {
            chessGame.stateHistory = chessGame.stateHistory.slice(0, chessGame.currentStateIndex + 1);
          }

          // IMPORTANT: Clear the botWasCancelled flag after successful undo
          // This allows the next move to work properly
          setTimeout(() => {
            chessGame.botWasCancelled = false;
            gameUI.botCancelled = false;
          }, 100);

          // Also clear after a brief delay to catch any async updates
          setTimeout(() => {
            chessGame.selectedSquare = null;
            chessGame.possibleMoves = [];
          }, 100);
        }

        gameUI.animateUndoRedo('undo', isUndoingBotMove);
        
        // Update UI elements after undo
        gameUI.updatePlayerTurnIndicator(chessGame.currentPlayer, chessGame.gameMode);
        gameUI.updateCapturedPiecesDisplay();
        gameUI.updateMoveHistoryDisplay();

        // CRITICAL FIX: Force selectedSquare to null RIGHT BEFORE saving
        // This ensures we don't save a stale selectedSquare state
        chessGame.selectedSquare = null;
        chessGame.possibleMoves = [];

        // Save state after undo
        await chessGame.autoSave();

        // Just update UI state - NO bot triggering on undo/redo!
        if (chessGame.gameMode === 'human-vs-bot') {
          // Always clear bot thinking and enable input after undo
          gameUI.showBotThinking(false);
          gameUI.setInputEnabled(true);

          // If we cancelled bot thinking, just ensure UI is in correct state
          // The undo already reverted the last move, no need for double undo
        } else if (chessGame.gameMode === 'human-vs-human') {
          // In human vs human, ensure input is enabled
          gameUI.setInputEnabled(true);
        }
        // Don't save state during undo/redo operations
      }
    } else {
      gameUI.showInstructionLabel('Push button to enable undo');
    }
  }
});

// Handle R1 side button with debouncing for options menu
let lastSideClickTime = 0;
const DEBOUNCE_DELAY = 300; // 300ms debounce

window.addEventListener('sideClick', () => {
  const now = Date.now();
  if (now - lastSideClickTime < DEBOUNCE_DELAY) {

    return;
  }
  lastSideClickTime = now;



  if (chessGame && gameUI) {
    // Check if options menu is already visible
    const overlay = document.getElementById('options-overlay');
    if (overlay && !overlay.classList.contains('hidden')) {
      // Menu is open - check which button should be activated
      const backBtn = document.getElementById('back-btn');
      const newGameBtn = document.getElementById('new-game-btn');

      // Check if back button is enabled
      if (backBtn && !backBtn.disabled) {
        // Back to Game is available - close menu
        gameUI.hideOptionsMenu();
      } else if (newGameBtn && !newGameBtn.disabled) {
        // Back to Game is disabled - start new game
        gameUI.confirmNewGame();
      }
    } else {
      // Menu is closed - open it
      gameUI.showOptionsMenu();
    }
  }
});

// Function to show enhanced help dialog
function showHelpDialog(fromMenu = false) {
  if (!gameUI) return;

  let helpContent = '<div class="help-dialog-content">';
  helpContent += '<div class="help-header">Chess R1 v0.0.2</div>';
  helpContent += '<div class="help-item">By @EricBuess on X</div>';

  // Add controls section
  helpContent += '<div class="help-controls">';
  helpContent += '<div class="controls-header">Controls & Shortcuts:</div>';
  helpContent += '<div class="control-item">• Open Menu → On Rabbit R1 press side button (push-to-talk).</div>';
  helpContent += '<div class="control-item">  In browser also use p key.</div>';
  helpContent += '<div class="control-item">• Undo/Redo → On Rabbit R1 use scroll wheel.</div>';
  helpContent += '<div class="control-item">  In browser use left/right arrows.</div>';
  helpContent += '</div>';

  // Add note about game saves
  helpContent += '<div class="help-note">';
  helpContent += '<div class="note-header">Note:</div>';
  helpContent += '<div class="note-text">Human vs Bot and Human vs Human games are saved separately. You can switch between modes and your last game in each mode will be automatically restored.</div>';
  helpContent += '</div>';

  // Add dismiss button
  helpContent += '<div class="help-button-container">';
  helpContent += '<button class="help-dismiss-btn">Dismiss</button>';
  helpContent += '</div>';
  helpContent += '</div>';

  // Create custom help dialog element
  const existingDialog = document.querySelector('.help-dialog');
  if (existingDialog) {
    existingDialog.remove();
  }

  const dialog = document.createElement('div');
  dialog.className = 'help-dialog';
  dialog.innerHTML = helpContent;
  document.body.appendChild(dialog);

  // Add dismiss button event listener
  const dismissBtn = dialog.querySelector('.help-dismiss-btn');
  if (dismissBtn) {
    dismissBtn.addEventListener('click', () => {
      dialog.classList.add('hiding');
      setTimeout(() => {
        dialog.remove();
        // Don't need to reopen menu - it stays open behind help
      }, 500);
    });
  }

  // Click outside to close - but ONLY for menu-opened dialog
  if (fromMenu) {
    setTimeout(() => {
      const closeHandler = (e) => {
        if (!dialog.contains(e.target)) {
          dialog.classList.add('hiding');
          setTimeout(() => {
            dialog.remove();
          }, 500);
          document.removeEventListener('click', closeHandler);
        }
      };
      // Use regular bubbling phase, not capture, to avoid interfering
      document.addEventListener('click', closeHandler);
    }, 100);
  }
  // For startup dialog, just rely on the dismiss button - no auto-close or click-outside
}

// Long press shows status information
window.addEventListener('longPressStart', () => {
  // Prevent default long press behavior
});

window.addEventListener('longPressEnd', () => {
  showHelpDialog();
});

// ===========================================
// Plugin Message Handling
// ===========================================

// Handle incoming messages from Flutter/WebSocket
window.onPluginMessage = function(data) {
  
  
  // Could be used for online chess features in the future
  if (data.data) {
    try {
      const parsed = typeof data.data === 'string' ? JSON.parse(data.data) : data.data;
      
    } catch (e) {
      
    }
  }
  
  if (data.message) {
    
  }
};

// ===========================================
// Sending Messages to Flutter
// ===========================================

// Send game events to Flutter (for potential voice feedback)
function sendGameEvent(event, details = {}) {
  if (typeof PluginMessageHandler !== 'undefined') {
    const payload = {
      message: `Chess game event: ${event}`,
      gameEvent: event,
      details: details,
      wantsR1Response: false,
      wantsJournalEntry: false
    };
    PluginMessageHandler.postMessage(JSON.stringify(payload));
  }
}

// ===========================================
// Accelerometer Access (unused in chess but available)
// ===========================================

let accelerometerRunning = false;

function startAccelerometer() {
  if (typeof window.creationSensors === 'undefined' || !window.creationSensors.accelerometer) {
    
    return;
  }
  
  try {
    window.creationSensors.accelerometer.start((data) => {
      // Could be used for shake-to-reset or tilt effects
      
    }, { frequency: 30 });
    
    accelerometerRunning = true;
    
  } catch (e) {
    
  }
}

function stopAccelerometer() {
  if (window.creationSensors && window.creationSensors.accelerometer && accelerometerRunning) {
    try {
      window.creationSensors.accelerometer.stop();
      accelerometerRunning = false;
      
    } catch (e) {
      
    }
  }
}

// ===========================================
// Persistent Storage
// ===========================================

// Calculate simple checksum for data integrity verification
function calculateChecksum(str) {
  let hash = 0;
  if (str.length === 0) return hash;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16);
}

// Wait for storage API to be available (for R1 plugin environment)
async function waitForStorageAPI(maxWaitTime = 500) {
  // Reduce wait time to 500ms since we have localStorage fallback
  const startTime = Date.now();
  const checkInterval = 50; // Check every 50ms

  while (Date.now() - startTime < maxWaitTime) {
    // Check if creationStorage is available
    if (window.creationStorage &&
        window.creationStorage.plain &&
        typeof window.creationStorage.plain.setItem === 'function' &&
        typeof window.creationStorage.plain.getItem === 'function') {
      return true;
    }

    // Wait before next check
    await new Promise(resolve => setTimeout(resolve, checkInterval));
  }

  // Timeout - creationStorage not available, will use localStorage
  return false;
}

// Save data to persistent storage (matches working R1 version - no cookies)
async function saveToStorage(key, value) {
  // Validate input
  if (!key || typeof key !== 'string') {
    return false;
  }

  if (value === undefined || value === null) {
    return false;
  }

  // Enhanced creationStorage availability check
  const creationStorageAvailable = window.creationStorage &&
                                   window.creationStorage.plain &&
                                   typeof window.creationStorage.plain.setItem === 'function';

  if (creationStorageAvailable) {
    try {
      const jsonString = JSON.stringify(value);
      const encoded = btoa(jsonString);
      await window.creationStorage.plain.setItem(key, encoded);
      return true;
    } catch (e) {
      // Fall through to localStorage
    }
  }

  // Direct fallback to localStorage (no cookies - matches working version)
  try {
    const jsonString = JSON.stringify(value);
    localStorage.setItem(key, jsonString);
    return true;
  } catch (e) {
    // Storage failed
  }

  return false;
}

// Load data from persistent storage (matches working R1 version - no cookies)
async function loadFromStorage(key) {
  // Enhanced creationStorage availability check
  const creationStorageAvailable = window.creationStorage &&
                                   window.creationStorage.plain &&
                                   typeof window.creationStorage.plain.getItem === 'function';

  if (creationStorageAvailable) {
    try {
      const stored = await window.creationStorage.plain.getItem(key);
      if (stored) {
        const decoded = atob(stored);
        const parsed = JSON.parse(decoded);
        return parsed;
      }
    } catch (e) {
      // Fall through to localStorage
    }
  }

  // Direct fallback to localStorage (no cookies - matches working version)
  try {
    const stored = localStorage.getItem(key);
    if (stored) {
      const parsed = JSON.parse(stored);
      return parsed;
    }
  } catch (e) {
    // Storage failed
  }
  return null;
}

// ===========================================
// Chess Game Initialization
// ===========================================

document.addEventListener('DOMContentLoaded', async () => {
  
  
  // Add keyboard fallback for development
  if (typeof PluginMessageHandler === 'undefined') {
    window.addEventListener('keydown', (event) => {
      // P key shortcut for opening menu
      if (event.code === 'KeyP') {
        event.preventDefault();
        // Trigger the same event as sideClick (push-to-talk button)
        window.dispatchEvent(new CustomEvent('sideClick'));
      }

      // Arrow key shortcuts for undo/redo in browser
      if (event.code === 'ArrowLeft') {
        event.preventDefault();
        // Trigger the same event as scroll down (which does undo)
        window.dispatchEvent(new CustomEvent('scrollDown'));
      }

      if (event.code === 'ArrowRight') {
        event.preventDefault();

        // Trigger the same event as scroll up (which does redo)
        window.dispatchEvent(new CustomEvent('scrollUp'));

      }
    });
  }

  // Initialize chess game
  chessGame = new ChessGame();
  gameUI = new ChessUI(chessGame);

  // Make objects globally accessible for R1 and bot dialogues
  window.gameUI = gameUI;
  window.chessGame = chessGame;

  // Help dialog no longer shows on startup - available through menu instead

  // Setup header tap zones for status indicator, menu, and undo/redo
  const gameHeader = document.getElementById('game-header');
  if (gameHeader) {
    gameHeader.addEventListener('click', (event) => {
      const rect = gameHeader.getBoundingClientRect();
      const clickX = event.clientX - rect.left;
      const clickY = event.clientY - rect.top;
      const headerWidth = rect.width;
      const headerHeight = rect.height;

      // Simplified logic - removed complex coordinate transformations for R1 performance
      // The header tap zones remain consistent regardless of board orientation

      // Top 40% of header = status indicator (like 'i' key)
      // Bottom 60% = open menu (like 'p' key) OR undo/redo on edges
      if (clickY < headerHeight * 0.4) {
        // Show help dialog
        showHelpDialog();
      } else {
        // Bottom region - check X position for tap zones
        if (clickX < headerWidth * 0.3) {
          // Left edge (30%) - trigger undo (scrollDown)
          window.dispatchEvent(new CustomEvent('scrollDown'));
        } else if (clickX > headerWidth * 0.7) {
          // Right edge (30%) - trigger redo (scrollUp)
          window.dispatchEvent(new CustomEvent('scrollUp'));
        } else {
          // Middle region (40%) - open menu (sideClick)
          window.dispatchEvent(new CustomEvent('sideClick'));
        }
      }
    });
  }

  // Initialize menu visibility based on default game mode
  const colorGroup = document.getElementById('color-group');
  const difficultyGroup = document.getElementById('difficulty-group');
  const orientationGroup = document.getElementById('orientation-mode-group');
  const undoGroup = document.getElementById('undo-group');

  // Set initial visibility based on default game mode (human-vs-bot)
  if (colorGroup) colorGroup.style.display = 'block';
  if (difficultyGroup) difficultyGroup.style.display = 'block';
  if (orientationGroup) orientationGroup.style.display = 'none';
  if (undoGroup) undoGroup.style.display = 'block';
  
  // Wait for storage API to be available before loading game state
  // This is critical for R1 plugin which may not have creationStorage immediately
  const storageReady = await waitForStorageAPI();
  if (!storageReady) {
    // console.log('R1 storage API not available, using localStorage fallback');
  }

  // Try to load saved game state
  const loaded = await gameUI.loadGameState();
  if (loaded) {
    gameUI.updateDisplay();
    gameUI.updateCapturedPiecesDisplay();
    gameUI.gameStatusElement.textContent = 'Game resumed';
    setTimeout(() => {
      gameUI.gameStatusElement.textContent = '';
    }, 2000);
    // Check if it's bot's turn after restoring game
    gameUI.checkInitialBotTurn();
  } else {
    chessGame.newGame();
    gameUI.updateDisplay();
    gameUI.updateCapturedPiecesDisplay();
    // Check if it's bot's turn for new game
    gameUI.checkInitialBotTurn();
  }

  // Send initialization event
  sendGameEvent('game_initialized', {
    theme: chessGame.theme,
    currentPlayer: chessGame.currentPlayer
  });

});

// ===========================================
// Game Exit and Cleanup Logging
// ===========================================

// Log when the page is about to be unloaded (game exit)
window.addEventListener('beforeunload', (event) => {
  });

// Log when the page is being unloaded (game exit)
window.addEventListener('unload', (event) => {
  });

// Log when the page becomes hidden (user switches away)
window.addEventListener('visibilitychange', () => {
  if (document.hidden) {
    } else {
    }
});

// Handle window resize to update bot dialogue width
let resizeTimer = null;
window.addEventListener('resize', () => {
  // Debounce resize events
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(() => {
    // Refresh bot dialogue to match new board dimensions
    if (window.gameUI && window.gameInstance) {
      const game = window.gameInstance;
      if (game.currentDialogue) {
        const botName = game.gameMode === 'human-vs-human' ? 'Human' : game.currentBotName;
        window.gameUI.showBotDialoguePersistent(game.currentDialogue.text, botName || 'Bot');
      }
    }
  }, 2000); // Debounce for 2 seconds
});

// Chess game ready












